/*
 * JMGPU driver
 *
 * Copyright (c) 2020 ChangSha JingJiaMicro Electronics Co., Ltd.
 * All rights reserved.
 *
 * Author:
 *      wj <jjwgpu@jingjiamicro.com>
 *
 * The software and information contained herein is proprietary and
 * confidential to JingJiaMicro Electronics. This software can only be
 * used by JingJiaMicro Electronics Corporation. Any use, reproduction,
 * or disclosure without the written permission of JingJiaMicro
 * Electronics Corporation is strictly prohibited.
 *
 */




#ifndef __jmgpuregDC_h__
#define __jmgpuregDC_h__




#define dcregFrameBufferAddressRegAddrs                                   0x0500
#define DCREG_FRAME_BUFFER_ADDRESS_Address                               0x01400
#define DCREG_FRAME_BUFFER_ADDRESS_MSB                                        15
#define DCREG_FRAME_BUFFER_ADDRESS_LSB                                         1
#define DCREG_FRAME_BUFFER_ADDRESS_BLK                                         1
#define DCREG_FRAME_BUFFER_ADDRESS_Count                                       2
#define DCREG_FRAME_BUFFER_ADDRESS_FieldMask                          0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ADDRESS_ReadMask                           0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ADDRESS_WriteMask                          0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ADDRESS_ResetValue                         0x00000000

#define DCREG_FRAME_BUFFER_ADDRESS_ADDRESS                                  31:0
#define DCREG_FRAME_BUFFER_ADDRESS_ADDRESS_End                                31
#define DCREG_FRAME_BUFFER_ADDRESS_ADDRESS_Start                               0
#define DCREG_FRAME_BUFFER_ADDRESS_ADDRESS_Type                              U32



#define dcregFrameBufferStrideRegAddrs                                    0x0502
#define DCREG_FRAME_BUFFER_STRIDE_Address                                0x01408
#define DCREG_FRAME_BUFFER_STRIDE_MSB                                         15
#define DCREG_FRAME_BUFFER_STRIDE_LSB                                          1
#define DCREG_FRAME_BUFFER_STRIDE_BLK                                          1
#define DCREG_FRAME_BUFFER_STRIDE_Count                                        2
#define DCREG_FRAME_BUFFER_STRIDE_FieldMask                           0x0003FFFF
#define DCREG_FRAME_BUFFER_STRIDE_ReadMask                            0x0003FFFF
#define DCREG_FRAME_BUFFER_STRIDE_WriteMask                           0x0003FFFF
#define DCREG_FRAME_BUFFER_STRIDE_ResetValue                          0x00000000


#define DCREG_FRAME_BUFFER_STRIDE_STRIDE                                    17:0
#define DCREG_FRAME_BUFFER_STRIDE_STRIDE_End                                  17
#define DCREG_FRAME_BUFFER_STRIDE_STRIDE_Start                                 0
#define DCREG_FRAME_BUFFER_STRIDE_STRIDE_Type                                U18



#define dcregDisplayDitherConfigRegAddrs                                  0x0504
#define DCREG_DISPLAY_DITHER_CONFIG_Address                              0x01410
#define DCREG_DISPLAY_DITHER_CONFIG_MSB                                       15
#define DCREG_DISPLAY_DITHER_CONFIG_LSB                                        1
#define DCREG_DISPLAY_DITHER_CONFIG_BLK                                        1
#define DCREG_DISPLAY_DITHER_CONFIG_Count                                      2
#define DCREG_DISPLAY_DITHER_CONFIG_FieldMask                         0x80000000
#define DCREG_DISPLAY_DITHER_CONFIG_ReadMask                          0x80000000
#define DCREG_DISPLAY_DITHER_CONFIG_WriteMask                         0x80000000
#define DCREG_DISPLAY_DITHER_CONFIG_ResetValue                        0x00000000

#define DCREG_DISPLAY_DITHER_CONFIG_ENABLE                                 31:31
#define DCREG_DISPLAY_DITHER_CONFIG_ENABLE_End                                31
#define DCREG_DISPLAY_DITHER_CONFIG_ENABLE_Start                              31
#define DCREG_DISPLAY_DITHER_CONFIG_ENABLE_Type                              U01
#define   DCREG_DISPLAY_DITHER_CONFIG_ENABLE_DISABLED                        0x0
#define   DCREG_DISPLAY_DITHER_CONFIG_ENABLE_ENABLED                         0x1




#define dcregPanelConfigRegAddrs                                          0x0506
#define DCREG_PANEL_CONFIG_Address                                       0x01418
#define DCREG_PANEL_CONFIG_MSB                                                15
#define DCREG_PANEL_CONFIG_LSB                                                 1
#define DCREG_PANEL_CONFIG_BLK                                                 1
#define DCREG_PANEL_CONFIG_Count                                               2
#define DCREG_PANEL_CONFIG_FieldMask                                  0x00000333
#define DCREG_PANEL_CONFIG_ReadMask                                   0x00000333
#define DCREG_PANEL_CONFIG_WriteMask                                  0x00000333
#define DCREG_PANEL_CONFIG_ResetValue                                 0x00000100


#define DCREG_PANEL_CONFIG_DE                                                0:0
#define DCREG_PANEL_CONFIG_DE_End                                              0
#define DCREG_PANEL_CONFIG_DE_Start                                            0
#define DCREG_PANEL_CONFIG_DE_Type                                           U01
#define   DCREG_PANEL_CONFIG_DE_DISABLED                                     0x0
#define   DCREG_PANEL_CONFIG_DE_ENABLED                                      0x1


#define DCREG_PANEL_CONFIG_DE_POLARITY                                       1:1
#define DCREG_PANEL_CONFIG_DE_POLARITY_End                                     1
#define DCREG_PANEL_CONFIG_DE_POLARITY_Start                                   1
#define DCREG_PANEL_CONFIG_DE_POLARITY_Type                                  U01
#define   DCREG_PANEL_CONFIG_DE_POLARITY_POSITIVE                            0x0
#define   DCREG_PANEL_CONFIG_DE_POLARITY_NEGATIVE                            0x1


#define DCREG_PANEL_CONFIG_DATA_ENABLE                                       4:4
#define DCREG_PANEL_CONFIG_DATA_ENABLE_End                                     4
#define DCREG_PANEL_CONFIG_DATA_ENABLE_Start                                   4
#define DCREG_PANEL_CONFIG_DATA_ENABLE_Type                                  U01
#define   DCREG_PANEL_CONFIG_DATA_ENABLE_DISABLED                            0x0
#define   DCREG_PANEL_CONFIG_DATA_ENABLE_ENABLED                             0x1


#define DCREG_PANEL_CONFIG_DATA_POLARITY                                     5:5
#define DCREG_PANEL_CONFIG_DATA_POLARITY_End                                   5
#define DCREG_PANEL_CONFIG_DATA_POLARITY_Start                                 5
#define DCREG_PANEL_CONFIG_DATA_POLARITY_Type                                U01
#define   DCREG_PANEL_CONFIG_DATA_POLARITY_POSITIVE                          0x0
#define   DCREG_PANEL_CONFIG_DATA_POLARITY_NEGATIVE                          0x1


#define DCREG_PANEL_CONFIG_CLOCK                                             8:8
#define DCREG_PANEL_CONFIG_CLOCK_End                                           8
#define DCREG_PANEL_CONFIG_CLOCK_Start                                         8
#define DCREG_PANEL_CONFIG_CLOCK_Type                                        U01
#define   DCREG_PANEL_CONFIG_CLOCK_DISABLED                                  0x0
#define   DCREG_PANEL_CONFIG_CLOCK_ENABLED                                   0x1


#define DCREG_PANEL_CONFIG_CLOCK_POLARITY                                    9:9
#define DCREG_PANEL_CONFIG_CLOCK_POLARITY_End                                  9
#define DCREG_PANEL_CONFIG_CLOCK_POLARITY_Start                                9
#define DCREG_PANEL_CONFIG_CLOCK_POLARITY_Type                               U01
#define   DCREG_PANEL_CONFIG_CLOCK_POLARITY_POSITIVE                         0x0
#define   DCREG_PANEL_CONFIG_CLOCK_POLARITY_NEGATIVE                         0x1




#define dcregDisplayDitherTableLowRegAddrs                                0x0508
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Address                           0x01420
#define DCREG_DISPLAY_DITHER_TABLE_LOW_MSB                                    15
#define DCREG_DISPLAY_DITHER_TABLE_LOW_LSB                                     1
#define DCREG_DISPLAY_DITHER_TABLE_LOW_BLK                                     1
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Count                                   2
#define DCREG_DISPLAY_DITHER_TABLE_LOW_FieldMask                      0xFFFFFFFF
#define DCREG_DISPLAY_DITHER_TABLE_LOW_ReadMask                       0xFFFFFFFF
#define DCREG_DISPLAY_DITHER_TABLE_LOW_WriteMask                      0xFFFFFFFF
#define DCREG_DISPLAY_DITHER_TABLE_LOW_ResetValue                     0x00000000


#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X0                                 3:0
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X0_End                               3
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X0_Start                             0
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X0_Type                            U04


#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X1                                 7:4
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X1_End                               7
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X1_Start                             4
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X1_Type                            U04


#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X2                                11:8
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X2_End                              11
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X2_Start                             8
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X2_Type                            U04


#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X3                               15:12
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X3_End                              15
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X3_Start                            12
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y0_X3_Type                            U04


#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X0                               19:16
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X0_End                              19
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X0_Start                            16
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X0_Type                            U04


#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X1                               23:20
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X1_End                              23
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X1_Start                            20
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X1_Type                            U04


#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X2                               27:24
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X2_End                              27
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X2_Start                            24
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X2_Type                            U04


#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X3                               31:28
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X3_End                              31
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X3_Start                            28
#define DCREG_DISPLAY_DITHER_TABLE_LOW_Y1_X3_Type                            U04

#define dcregDisplayDitherTableHighRegAddrs                               0x050A
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Address                          0x01428
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_MSB                                   15
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_LSB                                    1
#define DCREG_DISPLAY_DITHER_TABLE_LOW_HIGH_BLK                                1
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Count                                  2
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_FieldMask                     0xFFFFFFFF
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_ReadMask                      0xFFFFFFFF
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_WriteMask                     0xFFFFFFFF
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_ResetValue                    0x00000000


#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X0                                3:0
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X0_End                              3
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X0_Start                            0
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X0_Type                           U04


#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X1                                7:4
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X1_End                              7
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X1_Start                            4
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X1_Type                           U04


#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X2                               11:8
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X2_End                             11
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X2_Start                            8
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X2_Type                           U04


#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X3                              15:12
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X3_End                             15
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X3_Start                           12
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y2_X3_Type                           U04


#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X0                              19:16
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X0_End                             19
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X0_Start                           16
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X0_Type                           U04


#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X1                              23:20
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X1_End                             23
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X1_Start                           20
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X1_Type                           U04


#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X2                              27:24
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X2_End                             27
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X2_Start                           24
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X2_Type                           U04


#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X3                              31:28
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X3_End                             31
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X3_Start                           28
#define DCREG_DISPLAY_DITHER_TABLE_HIGH_Y3_X3_Type                           U04



#define dcregHDisplayRegAddrs                                             0x050C
#define DCREG_HDISPLAY_Address                                           0x01430
#define DCREG_HDISPLAY_MSB                                                    15
#define DCREG_HDISPLAY_LSB                                                     1
#define DCREG_HDISPLAY_BLK                                                     1
#define DCREG_HDISPLAY_Count                                                   2
#define DCREG_HDISPLAY_FieldMask                                      0x7FFF7FFF
#define DCREG_HDISPLAY_ReadMask                                       0x7FFF7FFF
#define DCREG_HDISPLAY_WriteMask                                      0x7FFF7FFF
#define DCREG_HDISPLAY_ResetValue                                     0x00000000


#define DCREG_HDISPLAY_DISPLAY_END                                          14:0
#define DCREG_HDISPLAY_DISPLAY_END_End                                        14
#define DCREG_HDISPLAY_DISPLAY_END_Start                                       0
#define DCREG_HDISPLAY_DISPLAY_END_Type                                      U15


#define DCREG_HDISPLAY_TOTAL                                               30:16
#define DCREG_HDISPLAY_TOTAL_End                                              30
#define DCREG_HDISPLAY_TOTAL_Start                                            16
#define DCREG_HDISPLAY_TOTAL_Type                                            U15



#define dcregHSyncRegAddrs                                                0x050E
#define DCREG_HSYNC_Address                                              0x01438
#define DCREG_HSYNC_MSB                                                       15
#define DCREG_HSYNC_LSB                                                        1
#define DCREG_HSYNC_BLK                                                        1
#define DCREG_HSYNC_Count                                                      2
#define DCREG_HSYNC_FieldMask                                         0xFFFFFFFF
#define DCREG_HSYNC_ReadMask                                          0xFFFFFFFF
#define DCREG_HSYNC_WriteMask                                         0xFFFFFFFF
#define DCREG_HSYNC_ResetValue                                        0x00000000


#define DCREG_HSYNC_START                                                   14:0
#define DCREG_HSYNC_START_End                                                 14
#define DCREG_HSYNC_START_Start                                                0
#define DCREG_HSYNC_START_Type                                               U15


#define DCREG_HSYNC_END                                                    29:15
#define DCREG_HSYNC_END_End                                                   29
#define DCREG_HSYNC_END_Start                                                 15
#define DCREG_HSYNC_END_Type                                                 U15


#define DCREG_HSYNC_PULSE                                                  30:30
#define DCREG_HSYNC_PULSE_End                                                 30
#define DCREG_HSYNC_PULSE_Start                                               30
#define DCREG_HSYNC_PULSE_Type                                               U01
#define   DCREG_HSYNC_PULSE_DISABLED                                         0x0
#define   DCREG_HSYNC_PULSE_ENABLED                                          0x1


#define DCREG_HSYNC_POLARITY                                               31:31
#define DCREG_HSYNC_POLARITY_End                                              31
#define DCREG_HSYNC_POLARITY_Start                                            31
#define DCREG_HSYNC_POLARITY_Type                                            U01
#define   DCREG_HSYNC_POLARITY_POSITIVE                                      0x0
#define   DCREG_HSYNC_POLARITY_NEGATIVE                                      0x1



#define dcregVDisplayRegAddrs                                             0x0510
#define DCREG_VDISPLAY_Address                                           0x01440
#define DCREG_VDISPLAY_MSB                                                    15
#define DCREG_VDISPLAY_LSB                                                     1
#define DCREG_VDISPLAY_BLK                                                     1
#define DCREG_VDISPLAY_Count                                                   2
#define DCREG_VDISPLAY_FieldMask                                      0x7FFF7FFF
#define DCREG_VDISPLAY_ReadMask                                       0x7FFF7FFF
#define DCREG_VDISPLAY_WriteMask                                      0x7FFF7FFF
#define DCREG_VDISPLAY_ResetValue                                     0x00000000


#define DCREG_VDISPLAY_DISPLAY_END                                          14:0
#define DCREG_VDISPLAY_DISPLAY_END_End                                        14
#define DCREG_VDISPLAY_DISPLAY_END_Start                                       0
#define DCREG_VDISPLAY_DISPLAY_END_Type                                      U15


#define DCREG_VDISPLAY_TOTAL                                               30:16
#define DCREG_VDISPLAY_TOTAL_End                                              30
#define DCREG_VDISPLAY_TOTAL_Start                                            16
#define DCREG_VDISPLAY_TOTAL_Type                                            U15



#define dcregVSyncRegAddrs                                                0x0512
#define DCREG_VSYNC_Address                                              0x01448
#define DCREG_VSYNC_MSB                                                       15
#define DCREG_VSYNC_LSB                                                        1
#define DCREG_VSYNC_BLK                                                        1
#define DCREG_VSYNC_Count                                                      2
#define DCREG_VSYNC_FieldMask                                         0xFFFFFFFF
#define DCREG_VSYNC_ReadMask                                          0xFFFFFFFF
#define DCREG_VSYNC_WriteMask                                         0xFFFFFFFF
#define DCREG_VSYNC_ResetValue                                        0x00000000


#define DCREG_VSYNC_START                                                   14:0
#define DCREG_VSYNC_START_End                                                 14
#define DCREG_VSYNC_START_Start                                                0
#define DCREG_VSYNC_START_Type                                               U15


#define DCREG_VSYNC_END                                                    29:15
#define DCREG_VSYNC_END_End                                                   29
#define DCREG_VSYNC_END_Start                                                 15
#define DCREG_VSYNC_END_Type                                                 U15


#define DCREG_VSYNC_PULSE                                                  30:30
#define DCREG_VSYNC_PULSE_End                                                 30
#define DCREG_VSYNC_PULSE_Start                                               30
#define DCREG_VSYNC_PULSE_Type                                               U01
#define   DCREG_VSYNC_PULSE_DISABLED                                         0x0
#define   DCREG_VSYNC_PULSE_ENABLED                                          0x1


#define DCREG_VSYNC_POLARITY                                               31:31
#define DCREG_VSYNC_POLARITY_End                                              31
#define DCREG_VSYNC_POLARITY_Start                                            31
#define DCREG_VSYNC_POLARITY_Type                                            U01
#define   DCREG_VSYNC_POLARITY_POSITIVE                                      0x0
#define   DCREG_VSYNC_POLARITY_NEGATIVE                                      0x1




#define dcregDisplayCurrentLocationRegAddrs                               0x0514
#define DCREG_DISPLAY_CURRENT_LOCATION_Address                           0x01450
#define DCREG_DISPLAY_CURRENT_LOCATION_MSB                                    15
#define DCREG_DISPLAY_CURRENT_LOCATION_LSB                                     1
#define DCREG_DISPLAY_CURRENT_LOCATION_BLK                                     1
#define DCREG_DISPLAY_CURRENT_LOCATION_Count                                   2
#define DCREG_DISPLAY_CURRENT_LOCATION_FieldMask                      0xFFFFFFFF
#define DCREG_DISPLAY_CURRENT_LOCATION_ReadMask                       0xFFFFFFFF
#define DCREG_DISPLAY_CURRENT_LOCATION_WriteMask                      0x00000000
#define DCREG_DISPLAY_CURRENT_LOCATION_ResetValue                     0x00000000


#define DCREG_DISPLAY_CURRENT_LOCATION_X                                    15:0
#define DCREG_DISPLAY_CURRENT_LOCATION_X_End                                  15
#define DCREG_DISPLAY_CURRENT_LOCATION_X_Start                                 0
#define DCREG_DISPLAY_CURRENT_LOCATION_X_Type                                U16


#define DCREG_DISPLAY_CURRENT_LOCATION_Y                                   31:16
#define DCREG_DISPLAY_CURRENT_LOCATION_Y_End                                  31
#define DCREG_DISPLAY_CURRENT_LOCATION_Y_Start                                16
#define DCREG_DISPLAY_CURRENT_LOCATION_Y_Type                                U16



#define dcregGammaIndexRegAddrs                                           0x0516
#define DCREG_GAMMA_INDEX_Address                                        0x01458
#define DCREG_GAMMA_INDEX_MSB                                                 15
#define DCREG_GAMMA_INDEX_LSB                                                  1
#define DCREG_GAMMA_INDEX_BLK                                                  1
#define DCREG_GAMMA_INDEX_Count                                                2
#define DCREG_GAMMA_INDEX_FieldMask                                   0x000000FF
#define DCREG_GAMMA_INDEX_ReadMask                                    0x00000000
#define DCREG_GAMMA_INDEX_WriteMask                                   0x000000FF
#define DCREG_GAMMA_INDEX_ResetValue                                  0x00000000


#define DCREG_GAMMA_INDEX_INDEX                                              7:0
#define DCREG_GAMMA_INDEX_INDEX_End                                            7
#define DCREG_GAMMA_INDEX_INDEX_Start                                          0
#define DCREG_GAMMA_INDEX_INDEX_Type                                         U08



#define dcregGammaDataRegAddrs                                            0x0518
#define DCREG_GAMMA_DATA_Address                                         0x01460
#define DCREG_GAMMA_DATA_MSB                                                  15
#define DCREG_GAMMA_DATA_LSB                                                   1
#define DCREG_GAMMA_DATA_BLK                                                   1
#define DCREG_GAMMA_DATA_Count                                                 2
#define DCREG_GAMMA_DATA_FieldMask                                    0x3FFFFFFF
#define DCREG_GAMMA_DATA_ReadMask                                     0x00000000
#define DCREG_GAMMA_DATA_WriteMask                                    0x3FFFFFFF
#define DCREG_GAMMA_DATA_ResetValue                                   0x00000000


#define DCREG_GAMMA_DATA_BLUE                                                9:0
#define DCREG_GAMMA_DATA_BLUE_End                                              9
#define DCREG_GAMMA_DATA_BLUE_Start                                            0
#define DCREG_GAMMA_DATA_BLUE_Type                                           U10


#define DCREG_GAMMA_DATA_GREEN                                             19:10
#define DCREG_GAMMA_DATA_GREEN_End                                            19
#define DCREG_GAMMA_DATA_GREEN_Start                                          10
#define DCREG_GAMMA_DATA_GREEN_Type                                          U10


#define DCREG_GAMMA_DATA_RED                                               29:20
#define DCREG_GAMMA_DATA_RED_End                                              29
#define DCREG_GAMMA_DATA_RED_Start                                            20
#define DCREG_GAMMA_DATA_RED_Type                                            U10




#define dcregCursorConfigRegAddrs                                         0x051A
#define DCREG_CURSOR_CONFIG_Address                                      0x01468
#define DCREG_CURSOR_CONFIG_MSB                                               15
#define DCREG_CURSOR_CONFIG_LSB                                                0
#define DCREG_CURSOR_CONFIG_BLK                                                0
#define DCREG_CURSOR_CONFIG_Count                                              1
#define DCREG_CURSOR_CONFIG_FieldMask                                 0x001F1FF7
#define DCREG_CURSOR_CONFIG_ReadMask                                  0x001F1FF7
#define DCREG_CURSOR_CONFIG_WriteMask                                 0x001F1FF7
#define DCREG_CURSOR_CONFIG_ResetValue                                0x00000000

#define DCREG_CURSOR_CONFIG_FORMAT                                           1:0
#define DCREG_CURSOR_CONFIG_FORMAT_End                                         1
#define DCREG_CURSOR_CONFIG_FORMAT_Start                                       0
#define DCREG_CURSOR_CONFIG_FORMAT_Type                                      U02
#define   DCREG_CURSOR_CONFIG_FORMAT_DISABLED                                0x0
#define   DCREG_CURSOR_CONFIG_FORMAT_MASKED                                  0x1
#define   DCREG_CURSOR_CONFIG_FORMAT_A8R8G8B8                                0x2


#define DCREG_CURSOR_CONFIG_TRIGGER_FETCH                                    2:2
#define DCREG_CURSOR_CONFIG_TRIGGER_FETCH_End                                  2
#define DCREG_CURSOR_CONFIG_TRIGGER_FETCH_Start                                2
#define DCREG_CURSOR_CONFIG_TRIGGER_FETCH_Type                               U01
#define   DCREG_CURSOR_CONFIG_TRIGGER_FETCH_DISABLED                         0x0
#define   DCREG_CURSOR_CONFIG_TRIGGER_FETCH_ENABLED                          0x1


#define DCREG_CURSOR_CONFIG_DISPLAY                                          4:4
#define DCREG_CURSOR_CONFIG_DISPLAY_End                                        4
#define DCREG_CURSOR_CONFIG_DISPLAY_Start                                      4
#define DCREG_CURSOR_CONFIG_DISPLAY_Type                                     U01
#define   DCREG_CURSOR_CONFIG_DISPLAY_DISPLAY0                               0x0
#define   DCREG_CURSOR_CONFIG_DISPLAY_DISPLAY1                               0x1


#define DCREG_CURSOR_CONFIG_SIZE                                             7:5
#define DCREG_CURSOR_CONFIG_SIZE_End                                           7
#define DCREG_CURSOR_CONFIG_SIZE_Start                                         5
#define DCREG_CURSOR_CONFIG_SIZE_Type                                        U03
#define   DCREG_CURSOR_CONFIG_SIZE_SIZE32X32                                 0x0
#define   DCREG_CURSOR_CONFIG_SIZE_SIZE64X64                                 0x1
#define   DCREG_CURSOR_CONFIG_SIZE_SIZE128X128                               0x2
#define   DCREG_CURSOR_CONFIG_SIZE_SIZE256X256                               0x3

#define DCREG_CURSOR_CONFIG_HOT_SPOT_Y                                      12:8
#define DCREG_CURSOR_CONFIG_HOT_SPOT_Y_End                                    12
#define DCREG_CURSOR_CONFIG_HOT_SPOT_Y_Start                                   8
#define DCREG_CURSOR_CONFIG_HOT_SPOT_Y_Type                                  U05

#define DCREG_CURSOR_CONFIG_HOT_SPOT_X                                     20:16
#define DCREG_CURSOR_CONFIG_HOT_SPOT_X_End                                    20
#define DCREG_CURSOR_CONFIG_HOT_SPOT_X_Start                                  16
#define DCREG_CURSOR_CONFIG_HOT_SPOT_X_Type                                  U05



#define dcregCursorAddressRegAddrs                                        0x051B
#define DCREG_CURSOR_ADDRESS_Address                                     0x0146C
#define DCREG_CURSOR_ADDRESS_MSB                                              15
#define DCREG_CURSOR_ADDRESS_LSB                                               0
#define DCREG_CURSOR_ADDRESS_BLK                                               0
#define DCREG_CURSOR_ADDRESS_Count                                             1
#define DCREG_CURSOR_ADDRESS_FieldMask                                0xFFFFFFFF
#define DCREG_CURSOR_ADDRESS_ReadMask                                 0xFFFFFFFF
#define DCREG_CURSOR_ADDRESS_WriteMask                                0xFFFFFFFF
#define DCREG_CURSOR_ADDRESS_ResetValue                               0x00000000

#define DCREG_CURSOR_ADDRESS_ADDRESS                                        31:0
#define DCREG_CURSOR_ADDRESS_ADDRESS_End                                      31
#define DCREG_CURSOR_ADDRESS_ADDRESS_Start                                     0
#define DCREG_CURSOR_ADDRESS_ADDRESS_Type                                    U32



#define dcregCursorLocationRegAddrs                                       0x051C
#define DCREG_CURSOR_LOCATION_Address                                    0x01470
#define DCREG_CURSOR_LOCATION_MSB                                             15
#define DCREG_CURSOR_LOCATION_LSB                                              0
#define DCREG_CURSOR_LOCATION_BLK                                              0
#define DCREG_CURSOR_LOCATION_Count                                            1
#define DCREG_CURSOR_LOCATION_FieldMask                               0x7FFF7FFF
#define DCREG_CURSOR_LOCATION_ReadMask                                0x7FFF7FFF
#define DCREG_CURSOR_LOCATION_WriteMask                               0x7FFF7FFF
#define DCREG_CURSOR_LOCATION_ResetValue                              0x00000000


#define DCREG_CURSOR_LOCATION_X                                             14:0
#define DCREG_CURSOR_LOCATION_X_End                                           14
#define DCREG_CURSOR_LOCATION_X_Start                                          0
#define DCREG_CURSOR_LOCATION_X_Type                                         U15


#define DCREG_CURSOR_LOCATION_Y                                            30:16
#define DCREG_CURSOR_LOCATION_Y_End                                           30
#define DCREG_CURSOR_LOCATION_Y_Start                                         16
#define DCREG_CURSOR_LOCATION_Y_Type                                         U15



#define dcregCursorBackgroundRegAddrs                                     0x051D
#define DCREG_CURSOR_BACKGROUND_Address                                  0x01474
#define DCREG_CURSOR_BACKGROUND_MSB                                           15
#define DCREG_CURSOR_BACKGROUND_LSB                                            0
#define DCREG_CURSOR_BACKGROUND_BLK                                            0
#define DCREG_CURSOR_BACKGROUND_Count                                          1
#define DCREG_CURSOR_BACKGROUND_FieldMask                             0x00FFFFFF
#define DCREG_CURSOR_BACKGROUND_ReadMask                              0x00FFFFFF
#define DCREG_CURSOR_BACKGROUND_WriteMask                             0x00FFFFFF
#define DCREG_CURSOR_BACKGROUND_ResetValue                            0x00000000


#define DCREG_CURSOR_BACKGROUND_BLUE                                         7:0
#define DCREG_CURSOR_BACKGROUND_BLUE_End                                       7
#define DCREG_CURSOR_BACKGROUND_BLUE_Start                                     0
#define DCREG_CURSOR_BACKGROUND_BLUE_Type                                    U08


#define DCREG_CURSOR_BACKGROUND_GREEN                                       15:8
#define DCREG_CURSOR_BACKGROUND_GREEN_End                                     15
#define DCREG_CURSOR_BACKGROUND_GREEN_Start                                    8
#define DCREG_CURSOR_BACKGROUND_GREEN_Type                                   U08


#define DCREG_CURSOR_BACKGROUND_RED                                        23:16
#define DCREG_CURSOR_BACKGROUND_RED_End                                       23
#define DCREG_CURSOR_BACKGROUND_RED_Start                                     16
#define DCREG_CURSOR_BACKGROUND_RED_Type                                     U08



#define dcregCursorForegroundRegAddrs                                     0x051E
#define DCREG_CURSOR_FOREGROUND_Address                                  0x01478
#define DCREG_CURSOR_FOREGROUND_MSB                                           15
#define DCREG_CURSOR_FOREGROUND_LSB                                            0
#define DCREG_CURSOR_FOREGROUND_BLK                                            0
#define DCREG_CURSOR_FOREGROUND_Count                                          1
#define DCREG_CURSOR_FOREGROUND_FieldMask                             0x00FFFFFF
#define DCREG_CURSOR_FOREGROUND_ReadMask                              0x00FFFFFF
#define DCREG_CURSOR_FOREGROUND_WriteMask                             0x00FFFFFF
#define DCREG_CURSOR_FOREGROUND_ResetValue                            0x00000000


#define DCREG_CURSOR_FOREGROUND_BLUE                                         7:0
#define DCREG_CURSOR_FOREGROUND_BLUE_End                                       7
#define DCREG_CURSOR_FOREGROUND_BLUE_Start                                     0
#define DCREG_CURSOR_FOREGROUND_BLUE_Type                                    U08


#define DCREG_CURSOR_FOREGROUND_GREEN                                       15:8
#define DCREG_CURSOR_FOREGROUND_GREEN_End                                     15
#define DCREG_CURSOR_FOREGROUND_GREEN_Start                                    8
#define DCREG_CURSOR_FOREGROUND_GREEN_Type                                   U08


#define DCREG_CURSOR_FOREGROUND_RED                                        23:16
#define DCREG_CURSOR_FOREGROUND_RED_End                                       23
#define DCREG_CURSOR_FOREGROUND_RED_Start                                     16
#define DCREG_CURSOR_FOREGROUND_RED_Type                                     U08

#define dcregDisplayIntrRegAddrs                                          0x051F
#define DCREG_DISPLAY_INTR_Address                                       0x0147C
#define DCREG_DISPLAY_INTR_MSB                                                15
#define DCREG_DISPLAY_INTR_LSB                                                 0
#define DCREG_DISPLAY_INTR_BLK                                                 0
#define DCREG_DISPLAY_INTR_Count                                               1
#define DCREG_DISPLAY_INTR_FieldMask                                  0x00003111
#define DCREG_DISPLAY_INTR_ReadMask                                   0x00003111
#define DCREG_DISPLAY_INTR_WriteMask                                  0x00000000
#define DCREG_DISPLAY_INTR_ResetValue                                 0x00000000


#define DCREG_DISPLAY_INTR_DISP0                                             0:0
#define DCREG_DISPLAY_INTR_DISP0_End                                           0
#define DCREG_DISPLAY_INTR_DISP0_Start                                         0
#define DCREG_DISPLAY_INTR_DISP0_Type                                        U01


#define DCREG_DISPLAY_INTR_DISP1                                             4:4
#define DCREG_DISPLAY_INTR_DISP1_End                                           4
#define DCREG_DISPLAY_INTR_DISP1_Start                                         4
#define DCREG_DISPLAY_INTR_DISP1_Type                                        U01


#define DCREG_DISPLAY_INTR_CURSOR                                            8:8
#define DCREG_DISPLAY_INTR_CURSOR_End                                          8
#define DCREG_DISPLAY_INTR_CURSOR_Start                                        8
#define DCREG_DISPLAY_INTR_CURSOR_Type                                       U01


#define DCREG_DISPLAY_INTR_DISP0_DBI_CFG_ERROR                             12:12
#define DCREG_DISPLAY_INTR_DISP0_DBI_CFG_ERROR_End                            12
#define DCREG_DISPLAY_INTR_DISP0_DBI_CFG_ERROR_Start                          12
#define DCREG_DISPLAY_INTR_DISP0_DBI_CFG_ERROR_Type                          U01


#define DCREG_DISPLAY_INTR_DISP1_DBI_CFG_ERROR                             13:13
#define DCREG_DISPLAY_INTR_DISP1_DBI_CFG_ERROR_End                            13
#define DCREG_DISPLAY_INTR_DISP1_DBI_CFG_ERROR_Start                          13
#define DCREG_DISPLAY_INTR_DISP1_DBI_CFG_ERROR_Type                          U01



#define dcregDisplayIntrEnableRegAddrs                                    0x0520
#define DCREG_DISPLAY_INTR_ENABLE_Address                                0x01480
#define DCREG_DISPLAY_INTR_ENABLE_MSB                                         15
#define DCREG_DISPLAY_INTR_ENABLE_LSB                                          0
#define DCREG_DISPLAY_INTR_ENABLE_BLK                                          0
#define DCREG_DISPLAY_INTR_ENABLE_Count                                        1
#define DCREG_DISPLAY_INTR_ENABLE_FieldMask                           0x00000011
#define DCREG_DISPLAY_INTR_ENABLE_ReadMask                            0x00000011
#define DCREG_DISPLAY_INTR_ENABLE_WriteMask                           0x00000011
#define DCREG_DISPLAY_INTR_ENABLE_ResetValue                          0x00000000


#define DCREG_DISPLAY_INTR_ENABLE_DISP0                                      0:0
#define DCREG_DISPLAY_INTR_ENABLE_DISP0_End                                    0
#define DCREG_DISPLAY_INTR_ENABLE_DISP0_Start                                  0
#define DCREG_DISPLAY_INTR_ENABLE_DISP0_Type                                 U01


#define DCREG_DISPLAY_INTR_ENABLE_DISP1                                      4:4
#define DCREG_DISPLAY_INTR_ENABLE_DISP1_End                                    4
#define DCREG_DISPLAY_INTR_ENABLE_DISP1_Start                                  4
#define DCREG_DISPLAY_INTR_ENABLE_DISP1_Type                                 U01




#define dcregCursorModuleClockGatingControlRegAddrs                       0x0521
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_Address                 0x01484
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_MSB                          15
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_LSB                           0
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_BLK                           0
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_Count                         1
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_FieldMask            0x00000001
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_ReadMask             0x00000001
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_WriteMask            0x00000001
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_ResetValue           0x00000001

#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_CURSOR 0:0
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_CURSOR_End 0
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_CURSOR_Start 0
#define DCREG_CURSOR_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_CURSOR_Type U01




#define dcregDbiConfigRegAddrs                                            0x0522
#define DCREG_DBI_CONFIG_Address                                         0x01488
#define DCREG_DBI_CONFIG_MSB                                                  15
#define DCREG_DBI_CONFIG_LSB                                                   1
#define DCREG_DBI_CONFIG_BLK                                                   1
#define DCREG_DBI_CONFIG_Count                                                 2
#define DCREG_DBI_CONFIG_FieldMask                                    0x00003FFF
#define DCREG_DBI_CONFIG_ReadMask                                     0x00003FFF
#define DCREG_DBI_CONFIG_WriteMask                                    0x00003FFF
#define DCREG_DBI_CONFIG_ResetValue                                   0x00000000


#define DCREG_DBI_CONFIG_DBI_TYPEC_OPT                                     13:12
#define DCREG_DBI_CONFIG_DBI_TYPEC_OPT_End                                    13
#define DCREG_DBI_CONFIG_DBI_TYPEC_OPT_Start                                  12
#define DCREG_DBI_CONFIG_DBI_TYPEC_OPT_Type                                  U02


#define DCREG_DBI_CONFIG_DBI_AC_TIME_UNIT                                   11:8
#define DCREG_DBI_CONFIG_DBI_AC_TIME_UNIT_End                                 11
#define DCREG_DBI_CONFIG_DBI_AC_TIME_UNIT_Start                                8
#define DCREG_DBI_CONFIG_DBI_AC_TIME_UNIT_Type                               U04


#define DCREG_DBI_CONFIG_DBIX_POLARITY                                       7:7
#define DCREG_DBI_CONFIG_DBIX_POLARITY_End                                     7
#define DCREG_DBI_CONFIG_DBIX_POLARITY_Start                                   7
#define DCREG_DBI_CONFIG_DBIX_POLARITY_Type                                  U01
#define   DCREG_DBI_CONFIG_DBIX_POLARITY_DEFAULT                             0x0
#define   DCREG_DBI_CONFIG_DBIX_POLARITY_REVERSE                             0x1


#define DCREG_DBI_CONFIG_BUS_OUTPUT_SEL                                      6:6
#define DCREG_DBI_CONFIG_BUS_OUTPUT_SEL_End                                    6
#define DCREG_DBI_CONFIG_BUS_OUTPUT_SEL_Start                                  6
#define DCREG_DBI_CONFIG_BUS_OUTPUT_SEL_Type                                 U01
#define   DCREG_DBI_CONFIG_BUS_OUTPUT_SEL_DPI                                0x0
#define   DCREG_DBI_CONFIG_BUS_OUTPUT_SEL_DBI                                0x1

#define DCREG_DBI_CONFIG_DBI_DATA_FORMAT                                     5:2
#define DCREG_DBI_CONFIG_DBI_DATA_FORMAT_End                                   5
#define DCREG_DBI_CONFIG_DBI_DATA_FORMAT_Start                                 2
#define DCREG_DBI_CONFIG_DBI_DATA_FORMAT_Type                                U04
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D8R3G3B2                          0x0
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D8R4G4B4                          0x1
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D8R5G6B5                          0x2
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D8R6G6B6                          0x3
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D8R8G8B8                          0x4
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D9R6G6B6                          0x5
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D16R3G3B2                         0x6
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D16R4G4B4                         0x7
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D16R5G6B5                         0x8
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D16_R6_G6_B6_OP1                  0x9
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D16_R6_G6_B6_OP2                  0xA
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D16_R8_G8_B8_OP1                  0xB
#define   DCREG_DBI_CONFIG_DBI_DATA_FORMAT_D16_R8_G8_B8_OP2                  0xC


#define DCREG_DBI_CONFIG_DBI_TYPE                                            1:0
#define DCREG_DBI_CONFIG_DBI_TYPE_End                                          1
#define DCREG_DBI_CONFIG_DBI_TYPE_Start                                        0
#define DCREG_DBI_CONFIG_DBI_TYPE_Type                                       U02
#define   DCREG_DBI_CONFIG_DBI_TYPE_TYPE_AFIXED_E                            0x0
#define   DCREG_DBI_CONFIG_DBI_TYPE_TYPE_ACLOCK_E                            0x1
#define   DCREG_DBI_CONFIG_DBI_TYPE_TYPE_B                                   0x2
#define   DCREG_DBI_CONFIG_DBI_TYPE_TYPE_C                                   0x3




#define dcregDbiIfResetRegAddrs                                           0x0524
#define DCREG_DBI_IF_RESET_Address                                       0x01490
#define DCREG_DBI_IF_RESET_MSB                                                15
#define DCREG_DBI_IF_RESET_LSB                                                 1
#define DCREG_DBI_IF_RESET_BLK                                                 1
#define DCREG_DBI_IF_RESET_Count                                               2
#define DCREG_DBI_IF_RESET_FieldMask                                  0x00000001
#define DCREG_DBI_IF_RESET_ReadMask                                   0x00000000
#define DCREG_DBI_IF_RESET_WriteMask                                  0x00000001
#define DCREG_DBI_IF_RESET_ResetValue                                 0x00000000

#define DCREG_DBI_IF_RESET_DBI_IF_LEVEL_RESET                                0:0
#define DCREG_DBI_IF_RESET_DBI_IF_LEVEL_RESET_End                              0
#define DCREG_DBI_IF_RESET_DBI_IF_LEVEL_RESET_Start                            0
#define DCREG_DBI_IF_RESET_DBI_IF_LEVEL_RESET_Type                           U01
#define   DCREG_DBI_IF_RESET_DBI_IF_LEVEL_RESET_RESET                        0x1




#define dcregDbiWrChar1RegAddrs                                           0x0526
#define DCREG_DBI_WR_CHAR1_Address                                       0x01498
#define DCREG_DBI_WR_CHAR1_MSB                                                15
#define DCREG_DBI_WR_CHAR1_LSB                                                 1
#define DCREG_DBI_WR_CHAR1_BLK                                                 1
#define DCREG_DBI_WR_CHAR1_Count                                               2
#define DCREG_DBI_WR_CHAR1_FieldMask                                  0x0000FFFF
#define DCREG_DBI_WR_CHAR1_ReadMask                                   0x0000FFFF
#define DCREG_DBI_WR_CHAR1_WriteMask                                  0x0000FFFF
#define DCREG_DBI_WR_CHAR1_ResetValue                                 0x00000000

#define DCREG_DBI_WR_CHAR1_DBI_WR_CS_ASSERT                                15:12
#define DCREG_DBI_WR_CHAR1_DBI_WR_CS_ASSERT_End                               15
#define DCREG_DBI_WR_CHAR1_DBI_WR_CS_ASSERT_Start                             12
#define DCREG_DBI_WR_CHAR1_DBI_WR_CS_ASSERT_Type                             U04

#define DCREG_DBI_WR_CHAR1_DBI_WR_EOR_WR_ASSERT                             11:8
#define DCREG_DBI_WR_CHAR1_DBI_WR_EOR_WR_ASSERT_End                           11
#define DCREG_DBI_WR_CHAR1_DBI_WR_EOR_WR_ASSERT_Start                          8
#define DCREG_DBI_WR_CHAR1_DBI_WR_EOR_WR_ASSERT_Type                         U04

#define DCREG_DBI_WR_CHAR1_DBI_WR_PERIOD                                     7:0
#define DCREG_DBI_WR_CHAR1_DBI_WR_PERIOD_End                                   7
#define DCREG_DBI_WR_CHAR1_DBI_WR_PERIOD_Start                                 0
#define DCREG_DBI_WR_CHAR1_DBI_WR_PERIOD_Type                                U08




#define dcregDbiWrChar2RegAddrs                                           0x0528
#define DCREG_DBI_WR_CHAR2_Address                                       0x014A0
#define DCREG_DBI_WR_CHAR2_MSB                                                15
#define DCREG_DBI_WR_CHAR2_LSB                                                 1
#define DCREG_DBI_WR_CHAR2_BLK                                                 1
#define DCREG_DBI_WR_CHAR2_Count                                               2
#define DCREG_DBI_WR_CHAR2_FieldMask                                  0x0000FFFF
#define DCREG_DBI_WR_CHAR2_ReadMask                                   0x0000FFFF
#define DCREG_DBI_WR_CHAR2_WriteMask                                  0x0000FFFF
#define DCREG_DBI_WR_CHAR2_ResetValue                                 0x00000000

#define DCREG_DBI_WR_CHAR2_DBI_WR_CS_DE_ASRT                                15:8
#define DCREG_DBI_WR_CHAR2_DBI_WR_CS_DE_ASRT_End                              15
#define DCREG_DBI_WR_CHAR2_DBI_WR_CS_DE_ASRT_Start                             8
#define DCREG_DBI_WR_CHAR2_DBI_WR_CS_DE_ASRT_Type                            U08

#define DCREG_DBI_WR_CHAR2_DBI_WR_EOR_WR_DE_ASRT                             7:0
#define DCREG_DBI_WR_CHAR2_DBI_WR_EOR_WR_DE_ASRT_End                           7
#define DCREG_DBI_WR_CHAR2_DBI_WR_EOR_WR_DE_ASRT_Start                         0
#define DCREG_DBI_WR_CHAR2_DBI_WR_EOR_WR_DE_ASRT_Type                        U08




#define dcregDbiCmdRegAddrs                                               0x052A
#define DCREG_DBI_CMD_Address                                            0x014A8
#define DCREG_DBI_CMD_MSB                                                     15
#define DCREG_DBI_CMD_LSB                                                      1
#define DCREG_DBI_CMD_BLK                                                      1
#define DCREG_DBI_CMD_Count                                                    2
#define DCREG_DBI_CMD_FieldMask                                       0xC000FFFF
#define DCREG_DBI_CMD_ReadMask                                        0x00000000
#define DCREG_DBI_CMD_WriteMask                                       0xC000FFFF
#define DCREG_DBI_CMD_ResetValue                                      0x00000000


#define DCREG_DBI_CMD_DBI_COMMAND_FLAG                                     31:30
#define DCREG_DBI_CMD_DBI_COMMAND_FLAG_End                                    31
#define DCREG_DBI_CMD_DBI_COMMAND_FLAG_Start                                  30
#define DCREG_DBI_CMD_DBI_COMMAND_FLAG_Type                                  U02
#define   DCREG_DBI_CMD_DBI_COMMAND_FLAG_ADDRESS                             0x0
#define   DCREG_DBI_CMD_DBI_COMMAND_FLAG_WRITE_MEM_START                     0x1
#define   DCREG_DBI_CMD_DBI_COMMAND_FLAG_PARAMETER_OR_DATA                   0x2
#define   DCREG_DBI_CMD_DBI_COMMAND_FLAG_READ                                0x3


#define DCREG_DBI_CMD_DBI_COMMAND_WORD                                      15:0
#define DCREG_DBI_CMD_DBI_COMMAND_WORD_End                                    15
#define DCREG_DBI_CMD_DBI_COMMAND_WORD_Start                                   0
#define DCREG_DBI_CMD_DBI_COMMAND_WORD_Type                                  U16




#define dcregGeneralConfigRegAddrs                                        0x052C
#define DCREG_GENERAL_CONFIG_Address                                     0x014B0
#define DCREG_GENERAL_CONFIG_MSB                                              15
#define DCREG_GENERAL_CONFIG_LSB                                               1
#define DCREG_GENERAL_CONFIG_BLK                                               1
#define DCREG_GENERAL_CONFIG_Count                                             2
#define DCREG_GENERAL_CONFIG_FieldMask                                0x0000000F
#define DCREG_GENERAL_CONFIG_ReadMask                                 0x0000000F
#define DCREG_GENERAL_CONFIG_WriteMask                                0x0000000F
#define DCREG_GENERAL_CONFIG_ResetValue                               0x00000000


#define DCREG_GENERAL_CONFIG_ENDIAN_CONTROL                                  1:0
#define DCREG_GENERAL_CONFIG_ENDIAN_CONTROL_End                                1
#define DCREG_GENERAL_CONFIG_ENDIAN_CONTROL_Start                              0
#define DCREG_GENERAL_CONFIG_ENDIAN_CONTROL_Type                             U02
#define   DCREG_GENERAL_CONFIG_ENDIAN_CONTROL_NO_SWAP                        0x0
#define   DCREG_GENERAL_CONFIG_ENDIAN_CONTROL_SWAP_WORD                      0x1
#define   DCREG_GENERAL_CONFIG_ENDIAN_CONTROL_SWAP_DWORD                     0x2
#define   DCREG_GENERAL_CONFIG_ENDIAN_CONTROL_SWAP_DDWORD                    0x3


#define DCREG_GENERAL_CONFIG_STALL_OUTPUT_WHEN_UNDERFLOW                     2:2
#define DCREG_GENERAL_CONFIG_STALL_OUTPUT_WHEN_UNDERFLOW_End                   2
#define DCREG_GENERAL_CONFIG_STALL_OUTPUT_WHEN_UNDERFLOW_Start                 2
#define DCREG_GENERAL_CONFIG_STALL_OUTPUT_WHEN_UNDERFLOW_Type                U01
#define   DCREG_GENERAL_CONFIG_STALL_OUTPUT_WHEN_UNDERFLOW_DISABLED          0x0
#define   DCREG_GENERAL_CONFIG_STALL_OUTPUT_WHEN_UNDERFLOW_ENABLED           0x1


#define DCREG_GENERAL_CONFIG_DISABLE_IDLE                                    3:3
#define DCREG_GENERAL_CONFIG_DISABLE_IDLE_End                                  3
#define DCREG_GENERAL_CONFIG_DISABLE_IDLE_Start                                3
#define DCREG_GENERAL_CONFIG_DISABLE_IDLE_Type                               U01
#define   DCREG_GENERAL_CONFIG_DISABLE_IDLE_DISABLED                         0x0
#define   DCREG_GENERAL_CONFIG_DISABLE_IDLE_ENABLED                          0x1



#define dcregDpiConfigRegAddrs                                            0x052E
#define DCREG_DPI_CONFIG_Address                                         0x014B8
#define DCREG_DPI_CONFIG_MSB                                                  15
#define DCREG_DPI_CONFIG_LSB                                                   1
#define DCREG_DPI_CONFIG_BLK                                                   1
#define DCREG_DPI_CONFIG_Count                                                 2
#define DCREG_DPI_CONFIG_FieldMask                                    0x00000007
#define DCREG_DPI_CONFIG_ReadMask                                     0x00000007
#define DCREG_DPI_CONFIG_WriteMask                                    0x00000007
#define DCREG_DPI_CONFIG_ResetValue                                   0x00000000

#define DCREG_DPI_CONFIG_DPI_DATA_FORMAT                                     2:0
#define DCREG_DPI_CONFIG_DPI_DATA_FORMAT_End                                   2
#define DCREG_DPI_CONFIG_DPI_DATA_FORMAT_Start                                 0
#define DCREG_DPI_CONFIG_DPI_DATA_FORMAT_Type                                U03
#define   DCREG_DPI_CONFIG_DPI_DATA_FORMAT_D16CFG1                           0x0
#define   DCREG_DPI_CONFIG_DPI_DATA_FORMAT_D16CFG2                           0x1
#define   DCREG_DPI_CONFIG_DPI_DATA_FORMAT_D16CFG3                           0x2
#define   DCREG_DPI_CONFIG_DPI_DATA_FORMAT_D18CFG1                           0x3
#define   DCREG_DPI_CONFIG_DPI_DATA_FORMAT_D18CFG2                           0x4
#define   DCREG_DPI_CONFIG_DPI_DATA_FORMAT_D24                               0x5
#define   DCREG_DPI_CONFIG_DPI_DATA_FORMAT_D30                               0x6




#define dcregDbiTypecCfgRegAddrs                                          0x0530
#define DCREG_DBI_TYPEC_CFG_Address                                      0x014C0
#define DCREG_DBI_TYPEC_CFG_MSB                                               15
#define DCREG_DBI_TYPEC_CFG_LSB                                                1
#define DCREG_DBI_TYPEC_CFG_BLK                                                1
#define DCREG_DBI_TYPEC_CFG_Count                                              2
#define DCREG_DBI_TYPEC_CFG_FieldMask                                 0x001FFFFF
#define DCREG_DBI_TYPEC_CFG_ReadMask                                  0x001FFFFF
#define DCREG_DBI_TYPEC_CFG_WriteMask                                 0x001FFFFF
#define DCREG_DBI_TYPEC_CFG_ResetValue                                0x00000000

#define DCREG_DBI_TYPEC_CFG_SCL_SEL                                        20:20
#define DCREG_DBI_TYPEC_CFG_SCL_SEL_End                                       20
#define DCREG_DBI_TYPEC_CFG_SCL_SEL_Start                                     20
#define DCREG_DBI_TYPEC_CFG_SCL_SEL_Type                                     U01
#define   DCREG_DBI_TYPEC_CFG_SCL_SEL_DIVIDED_SDA_CLK                        0x0
#define   DCREG_DBI_TYPEC_CFG_SCL_SEL_SDA_CLK                                0x1

#define DCREG_DBI_TYPEC_CFG_SCL_TWRH                                       19:12
#define DCREG_DBI_TYPEC_CFG_SCL_TWRH_End                                      19
#define DCREG_DBI_TYPEC_CFG_SCL_TWRH_Start                                    12
#define DCREG_DBI_TYPEC_CFG_SCL_TWRH_Type                                    U08

#define DCREG_DBI_TYPEC_CFG_SCL_TWRL                                        11:4
#define DCREG_DBI_TYPEC_CFG_SCL_TWRL_End                                      11
#define DCREG_DBI_TYPEC_CFG_SCL_TWRL_Start                                     4
#define DCREG_DBI_TYPEC_CFG_SCL_TWRL_Type                                    U08

#define DCREG_DBI_TYPEC_CFG_TAS                                              3:0
#define DCREG_DBI_TYPEC_CFG_TAS_End                                            3
#define DCREG_DBI_TYPEC_CFG_TAS_Start                                          0
#define DCREG_DBI_TYPEC_CFG_TAS_Type                                         U04

#define dcregDCStatusRegAddrs                                             0x0532
#define DCREG_DC_STATUS_Address                                          0x014C8
#define DCREG_DC_STATUS_MSB                                                   15
#define DCREG_DC_STATUS_LSB                                                    1
#define DCREG_DC_STATUS_BLK                                                    1
#define DCREG_DC_STATUS_Count                                                  2
#define DCREG_DC_STATUS_FieldMask                                     0x00000001
#define DCREG_DC_STATUS_ReadMask                                      0x00000001
#define DCREG_DC_STATUS_WriteMask                                     0x00000000
#define DCREG_DC_STATUS_ResetValue                                    0x00000000


#define DCREG_DC_STATUS_DBI_TYPEC_FIFO_FULL                                  0:0
#define DCREG_DC_STATUS_DBI_TYPEC_FIFO_FULL_End                                0
#define DCREG_DC_STATUS_DBI_TYPEC_FIFO_FULL_Start                              0
#define DCREG_DC_STATUS_DBI_TYPEC_FIFO_FULL_Type                             U01

#define dcregDebugCounterSelectRegAddrs                                   0x0534
#define DCREG_DEBUG_COUNTER_SELECT_Address                               0x014D0
#define DCREG_DEBUG_COUNTER_SELECT_MSB                                        15
#define DCREG_DEBUG_COUNTER_SELECT_LSB                                         1
#define DCREG_DEBUG_COUNTER_SELECT_BLK                                         1
#define DCREG_DEBUG_COUNTER_SELECT_Count                                       2
#define DCREG_DEBUG_COUNTER_SELECT_FieldMask                          0x000000FF
#define DCREG_DEBUG_COUNTER_SELECT_ReadMask                           0x000000FF
#define DCREG_DEBUG_COUNTER_SELECT_WriteMask                          0x000000FF
#define DCREG_DEBUG_COUNTER_SELECT_ResetValue                         0x00000000

#define DCREG_DEBUG_COUNTER_SELECT_SELECT                                    7:0
#define DCREG_DEBUG_COUNTER_SELECT_SELECT_End                                  7
#define DCREG_DEBUG_COUNTER_SELECT_SELECT_Start                                0
#define DCREG_DEBUG_COUNTER_SELECT_SELECT_Type                               U08
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_AXI_VIDEO_RD_REQ_CNT      0x00
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_AXI_VIDEO_RD_LAST_CNT     0x01
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_AXI_VIDEO_REQ_BURST_CNT   0x02
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_AXI_VIDEO_RD_BURST_CUNT   0x03
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_PIXEL_CNT                 0x04
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_FRAME_CNT                 0x05
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_INPUT_DBI_CMD_CNT         0x06
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_OUTPUT_DBI_CMD_CNT        0x07
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS0                  0x08
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_AXI_OVERLAY0_RD_REQ_CNT   0x09
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_AXI_OVERLAY0_RD_LAST_CNT  0x0A
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_AXI_OVERLAY0_REQ_BURST_CNT 0x0B
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_TOTAL_AXI_OVERLAY0_RD_BURST_CUNT 0x0C
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_FREE_POOL         0x0D
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_INFOBUF_RD        0x0E
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_INFOBUF_WR0       0x0F
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_INFOBUF_WR1       0x10
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_INFOBUF_WR2       0x11
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_INFOBUF_WR3       0x12
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_OVERLAY0_FREE_POOL 0x13
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_OVERLAY0_INFOBUF_RD 0x14
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_OVERLAY0_INFOBUF_WR0 0x15
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_OVERLAY0_INFOBUF_WR1 0x16
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_OVERLAY0_INFOBUF_WR2 0x17
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_DEBUG_SIGNALS_OVERLAY0_INFOBUF_WR3 0x18
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_OVERLAY_BLEND_DEBUGSIGNALS      0x19
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_CURSOR_BLEND_DEBUGSIGNALS       0x1A
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_SCALER_DEBUGSIGNALS             0x1B
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_VIDEO_WALKER_DEBUGSIGNALS_1     0x1C
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_VIDEO_WALKER_DEBUGSIGNALS_2     0x1D
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_VIDEO_WALKER_DEBUGSIGNALS_3     0x1E
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_OVERLAY_WALKER_DEBUGSIGNALS_1   0x1F
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_OVERLAY_WALKER_DEBUGSIGNALS_2   0x20
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_OVERLAY_WALKER_DEBUGSIGNALS_3   0x21
#define   DCREG_DEBUG_COUNTER_SELECT_SELECT_RESET_ALL_DEBUG_COUNTERS        0xFF

#define dcregDebugCounterValueRegAddrs                                    0x0536
#define DCREG_DEBUG_COUNTER_VALUE_Address                                0x014D8
#define DCREG_DEBUG_COUNTER_VALUE_MSB                                         15
#define DCREG_DEBUG_COUNTER_VALUE_LSB                                          1
#define DCREG_DEBUG_COUNTER_VALUE_BLK                                          1
#define DCREG_DEBUG_COUNTER_VALUE_Count                                        2
#define DCREG_DEBUG_COUNTER_VALUE_FieldMask                           0xFFFFFFFF
#define DCREG_DEBUG_COUNTER_VALUE_ReadMask                            0xFFFFFFFF
#define DCREG_DEBUG_COUNTER_VALUE_WriteMask                           0x00000000
#define DCREG_DEBUG_COUNTER_VALUE_ResetValue                          0x00000000


#define DCREG_DEBUG_COUNTER_VALUE_VALUE                                     31:0
#define DCREG_DEBUG_COUNTER_VALUE_VALUE_End                                   31
#define DCREG_DEBUG_COUNTER_VALUE_VALUE_Start                                  0
#define DCREG_DEBUG_COUNTER_VALUE_VALUE_Type                                 U32

#define dcregDebugComposeRegAddrs                                         0x0538
#define DCREG_DEBUG_COMPOSE_Address                                      0x014E0
#define DCREG_DEBUG_COMPOSE_MSB                                               15
#define DCREG_DEBUG_COMPOSE_LSB                                                1
#define DCREG_DEBUG_COMPOSE_BLK                                                1
#define DCREG_DEBUG_COMPOSE_Count                                              2
#define DCREG_DEBUG_COMPOSE_FieldMask                                 0x00000006
#define DCREG_DEBUG_COMPOSE_ReadMask                                  0x00000000
#define DCREG_DEBUG_COMPOSE_WriteMask                                 0x00000006
#define DCREG_DEBUG_COMPOSE_ResetValue                                0x00000000

#define DCREG_DEBUG_COMPOSE_TRIGGER                                          1:1
#define DCREG_DEBUG_COMPOSE_TRIGGER_End                                        1
#define DCREG_DEBUG_COMPOSE_TRIGGER_Start                                      1
#define DCREG_DEBUG_COMPOSE_TRIGGER_Type                                     U01

#define DCREG_DEBUG_COMPOSE_CLEAR_MPU_INTF_COUNTER                           2:2
#define DCREG_DEBUG_COMPOSE_CLEAR_MPU_INTF_COUNTER_End                         2
#define DCREG_DEBUG_COMPOSE_CLEAR_MPU_INTF_COUNTER_Start                       2
#define DCREG_DEBUG_COMPOSE_CLEAR_MPU_INTF_COUNTER_Type                      U01



#define dcregMemDestAddressRegAddrs                                       0x053A
#define DCREG_MEM_DEST_ADDRESS_Address                                   0x014E8
#define DCREG_MEM_DEST_ADDRESS_MSB                                            15
#define DCREG_MEM_DEST_ADDRESS_LSB                                             1
#define DCREG_MEM_DEST_ADDRESS_BLK                                             1
#define DCREG_MEM_DEST_ADDRESS_Count                                           2
#define DCREG_MEM_DEST_ADDRESS_FieldMask                              0xFFFFFFFF
#define DCREG_MEM_DEST_ADDRESS_ReadMask                               0xFFFFFFFF
#define DCREG_MEM_DEST_ADDRESS_WriteMask                              0xFFFFFFFF
#define DCREG_MEM_DEST_ADDRESS_ResetValue                             0x00000000

#define DCREG_MEM_DEST_ADDRESS_ADDRESS                                      31:0
#define DCREG_MEM_DEST_ADDRESS_ADDRESS_End                                    31
#define DCREG_MEM_DEST_ADDRESS_ADDRESS_Start                                   0
#define DCREG_MEM_DEST_ADDRESS_ADDRESS_Type                                  U32



#define dcregPanelDestAddressRegAddrs                                     0x053C
#define DCREG_PANEL_DEST_ADDRESS_Address                                 0x014F0
#define DCREG_PANEL_DEST_ADDRESS_MSB                                          15
#define DCREG_PANEL_DEST_ADDRESS_LSB                                           1
#define DCREG_PANEL_DEST_ADDRESS_BLK                                           1
#define DCREG_PANEL_DEST_ADDRESS_Count                                         2
#define DCREG_PANEL_DEST_ADDRESS_FieldMask                            0xFFFFFFFF
#define DCREG_PANEL_DEST_ADDRESS_ReadMask                             0xFFFFFFFF
#define DCREG_PANEL_DEST_ADDRESS_WriteMask                            0xFFFFFFFF
#define DCREG_PANEL_DEST_ADDRESS_ResetValue                           0x00000000

#define DCREG_PANEL_DEST_ADDRESS_ADDRESS                                    31:0
#define DCREG_PANEL_DEST_ADDRESS_ADDRESS_End                                  31
#define DCREG_PANEL_DEST_ADDRESS_ADDRESS_Start                                 0
#define DCREG_PANEL_DEST_ADDRESS_ADDRESS_Type                                U32




#define dcregDestConfigRegAddrs                                           0x053E
#define DCREG_DEST_CONFIG_Address                                        0x014F8
#define DCREG_DEST_CONFIG_MSB                                                 15
#define DCREG_DEST_CONFIG_LSB                                                  1
#define DCREG_DEST_CONFIG_BLK                                                  1
#define DCREG_DEST_CONFIG_Count                                                2
#define DCREG_DEST_CONFIG_FieldMask                                   0x0003FFFF
#define DCREG_DEST_CONFIG_ReadMask                                    0x0003FFFF
#define DCREG_DEST_CONFIG_WriteMask                                   0x0003FFFF
#define DCREG_DEST_CONFIG_ResetValue                                  0x00000000


#define DCREG_DEST_CONFIG_FORMAT                                            15:0
#define DCREG_DEST_CONFIG_FORMAT_End                                          15
#define DCREG_DEST_CONFIG_FORMAT_Start                                         0
#define DCREG_DEST_CONFIG_FORMAT_Type                                        U16
#define   DCREG_DEST_CONFIG_FORMAT_X4R4G4B4                               0x0000
#define   DCREG_DEST_CONFIG_FORMAT_A4R4G4B4                               0x0001
#define   DCREG_DEST_CONFIG_FORMAT_X1R5G5B5                               0x0002
#define   DCREG_DEST_CONFIG_FORMAT_A1R5G5B5                               0x0003
#define   DCREG_DEST_CONFIG_FORMAT_R5G6B5                                 0x0004
#define   DCREG_DEST_CONFIG_FORMAT_X8R8G8B8                               0x0005
#define   DCREG_DEST_CONFIG_FORMAT_A8R8G8B8                               0x0006
#define   DCREG_DEST_CONFIG_FORMAT_YUY2                                   0x0007
#define   DCREG_DEST_CONFIG_FORMAT_UYVY                                   0x0008
#define   DCREG_DEST_CONFIG_FORMAT_INDEX8                                 0x0009
#define   DCREG_DEST_CONFIG_FORMAT_MONOCHROME                             0x000A
#define   DCREG_DEST_CONFIG_FORMAT_AYUV                                   0x000B
#define   DCREG_DEST_CONFIG_FORMAT_RGB888_PLANAR                          0x000C
#define   DCREG_DEST_CONFIG_FORMAT_RGB888_PACKED                          0x000D
#define   DCREG_DEST_CONFIG_FORMAT_EXTENSION                              0x000E
#define   DCREG_DEST_CONFIG_FORMAT_YV12                                   0x000F
#define   DCREG_DEST_CONFIG_FORMAT_A8                                     0x0010
#define   DCREG_DEST_CONFIG_FORMAT_NV12                                   0x0011
#define   DCREG_DEST_CONFIG_FORMAT_NV16                                   0x0012
#define   DCREG_DEST_CONFIG_FORMAT_RG16                                   0x0013
#define   DCREG_DEST_CONFIG_FORMAT_R8                                     0x0014
#define   DCREG_DEST_CONFIG_FORMAT_NV12_10BIT                             0x0015
#define   DCREG_DEST_CONFIG_FORMAT_A2R10G10B10                            0x0016
#define   DCREG_DEST_CONFIG_FORMAT_NV16_10BIT                             0x0017
#define   DCREG_DEST_CONFIG_FORMAT_INDEX1                                 0x0018
#define   DCREG_DEST_CONFIG_FORMAT_INDEX2                                 0x0019
#define   DCREG_DEST_CONFIG_FORMAT_INDEX4                                 0x001A
#define   DCREG_DEST_CONFIG_FORMAT_P010                                   0x001B
#define   DCREG_DEST_CONFIG_FORMAT_NV12_10BIT_L1                          0x001C
#define   DCREG_DEST_CONFIG_FORMAT_NV16_10BIT_L1                          0x001D
#define   DCREG_DEST_CONFIG_FORMAT_I010                                   0x001E

#define DCREG_DEST_CONFIG_ENABLE                                           16:16
#define DCREG_DEST_CONFIG_ENABLE_End                                          16
#define DCREG_DEST_CONFIG_ENABLE_Start                                        16
#define DCREG_DEST_CONFIG_ENABLE_Type                                        U01
#define   DCREG_DEST_CONFIG_ENABLE_DISABLE                                   0x0
#define   DCREG_DEST_CONFIG_ENABLE_ENABLE                                    0x1


#define DCREG_DEST_CONFIG_INCLUDE_POST_PROCESS                             17:17
#define DCREG_DEST_CONFIG_INCLUDE_POST_PROCESS_End                            17
#define DCREG_DEST_CONFIG_INCLUDE_POST_PROCESS_Start                          17
#define DCREG_DEST_CONFIG_INCLUDE_POST_PROCESS_Type                          U01
#define   DCREG_DEST_CONFIG_INCLUDE_POST_PROCESS_DISABLE                     0x0
#define   DCREG_DEST_CONFIG_INCLUDE_POST_PROCESS_ENABLE                      0x1



#define dcregDestStrideRegAddrs                                           0x0540
#define DCREG_DEST_STRIDE_Address                                        0x01500
#define DCREG_DEST_STRIDE_MSB                                                 15
#define DCREG_DEST_STRIDE_LSB                                                  1
#define DCREG_DEST_STRIDE_BLK                                                  1
#define DCREG_DEST_STRIDE_Count                                                2
#define DCREG_DEST_STRIDE_FieldMask                                   0x0003FFFF
#define DCREG_DEST_STRIDE_ReadMask                                    0x0003FFFF
#define DCREG_DEST_STRIDE_WriteMask                                   0x0003FFFF
#define DCREG_DEST_STRIDE_ResetValue                                  0x00000000


#define DCREG_DEST_STRIDE_STRIDE                                            17:0
#define DCREG_DEST_STRIDE_STRIDE_End                                          17
#define DCREG_DEST_STRIDE_STRIDE_Start                                         0
#define DCREG_DEST_STRIDE_STRIDE_Type                                        U18



#define dcregFrameBufferColorKeyRegAddrs                                  0x0542
#define DCREG_FRAME_BUFFER_COLOR_KEY_Address                             0x01508
#define DCREG_FRAME_BUFFER_COLOR_KEY_MSB                                      15
#define DCREG_FRAME_BUFFER_COLOR_KEY_LSB                                       1
#define DCREG_FRAME_BUFFER_COLOR_KEY_BLK                                       1
#define DCREG_FRAME_BUFFER_COLOR_KEY_Count                                     2
#define DCREG_FRAME_BUFFER_COLOR_KEY_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_BUFFER_COLOR_KEY_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_BUFFER_COLOR_KEY_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_BUFFER_COLOR_KEY_ResetValue                       0x00000000

#define DCREG_FRAME_BUFFER_COLOR_KEY_BLUE                                    7:0
#define DCREG_FRAME_BUFFER_COLOR_KEY_BLUE_End                                  7
#define DCREG_FRAME_BUFFER_COLOR_KEY_BLUE_Start                                0
#define DCREG_FRAME_BUFFER_COLOR_KEY_BLUE_Type                               U08

#define DCREG_FRAME_BUFFER_COLOR_KEY_GREEN                                  15:8
#define DCREG_FRAME_BUFFER_COLOR_KEY_GREEN_End                                15
#define DCREG_FRAME_BUFFER_COLOR_KEY_GREEN_Start                               8
#define DCREG_FRAME_BUFFER_COLOR_KEY_GREEN_Type                              U08

#define DCREG_FRAME_BUFFER_COLOR_KEY_RED                                   23:16
#define DCREG_FRAME_BUFFER_COLOR_KEY_RED_End                                  23
#define DCREG_FRAME_BUFFER_COLOR_KEY_RED_Start                                16
#define DCREG_FRAME_BUFFER_COLOR_KEY_RED_Type                                U08

#define DCREG_FRAME_BUFFER_COLOR_KEY_ALPHA                                 31:24
#define DCREG_FRAME_BUFFER_COLOR_KEY_ALPHA_End                                31
#define DCREG_FRAME_BUFFER_COLOR_KEY_ALPHA_Start                              24
#define DCREG_FRAME_BUFFER_COLOR_KEY_ALPHA_Type                              U08



#define dcregFrameBufferColorKeyHighRegAddrs                              0x0544
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_Address                        0x01510
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_MSB                                 15
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_LSB                                  1
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_BLK                                  1
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_Count                                2
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_FieldMask                   0xFFFFFFFF
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_ReadMask                    0xFFFFFFFF
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_WriteMask                   0xFFFFFFFF
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_ResetValue                  0x00000000

#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_BLUE                               7:0
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_BLUE_End                             7
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_BLUE_Start                           0
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_BLUE_Type                          U08

#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_GREEN                             15:8
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_GREEN_End                           15
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_GREEN_Start                          8
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_GREEN_Type                         U08

#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_RED                              23:16
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_RED_End                             23
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_RED_Start                           16
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_RED_Type                           U08

#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_ALPHA                            31:24
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_ALPHA_End                           31
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_ALPHA_Start                         24
#define DCREG_FRAME_BUFFER_COLOR_KEY_HIGH_ALPHA_Type                         U08



#define dcregFrameBufferConfigRegAddrs                                    0x0546
#define DCREG_FRAME_BUFFER_CONFIG_Address                                0x01518
#define DCREG_FRAME_BUFFER_CONFIG_MSB                                         15
#define DCREG_FRAME_BUFFER_CONFIG_LSB                                          1
#define DCREG_FRAME_BUFFER_CONFIG_BLK                                          1
#define DCREG_FRAME_BUFFER_CONFIG_Count                                        2
#define DCREG_FRAME_BUFFER_CONFIG_FieldMask                           0xFFFFFFFF
#define DCREG_FRAME_BUFFER_CONFIG_ReadMask                            0xFFFFFFEF
#define DCREG_FRAME_BUFFER_CONFIG_WriteMask                           0xFFFFFF9F
#define DCREG_FRAME_BUFFER_CONFIG_ResetValue                          0x00000000

#define DCREG_FRAME_BUFFER_CONFIG_OUTPUT                                     0:0
#define DCREG_FRAME_BUFFER_CONFIG_OUTPUT_End                                   0
#define DCREG_FRAME_BUFFER_CONFIG_OUTPUT_Start                                 0
#define DCREG_FRAME_BUFFER_CONFIG_OUTPUT_Type                                U01
#define   DCREG_FRAME_BUFFER_CONFIG_OUTPUT_DISABLED                          0x0
#define   DCREG_FRAME_BUFFER_CONFIG_OUTPUT_ENABLED                           0x1

#define DCREG_FRAME_BUFFER_CONFIG_SWITCHPANEL                                1:1
#define DCREG_FRAME_BUFFER_CONFIG_SWITCHPANEL_End                              1
#define DCREG_FRAME_BUFFER_CONFIG_SWITCHPANEL_Start                            1
#define DCREG_FRAME_BUFFER_CONFIG_SWITCHPANEL_Type                           U01
#define   DCREG_FRAME_BUFFER_CONFIG_SWITCHPANEL_DISABLED                     0x0
#define   DCREG_FRAME_BUFFER_CONFIG_SWITCHPANEL_ENABLED                      0x1

#define DCREG_FRAME_BUFFER_CONFIG_GAMMA                                      2:2
#define DCREG_FRAME_BUFFER_CONFIG_GAMMA_End                                    2
#define DCREG_FRAME_BUFFER_CONFIG_GAMMA_Start                                  2
#define DCREG_FRAME_BUFFER_CONFIG_GAMMA_Type                                 U01
#define   DCREG_FRAME_BUFFER_CONFIG_GAMMA_DISABLED                           0x0
#define   DCREG_FRAME_BUFFER_CONFIG_GAMMA_ENABLED                            0x1

#define DCREG_FRAME_BUFFER_CONFIG_VALID                                      3:3
#define DCREG_FRAME_BUFFER_CONFIG_VALID_End                                    3
#define DCREG_FRAME_BUFFER_CONFIG_VALID_Start                                  3
#define DCREG_FRAME_BUFFER_CONFIG_VALID_Type                                 U01
#define   DCREG_FRAME_BUFFER_CONFIG_VALID_WORKING                            0x0
#define   DCREG_FRAME_BUFFER_CONFIG_VALID_PENDING                            0x1

#define DCREG_FRAME_BUFFER_CONFIG_RESET                                      4:4
#define DCREG_FRAME_BUFFER_CONFIG_RESET_End                                    4
#define DCREG_FRAME_BUFFER_CONFIG_RESET_Start                                  4
#define DCREG_FRAME_BUFFER_CONFIG_RESET_Type                                 U01
#define   DCREG_FRAME_BUFFER_CONFIG_RESET_RESET                              0x1

#define DCREG_FRAME_BUFFER_CONFIG_UNDERFLOW                                  5:5
#define DCREG_FRAME_BUFFER_CONFIG_UNDERFLOW_End                                5
#define DCREG_FRAME_BUFFER_CONFIG_UNDERFLOW_Start                              5
#define DCREG_FRAME_BUFFER_CONFIG_UNDERFLOW_Type                             U01
#define   DCREG_FRAME_BUFFER_CONFIG_UNDERFLOW_NO                             0x0
#define   DCREG_FRAME_BUFFER_CONFIG_UNDERFLOW_YES                            0x1

#define DCREG_FRAME_BUFFER_CONFIG_FLIP_IN_PROGRESS                           6:6
#define DCREG_FRAME_BUFFER_CONFIG_FLIP_IN_PROGRESS_End                         6
#define DCREG_FRAME_BUFFER_CONFIG_FLIP_IN_PROGRESS_Start                       6
#define DCREG_FRAME_BUFFER_CONFIG_FLIP_IN_PROGRESS_Type                      U01
#define   DCREG_FRAME_BUFFER_CONFIG_FLIP_IN_PROGRESS_NO                      0x0
#define   DCREG_FRAME_BUFFER_CONFIG_FLIP_IN_PROGRESS_YES                     0x1


#define DCREG_FRAME_BUFFER_CONFIG_DTRC                                       7:7
#define DCREG_FRAME_BUFFER_CONFIG_DTRC_End                                     7
#define DCREG_FRAME_BUFFER_CONFIG_DTRC_Start                                   7
#define DCREG_FRAME_BUFFER_CONFIG_DTRC_Type                                  U01
#define   DCREG_FRAME_BUFFER_CONFIG_DTRC_DISABLED                            0x0
#define   DCREG_FRAME_BUFFER_CONFIG_DTRC_ENABLED                             0x1

#define DCREG_FRAME_BUFFER_CONFIG_CLEAR                                      8:8
#define DCREG_FRAME_BUFFER_CONFIG_CLEAR_End                                    8
#define DCREG_FRAME_BUFFER_CONFIG_CLEAR_Start                                  8
#define DCREG_FRAME_BUFFER_CONFIG_CLEAR_Type                                 U01
#define   DCREG_FRAME_BUFFER_CONFIG_CLEAR_DISABLED                           0x0
#define   DCREG_FRAME_BUFFER_CONFIG_CLEAR_ENABLED                            0x1


#define DCREG_FRAME_BUFFER_CONFIG_TRANSPARENCY                              10:9
#define DCREG_FRAME_BUFFER_CONFIG_TRANSPARENCY_End                            10
#define DCREG_FRAME_BUFFER_CONFIG_TRANSPARENCY_Start                           9
#define DCREG_FRAME_BUFFER_CONFIG_TRANSPARENCY_Type                          U02
#define   DCREG_FRAME_BUFFER_CONFIG_TRANSPARENCY_OPAQUE                      0x0
#define   DCREG_FRAME_BUFFER_CONFIG_TRANSPARENCY_MASK                        0x1
#define   DCREG_FRAME_BUFFER_CONFIG_TRANSPARENCY_KEY                         0x2

#define DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE                                13:11
#define DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_End                               13
#define DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_Start                             11
#define DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_Type                             U03
#define   DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_ROT0                           0x0
#define   DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_FLIP_X                         0x1
#define   DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_FLIP_Y                         0x2
#define   DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_FLIP_XY                        0x3
#define   DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_ROT90                          0x4
#define   DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_ROT180                         0x5
#define   DCREG_FRAME_BUFFER_CONFIG_ROT_ANGLE_ROT270                         0x6


#define DCREG_FRAME_BUFFER_CONFIG_YUV                                      16:14
#define DCREG_FRAME_BUFFER_CONFIG_YUV_End                                     16
#define DCREG_FRAME_BUFFER_CONFIG_YUV_Start                                   14
#define DCREG_FRAME_BUFFER_CONFIG_YUV_Type                                   U03
#define   DCREG_FRAME_BUFFER_CONFIG_YUV_709                                  0x1
#define   DCREG_FRAME_BUFFER_CONFIG_YUV_2020                                 0x3

#define DCREG_FRAME_BUFFER_CONFIG_TILE_MODE                                21:17
#define DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_End                               21
#define DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_Start                             17
#define DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_Type                             U05
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_LINEAR                        0x00
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILED4X4                      0x01
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_SUPER_TILED_XMAJOR            0x02
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_SUPER_TILED_YMAJOR            0x03
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_MODE8X8                  0x04
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_MODE1                    0x05
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_MODE2                    0x06
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_MODE8X4                  0x07
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_MODE4                    0x08
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_MODE5                    0x09
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_MODE6                    0x0A
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_SUPER_TILED_XMAJOR8X4         0x0B
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_SUPER_TILED_YMAJOR4X8         0x0C
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_Y                        0x0D
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILE_MODE7                    0x0E
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILED128X1                    0x0F
#define   DCREG_FRAME_BUFFER_CONFIG_TILE_MODE_TILED256X1                    0x10

#define DCREG_FRAME_BUFFER_CONFIG_SCALE                                    22:22
#define DCREG_FRAME_BUFFER_CONFIG_SCALE_End                                   22
#define DCREG_FRAME_BUFFER_CONFIG_SCALE_Start                                 22
#define DCREG_FRAME_BUFFER_CONFIG_SCALE_Type                                 U01
#define   DCREG_FRAME_BUFFER_CONFIG_SCALE_DISABLE                            0x0
#define   DCREG_FRAME_BUFFER_CONFIG_SCALE_ENABLE                             0x1

#define DCREG_FRAME_BUFFER_CONFIG_SWIZZLE                                  24:23
#define DCREG_FRAME_BUFFER_CONFIG_SWIZZLE_End                                 24
#define DCREG_FRAME_BUFFER_CONFIG_SWIZZLE_Start                               23
#define DCREG_FRAME_BUFFER_CONFIG_SWIZZLE_Type                               U02
#define   DCREG_FRAME_BUFFER_CONFIG_SWIZZLE_ARGB                             0x0
#define   DCREG_FRAME_BUFFER_CONFIG_SWIZZLE_RGBA                             0x1
#define   DCREG_FRAME_BUFFER_CONFIG_SWIZZLE_ABGR                             0x2
#define   DCREG_FRAME_BUFFER_CONFIG_SWIZZLE_BGRA                             0x3

#define DCREG_FRAME_BUFFER_CONFIG_UV_SWIZZLE                               25:25
#define DCREG_FRAME_BUFFER_CONFIG_UV_SWIZZLE_End                              25
#define DCREG_FRAME_BUFFER_CONFIG_UV_SWIZZLE_Start                            25
#define DCREG_FRAME_BUFFER_CONFIG_UV_SWIZZLE_Type                            U01


#define DCREG_FRAME_BUFFER_CONFIG_FORMAT                                   31:26
#define DCREG_FRAME_BUFFER_CONFIG_FORMAT_End                                  31
#define DCREG_FRAME_BUFFER_CONFIG_FORMAT_Start                                26
#define DCREG_FRAME_BUFFER_CONFIG_FORMAT_Type                                U06
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_X4R4G4B4                         0x00
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_A4R4G4B4                         0x01
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_X1R5G5B5                         0x02
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_A1R5G5B5                         0x03
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_R5G6B5                           0x04
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_X8R8G8B8                         0x05
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_A8R8G8B8                         0x06
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_YUY2                             0x07
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_UYVY                             0x08
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_INDEX8                           0x09
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_MONOCHROME                       0x0A
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_AYUV                             0x0B
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_RGB888_PLANAR                    0x0C
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_RGB888_PACKED                    0x0D
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_EXTENSION                        0x0E
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_YV12                             0x0F
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_A8                               0x10
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_NV12                             0x11
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_NV16                             0x12
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_RG16                             0x13
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_R8                               0x14
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_NV12_10BIT                       0x15
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_A2R10G10B10                      0x16
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_NV16_10BIT                       0x17
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_INDEX1                           0x18
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_INDEX2                           0x19
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_INDEX4                           0x1A
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_P010                             0x1B
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_NV12_10BIT_L1                    0x1C
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_NV16_10BIT_L1                    0x1D
#define   DCREG_FRAME_BUFFER_CONFIG_FORMAT_I010                             0x1E



#define dcregFrameBufferScaleConfigRegAddrs                               0x0548
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_Address                          0x01520
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_MSB                                   15
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_LSB                                    1
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_BLK                                    1
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_Count                                  2
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_FieldMask                     0x000000FF
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_ReadMask                      0x000000FF
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_WriteMask                     0x000000FF
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_ResetValue                    0x00000000

#define DCREG_FRAME_BUFFER_SCALE_CONFIG_FILTER_TAP                           3:0
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_FILTER_TAP_End                         3
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_FILTER_TAP_Start                       0
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_FILTER_TAP_Type                      U04

#define DCREG_FRAME_BUFFER_SCALE_CONFIG_HORIZONTAL_FILTER_TAP                7:4
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_HORIZONTAL_FILTER_TAP_End              7
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_HORIZONTAL_FILTER_TAP_Start            4
#define DCREG_FRAME_BUFFER_SCALE_CONFIG_HORIZONTAL_FILTER_TAP_Type           U04



#define dcregFrameBufferBGColorRegAddrs                                   0x054A
#define DCREG_FRAME_BUFFER_BG_COLOR_Address                              0x01528
#define DCREG_FRAME_BUFFER_BG_COLOR_MSB                                       15
#define DCREG_FRAME_BUFFER_BG_COLOR_LSB                                        1
#define DCREG_FRAME_BUFFER_BG_COLOR_BLK                                        1
#define DCREG_FRAME_BUFFER_BG_COLOR_Count                                      2
#define DCREG_FRAME_BUFFER_BG_COLOR_FieldMask                         0xFFFFFFFF
#define DCREG_FRAME_BUFFER_BG_COLOR_ReadMask                          0xFFFFFFFF
#define DCREG_FRAME_BUFFER_BG_COLOR_WriteMask                         0xFFFFFFFF
#define DCREG_FRAME_BUFFER_BG_COLOR_ResetValue                        0x00000000

#define DCREG_FRAME_BUFFER_BG_COLOR_BLUE                                     7:0
#define DCREG_FRAME_BUFFER_BG_COLOR_BLUE_End                                   7
#define DCREG_FRAME_BUFFER_BG_COLOR_BLUE_Start                                 0
#define DCREG_FRAME_BUFFER_BG_COLOR_BLUE_Type                                U08

#define DCREG_FRAME_BUFFER_BG_COLOR_GREEN                                   15:8
#define DCREG_FRAME_BUFFER_BG_COLOR_GREEN_End                                 15
#define DCREG_FRAME_BUFFER_BG_COLOR_GREEN_Start                                8
#define DCREG_FRAME_BUFFER_BG_COLOR_GREEN_Type                               U08

#define DCREG_FRAME_BUFFER_BG_COLOR_RED                                    23:16
#define DCREG_FRAME_BUFFER_BG_COLOR_RED_End                                   23
#define DCREG_FRAME_BUFFER_BG_COLOR_RED_Start                                 16
#define DCREG_FRAME_BUFFER_BG_COLOR_RED_Type                                 U08

#define DCREG_FRAME_BUFFER_BG_COLOR_ALPHA                                  31:24
#define DCREG_FRAME_BUFFER_BG_COLOR_ALPHA_End                                 31
#define DCREG_FRAME_BUFFER_BG_COLOR_ALPHA_Start                               24
#define DCREG_FRAME_BUFFER_BG_COLOR_ALPHA_Type                               U08



#define dcregFrameBufferUPlanarAddressRegAddrs                            0x054C
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_Address                       0x01530
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_MSB                                15
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_LSB                                 1
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_BLK                                 1
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_Count                               2
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_FieldMask                  0xFFFFFFFF
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_ReadMask                   0xFFFFFFFF
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_WriteMask                  0xFFFFFFFF
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_ResetValue                 0x00000000

#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_ADDRESS                          31:0
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_ADDRESS_End                        31
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_ADDRESS_Start                       0
#define DCREG_FRAME_BUFFER_UPLANAR_ADDRESS_ADDRESS_Type                      U32



#define dcregFrameBufferVPlanarAddressRegAddrs                            0x054E
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_Address                       0x01538
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_MSB                                15
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_LSB                                 1
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_BLK                                 1
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_Count                               2
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_FieldMask                  0xFFFFFFFF
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_ReadMask                   0xFFFFFFFF
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_WriteMask                  0xFFFFFFFF
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_ResetValue                 0x00000000

#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_ADDRESS                          31:0
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_ADDRESS_End                        31
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_ADDRESS_Start                       0
#define DCREG_FRAME_BUFFER_VPLANAR_ADDRESS_ADDRESS_Type                      U32




#define dcregOverlayConfigRegAddrs                                        0x0550
#define DCREG_OVERLAY_CONFIG_Address                                     0x01540
#define DCREG_OVERLAY_CONFIG_MSB                                              15
#define DCREG_OVERLAY_CONFIG_LSB                                               4
#define DCREG_OVERLAY_CONFIG_BLK                                               4
#define DCREG_OVERLAY_CONFIG_Count                                            16
#define DCREG_OVERLAY_CONFIG_FieldMask                                0x7FBFFFFF
#define DCREG_OVERLAY_CONFIG_ReadMask                                 0x7FBFFFFF
#define DCREG_OVERLAY_CONFIG_WriteMask                                0x7F3FFFFF
#define DCREG_OVERLAY_CONFIG_ResetValue                               0x00000000


#define DCREG_OVERLAY_CONFIG_TRANSPARENCY                                    1:0
#define DCREG_OVERLAY_CONFIG_TRANSPARENCY_End                                  1
#define DCREG_OVERLAY_CONFIG_TRANSPARENCY_Start                                0
#define DCREG_OVERLAY_CONFIG_TRANSPARENCY_Type                               U02
#define   DCREG_OVERLAY_CONFIG_TRANSPARENCY_OPAQUE                           0x0
#define   DCREG_OVERLAY_CONFIG_TRANSPARENCY_MASK                             0x1
#define   DCREG_OVERLAY_CONFIG_TRANSPARENCY_KEY                              0x2

#define DCREG_OVERLAY_CONFIG_ROT_ANGLE                                       4:2
#define DCREG_OVERLAY_CONFIG_ROT_ANGLE_End                                     4
#define DCREG_OVERLAY_CONFIG_ROT_ANGLE_Start                                   2
#define DCREG_OVERLAY_CONFIG_ROT_ANGLE_Type                                  U03
#define   DCREG_OVERLAY_CONFIG_ROT_ANGLE_ROT0                                0x0
#define   DCREG_OVERLAY_CONFIG_ROT_ANGLE_FLIP_X                              0x1
#define   DCREG_OVERLAY_CONFIG_ROT_ANGLE_FLIP_Y                              0x2
#define   DCREG_OVERLAY_CONFIG_ROT_ANGLE_FLIP_XY                             0x3
#define   DCREG_OVERLAY_CONFIG_ROT_ANGLE_ROT90                               0x4
#define   DCREG_OVERLAY_CONFIG_ROT_ANGLE_ROT180                              0x5
#define   DCREG_OVERLAY_CONFIG_ROT_ANGLE_ROT270                              0x6


#define DCREG_OVERLAY_CONFIG_YUV                                             7:5
#define DCREG_OVERLAY_CONFIG_YUV_End                                           7
#define DCREG_OVERLAY_CONFIG_YUV_Start                                         5
#define DCREG_OVERLAY_CONFIG_YUV_Type                                        U03
#define   DCREG_OVERLAY_CONFIG_YUV_709                                       0x1
#define   DCREG_OVERLAY_CONFIG_YUV_2020                                      0x3

#define DCREG_OVERLAY_CONFIG_TILE_MODE                                      12:8
#define DCREG_OVERLAY_CONFIG_TILE_MODE_End                                    12
#define DCREG_OVERLAY_CONFIG_TILE_MODE_Start                                   8
#define DCREG_OVERLAY_CONFIG_TILE_MODE_Type                                  U05
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_LINEAR                             0x00
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILED4X4                           0x01
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_SUPER_TILED_XMAJOR                 0x02
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_SUPER_TILED_YMAJOR                 0x03
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_MODE8X8                       0x04
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_MODE1                         0x05
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_MODE2                         0x06
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_MODE8X4                       0x07
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_MODE4                         0x08
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_MODE5                         0x09
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_MODE6                         0x0A
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_SUPER_TILED_XMAJOR8X4              0x0B
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_SUPER_TILED_YMAJOR4X8              0x0C
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_Y                             0x0D
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILE_MODE7                         0x0E
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILED128X1                         0x0F
#define   DCREG_OVERLAY_CONFIG_TILE_MODE_TILED256X1                         0x10

#define DCREG_OVERLAY_CONFIG_SWIZZLE                                       14:13
#define DCREG_OVERLAY_CONFIG_SWIZZLE_End                                      14
#define DCREG_OVERLAY_CONFIG_SWIZZLE_Start                                    13
#define DCREG_OVERLAY_CONFIG_SWIZZLE_Type                                    U02
#define   DCREG_OVERLAY_CONFIG_SWIZZLE_ARGB                                  0x0
#define   DCREG_OVERLAY_CONFIG_SWIZZLE_RGBA                                  0x1
#define   DCREG_OVERLAY_CONFIG_SWIZZLE_ABGR                                  0x2
#define   DCREG_OVERLAY_CONFIG_SWIZZLE_BGRA                                  0x3

#define DCREG_OVERLAY_CONFIG_UV_SWIZZLE                                    15:15
#define DCREG_OVERLAY_CONFIG_UV_SWIZZLE_End                                   15
#define DCREG_OVERLAY_CONFIG_UV_SWIZZLE_Start                                 15
#define DCREG_OVERLAY_CONFIG_UV_SWIZZLE_Type                                 U01


#define DCREG_OVERLAY_CONFIG_FORMAT                                        21:16
#define DCREG_OVERLAY_CONFIG_FORMAT_End                                       21
#define DCREG_OVERLAY_CONFIG_FORMAT_Start                                     16
#define DCREG_OVERLAY_CONFIG_FORMAT_Type                                     U06
#define   DCREG_OVERLAY_CONFIG_FORMAT_X4R4G4B4                              0x00
#define   DCREG_OVERLAY_CONFIG_FORMAT_A4R4G4B4                              0x01
#define   DCREG_OVERLAY_CONFIG_FORMAT_X1R5G5B5                              0x02
#define   DCREG_OVERLAY_CONFIG_FORMAT_A1R5G5B5                              0x03
#define   DCREG_OVERLAY_CONFIG_FORMAT_R5G6B5                                0x04
#define   DCREG_OVERLAY_CONFIG_FORMAT_X8R8G8B8                              0x05
#define   DCREG_OVERLAY_CONFIG_FORMAT_A8R8G8B8                              0x06
#define   DCREG_OVERLAY_CONFIG_FORMAT_YUY2                                  0x07
#define   DCREG_OVERLAY_CONFIG_FORMAT_UYVY                                  0x08
#define   DCREG_OVERLAY_CONFIG_FORMAT_INDEX8                                0x09
#define   DCREG_OVERLAY_CONFIG_FORMAT_MONOCHROME                            0x0A
#define   DCREG_OVERLAY_CONFIG_FORMAT_AYUV                                  0x0B
#define   DCREG_OVERLAY_CONFIG_FORMAT_RGB888_PLANAR                         0x0C
#define   DCREG_OVERLAY_CONFIG_FORMAT_RGB888_PACKED                         0x0D
#define   DCREG_OVERLAY_CONFIG_FORMAT_EXTENSION                             0x0E
#define   DCREG_OVERLAY_CONFIG_FORMAT_YV12                                  0x0F
#define   DCREG_OVERLAY_CONFIG_FORMAT_A8                                    0x10
#define   DCREG_OVERLAY_CONFIG_FORMAT_NV12                                  0x11
#define   DCREG_OVERLAY_CONFIG_FORMAT_NV16                                  0x12
#define   DCREG_OVERLAY_CONFIG_FORMAT_RG16                                  0x13
#define   DCREG_OVERLAY_CONFIG_FORMAT_R8                                    0x14
#define   DCREG_OVERLAY_CONFIG_FORMAT_NV12_10BIT                            0x15
#define   DCREG_OVERLAY_CONFIG_FORMAT_A2R10G10B10                           0x16
#define   DCREG_OVERLAY_CONFIG_FORMAT_NV16_10BIT                            0x17
#define   DCREG_OVERLAY_CONFIG_FORMAT_INDEX1                                0x18
#define   DCREG_OVERLAY_CONFIG_FORMAT_INDEX2                                0x19
#define   DCREG_OVERLAY_CONFIG_FORMAT_INDEX4                                0x1A
#define   DCREG_OVERLAY_CONFIG_FORMAT_P010                                  0x1B
#define   DCREG_OVERLAY_CONFIG_FORMAT_NV12_10BIT_L1                         0x1C
#define   DCREG_OVERLAY_CONFIG_FORMAT_NV16_10BIT_L1                         0x1D
#define   DCREG_OVERLAY_CONFIG_FORMAT_I010                                  0x1E

#define DCREG_OVERLAY_CONFIG_UNDERFLOW                                     23:23
#define DCREG_OVERLAY_CONFIG_UNDERFLOW_End                                    23
#define DCREG_OVERLAY_CONFIG_UNDERFLOW_Start                                  23
#define DCREG_OVERLAY_CONFIG_UNDERFLOW_Type                                  U01
#define   DCREG_OVERLAY_CONFIG_UNDERFLOW_NO                                  0x0
#define   DCREG_OVERLAY_CONFIG_UNDERFLOW_YES                                 0x1


#define DCREG_OVERLAY_CONFIG_ENABLE                                        24:24
#define DCREG_OVERLAY_CONFIG_ENABLE_End                                       24
#define DCREG_OVERLAY_CONFIG_ENABLE_Start                                     24
#define DCREG_OVERLAY_CONFIG_ENABLE_Type                                     U01
#define   DCREG_OVERLAY_CONFIG_ENABLE_DISABLE                                0x0
#define   DCREG_OVERLAY_CONFIG_ENABLE_ENABLE                                 0x1

#define DCREG_OVERLAY_CONFIG_CLEAR                                         25:25
#define DCREG_OVERLAY_CONFIG_CLEAR_End                                        25
#define DCREG_OVERLAY_CONFIG_CLEAR_Start                                      25
#define DCREG_OVERLAY_CONFIG_CLEAR_Type                                      U01
#define   DCREG_OVERLAY_CONFIG_CLEAR_DISABLED                                0x0
#define   DCREG_OVERLAY_CONFIG_CLEAR_ENABLED                                 0x1


#define DCREG_OVERLAY_CONFIG_DTRC                                          26:26
#define DCREG_OVERLAY_CONFIG_DTRC_End                                         26
#define DCREG_OVERLAY_CONFIG_DTRC_Start                                       26
#define DCREG_OVERLAY_CONFIG_DTRC_Type                                       U01
#define   DCREG_OVERLAY_CONFIG_DTRC_DISABLED                                 0x0
#define   DCREG_OVERLAY_CONFIG_DTRC_ENABLED                                  0x1


#define DCREG_OVERLAY_CONFIG_COMPRESSED                                    27:27
#define DCREG_OVERLAY_CONFIG_COMPRESSED_End                                   27
#define DCREG_OVERLAY_CONFIG_COMPRESSED_Start                                 27
#define DCREG_OVERLAY_CONFIG_COMPRESSED_Type                                 U01
#define   DCREG_OVERLAY_CONFIG_COMPRESSED_UNCOMPRESSED                       0x0
#define   DCREG_OVERLAY_CONFIG_COMPRESSED_COMPRESSED                         0x1


#define DCREG_OVERLAY_CONFIG_DE_GAMMA                                      28:28
#define DCREG_OVERLAY_CONFIG_DE_GAMMA_End                                     28
#define DCREG_OVERLAY_CONFIG_DE_GAMMA_Start                                   28
#define DCREG_OVERLAY_CONFIG_DE_GAMMA_Type                                   U01
#define   DCREG_OVERLAY_CONFIG_DE_GAMMA_DISABLED                             0x0
#define   DCREG_OVERLAY_CONFIG_DE_GAMMA_ENABLED                              0x1


#define DCREG_OVERLAY_CONFIG_RGB_TO_RGB                                    29:29
#define DCREG_OVERLAY_CONFIG_RGB_TO_RGB_End                                   29
#define DCREG_OVERLAY_CONFIG_RGB_TO_RGB_Start                                 29
#define DCREG_OVERLAY_CONFIG_RGB_TO_RGB_Type                                 U01
#define   DCREG_OVERLAY_CONFIG_RGB_TO_RGB_DISABLED                           0x0
#define   DCREG_OVERLAY_CONFIG_RGB_TO_RGB_ENABLED                            0x1


#define DCREG_OVERLAY_CONFIG_YUV_CLAMP                                     30:30
#define DCREG_OVERLAY_CONFIG_YUV_CLAMP_End                                    30
#define DCREG_OVERLAY_CONFIG_YUV_CLAMP_Start                                  30
#define DCREG_OVERLAY_CONFIG_YUV_CLAMP_Type                                  U01
#define   DCREG_OVERLAY_CONFIG_YUV_CLAMP_DISABLED                            0x0
#define   DCREG_OVERLAY_CONFIG_YUV_CLAMP_ENABLED                             0x1




#define dcregOverlayAlphaBlendConfigRegAddrs                              0x0560
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_Address                         0x01580
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_MSB                                  15
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_LSB                                   4
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_BLK                                   4
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_Count                                16
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_FieldMask                    0x0000FFFB
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_ReadMask                     0x0000FFFB
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_WriteMask                    0x0000FFFB
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_ResetValue                   0x00000000

#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_MODE                      0:0
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_MODE_End                    0
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_MODE_Start                  0
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_MODE_Type                 U01
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_MODE_NORMAL             0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_MODE_INVERSED           0x1

#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DISABLE_ALPHA_BLEND                 1:1
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DISABLE_ALPHA_BLEND_End               1
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DISABLE_ALPHA_BLEND_Start             1
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DISABLE_ALPHA_BLEND_Type            U01
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DISABLE_ALPHA_BLEND_DISABLED      0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DISABLE_ALPHA_BLEND_ENABLED       0x1

#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_GLOBAL_ALPHA_MODE               4:3
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_GLOBAL_ALPHA_MODE_End             4
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_GLOBAL_ALPHA_MODE_Start           3
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_GLOBAL_ALPHA_MODE_Type          U02
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_GLOBAL_ALPHA_MODE_NORMAL      0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_GLOBAL_ALPHA_MODE_GLOBAL      0x1
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_GLOBAL_ALPHA_MODE_SCALED      0x2

#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE                   7:5
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_End                 7
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_Start               5
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_Type              U03
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_ZERO            0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_ONE             0x1
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_NORMAL          0x2
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_INVERSED        0x3
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_COLOR           0x4
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_COLOR_INVERSED  0x5
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_SATURATED_ALPHA 0x6
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_BLENDING_MODE_SATURATED_DEST_ALPHA 0x7


#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_FACTOR                    8:8
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_FACTOR_End                  8
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_FACTOR_Start                8
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_FACTOR_Type               U01
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_FACTOR_DISABLED         0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_SRC_ALPHA_FACTOR_ENABLED          0x1

#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_MODE                      9:9
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_MODE_End                    9
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_MODE_Start                  9
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_MODE_Type                 U01
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_MODE_NORMAL             0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_MODE_INVERSED           0x1

#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_GLOBAL_ALPHA_MODE             11:10
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_GLOBAL_ALPHA_MODE_End            11
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_GLOBAL_ALPHA_MODE_Start          10
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_GLOBAL_ALPHA_MODE_Type          U02
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_GLOBAL_ALPHA_MODE_NORMAL      0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_GLOBAL_ALPHA_MODE_GLOBAL      0x1
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_GLOBAL_ALPHA_MODE_SCALED      0x2

#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE                 14:12
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_End                14
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_Start              12
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_Type              U03
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_ZERO            0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_ONE             0x1
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_NORMAL          0x2
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_INVERSED        0x3
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_COLOR           0x4
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_COLOR_INVERSED  0x5
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_SATURATED_ALPHA 0x6
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_BLENDING_MODE_SATURATED_DEST_ALPHA 0x7


#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_FACTOR                  15:15
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_FACTOR_End                 15
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_FACTOR_Start               15
#define DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_FACTOR_Type               U01
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_FACTOR_DISABLED         0x0
#define   DCREG_OVERLAY_ALPHA_BLEND_CONFIG_DST_ALPHA_FACTOR_ENABLED          0x1




#define dcregOverlayAddressRegAddrs                                       0x0570
#define DCREG_OVERLAY_ADDRESS_Address                                    0x015C0
#define DCREG_OVERLAY_ADDRESS_MSB                                             15
#define DCREG_OVERLAY_ADDRESS_LSB                                              4
#define DCREG_OVERLAY_ADDRESS_BLK                                              4
#define DCREG_OVERLAY_ADDRESS_Count                                           16
#define DCREG_OVERLAY_ADDRESS_FieldMask                               0xFFFFFFFF
#define DCREG_OVERLAY_ADDRESS_ReadMask                                0xFFFFFFFF
#define DCREG_OVERLAY_ADDRESS_WriteMask                               0xFFFFFFFF
#define DCREG_OVERLAY_ADDRESS_ResetValue                              0x00000000

#define DCREG_OVERLAY_ADDRESS_ADDRESS                                       31:0
#define DCREG_OVERLAY_ADDRESS_ADDRESS_End                                     31
#define DCREG_OVERLAY_ADDRESS_ADDRESS_Start                                    0
#define DCREG_OVERLAY_ADDRESS_ADDRESS_Type                                   U32




#define dcregOverlayStrideRegAddrs                                        0x0580
#define DCREG_OVERLAY_STRIDE_Address                                     0x01600
#define DCREG_OVERLAY_STRIDE_MSB                                              15
#define DCREG_OVERLAY_STRIDE_LSB                                               4
#define DCREG_OVERLAY_STRIDE_BLK                                               4
#define DCREG_OVERLAY_STRIDE_Count                                            16
#define DCREG_OVERLAY_STRIDE_FieldMask                                0x0003FFFF
#define DCREG_OVERLAY_STRIDE_ReadMask                                 0x0003FFFF
#define DCREG_OVERLAY_STRIDE_WriteMask                                0x0003FFFF
#define DCREG_OVERLAY_STRIDE_ResetValue                               0x00000000


#define DCREG_OVERLAY_STRIDE_STRIDE                                         17:0
#define DCREG_OVERLAY_STRIDE_STRIDE_End                                       17
#define DCREG_OVERLAY_STRIDE_STRIDE_Start                                      0
#define DCREG_OVERLAY_STRIDE_STRIDE_Type                                     U18



#define dcregOverlayTLRegAddrs                                            0x0590
#define DCREG_OVERLAY_TL_Address                                         0x01640
#define DCREG_OVERLAY_TL_MSB                                                  15
#define DCREG_OVERLAY_TL_LSB                                                   4
#define DCREG_OVERLAY_TL_BLK                                                   4
#define DCREG_OVERLAY_TL_Count                                                16
#define DCREG_OVERLAY_TL_FieldMask                                    0x3FFFFFFF
#define DCREG_OVERLAY_TL_ReadMask                                     0x3FFFFFFF
#define DCREG_OVERLAY_TL_WriteMask                                    0x3FFFFFFF
#define DCREG_OVERLAY_TL_ResetValue                                   0x00000000


#define DCREG_OVERLAY_TL_X                                                  14:0
#define DCREG_OVERLAY_TL_X_End                                                14
#define DCREG_OVERLAY_TL_X_Start                                               0
#define DCREG_OVERLAY_TL_X_Type                                              U15


#define DCREG_OVERLAY_TL_Y                                                 29:15
#define DCREG_OVERLAY_TL_Y_End                                                29
#define DCREG_OVERLAY_TL_Y_Start                                              15
#define DCREG_OVERLAY_TL_Y_Type                                              U15



#define dcregOverlayBRRegAddrs                                            0x05A0
#define DCREG_OVERLAY_BR_Address                                         0x01680
#define DCREG_OVERLAY_BR_MSB                                                  15
#define DCREG_OVERLAY_BR_LSB                                                   4
#define DCREG_OVERLAY_BR_BLK                                                   4
#define DCREG_OVERLAY_BR_Count                                                16
#define DCREG_OVERLAY_BR_FieldMask                                    0x3FFFFFFF
#define DCREG_OVERLAY_BR_ReadMask                                     0x3FFFFFFF
#define DCREG_OVERLAY_BR_WriteMask                                    0x3FFFFFFF
#define DCREG_OVERLAY_BR_ResetValue                                   0x00000000


#define DCREG_OVERLAY_BR_X                                                  14:0
#define DCREG_OVERLAY_BR_X_End                                                14
#define DCREG_OVERLAY_BR_X_Start                                               0
#define DCREG_OVERLAY_BR_X_Type                                              U15


#define DCREG_OVERLAY_BR_Y                                                 29:15
#define DCREG_OVERLAY_BR_Y_End                                                29
#define DCREG_OVERLAY_BR_Y_Start                                              15
#define DCREG_OVERLAY_BR_Y_Type                                              U15



#define dcregOverlaySrcGlobalColorRegAddrs                                0x05B0
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_Address                           0x016C0
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_MSB                                    15
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_LSB                                     4
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_BLK                                     4
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_Count                                  16
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_ResetValue                     0x00000000

#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_BLUE                                  7:0
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_BLUE_End                                7
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_BLUE_Start                              0
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_BLUE_Type                             U08

#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_GREEN                                15:8
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_GREEN_End                              15
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_GREEN_Start                             8
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_GREEN_Type                            U08

#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_RED                                 23:16
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_RED_End                                23
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_RED_Start                              16
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_RED_Type                              U08

#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_ALPHA                               31:24
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_ALPHA_End                              31
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_ALPHA_Start                            24
#define DCREG_OVERLAY_SRC_GLOBAL_COLOR_ALPHA_Type                            U08



#define dcregOverlayDstGlobalColorRegAddrs                                0x05C0
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_Address                           0x01700
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_MSB                                    15
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_LSB                                     4
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_BLK                                     4
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_Count                                  16
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_ResetValue                     0x00000000

#define DCREG_OVERLAY_DST_GLOBAL_COLOR_BLUE                                  7:0
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_BLUE_End                                7
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_BLUE_Start                              0
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_BLUE_Type                             U08

#define DCREG_OVERLAY_DST_GLOBAL_COLOR_GREEN                                15:8
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_GREEN_End                              15
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_GREEN_Start                             8
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_GREEN_Type                            U08

#define DCREG_OVERLAY_DST_GLOBAL_COLOR_RED                                 23:16
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_RED_End                                23
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_RED_Start                              16
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_RED_Type                              U08

#define DCREG_OVERLAY_DST_GLOBAL_COLOR_ALPHA                               31:24
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_ALPHA_End                              31
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_ALPHA_Start                            24
#define DCREG_OVERLAY_DST_GLOBAL_COLOR_ALPHA_Type                            U08



#define dcregOverlayColorKeyRegAddrs                                      0x05D0
#define DCREG_OVERLAY_COLOR_KEY_Address                                  0x01740
#define DCREG_OVERLAY_COLOR_KEY_MSB                                           15
#define DCREG_OVERLAY_COLOR_KEY_LSB                                            4
#define DCREG_OVERLAY_COLOR_KEY_BLK                                            4
#define DCREG_OVERLAY_COLOR_KEY_Count                                         16
#define DCREG_OVERLAY_COLOR_KEY_FieldMask                             0xFFFFFFFF
#define DCREG_OVERLAY_COLOR_KEY_ReadMask                              0xFFFFFFFF
#define DCREG_OVERLAY_COLOR_KEY_WriteMask                             0xFFFFFFFF
#define DCREG_OVERLAY_COLOR_KEY_ResetValue                            0x00000000

#define DCREG_OVERLAY_COLOR_KEY_BLUE                                         7:0
#define DCREG_OVERLAY_COLOR_KEY_BLUE_End                                       7
#define DCREG_OVERLAY_COLOR_KEY_BLUE_Start                                     0
#define DCREG_OVERLAY_COLOR_KEY_BLUE_Type                                    U08

#define DCREG_OVERLAY_COLOR_KEY_GREEN                                       15:8
#define DCREG_OVERLAY_COLOR_KEY_GREEN_End                                     15
#define DCREG_OVERLAY_COLOR_KEY_GREEN_Start                                    8
#define DCREG_OVERLAY_COLOR_KEY_GREEN_Type                                   U08

#define DCREG_OVERLAY_COLOR_KEY_RED                                        23:16
#define DCREG_OVERLAY_COLOR_KEY_RED_End                                       23
#define DCREG_OVERLAY_COLOR_KEY_RED_Start                                     16
#define DCREG_OVERLAY_COLOR_KEY_RED_Type                                     U08

#define DCREG_OVERLAY_COLOR_KEY_ALPHA                                      31:24
#define DCREG_OVERLAY_COLOR_KEY_ALPHA_End                                     31
#define DCREG_OVERLAY_COLOR_KEY_ALPHA_Start                                   24
#define DCREG_OVERLAY_COLOR_KEY_ALPHA_Type                                   U08



#define dcregOverlayColorKeyHighRegAddrs                                  0x05E0
#define DCREG_OVERLAY_COLOR_KEY_HIGH_Address                             0x01780
#define DCREG_OVERLAY_COLOR_KEY_HIGH_MSB                                      15
#define DCREG_OVERLAY_COLOR_KEY_HIGH_LSB                                       4
#define DCREG_OVERLAY_COLOR_KEY_HIGH_BLK                                       4
#define DCREG_OVERLAY_COLOR_KEY_HIGH_Count                                    16
#define DCREG_OVERLAY_COLOR_KEY_HIGH_FieldMask                        0xFFFFFFFF
#define DCREG_OVERLAY_COLOR_KEY_HIGH_ReadMask                         0xFFFFFFFF
#define DCREG_OVERLAY_COLOR_KEY_HIGH_WriteMask                        0xFFFFFFFF
#define DCREG_OVERLAY_COLOR_KEY_HIGH_ResetValue                       0x00000000

#define DCREG_OVERLAY_COLOR_KEY_HIGH_BLUE                                    7:0
#define DCREG_OVERLAY_COLOR_KEY_HIGH_BLUE_End                                  7
#define DCREG_OVERLAY_COLOR_KEY_HIGH_BLUE_Start                                0
#define DCREG_OVERLAY_COLOR_KEY_HIGH_BLUE_Type                               U08

#define DCREG_OVERLAY_COLOR_KEY_HIGH_GREEN                                  15:8
#define DCREG_OVERLAY_COLOR_KEY_HIGH_GREEN_End                                15
#define DCREG_OVERLAY_COLOR_KEY_HIGH_GREEN_Start                               8
#define DCREG_OVERLAY_COLOR_KEY_HIGH_GREEN_Type                              U08

#define DCREG_OVERLAY_COLOR_KEY_HIGH_RED                                   23:16
#define DCREG_OVERLAY_COLOR_KEY_HIGH_RED_End                                  23
#define DCREG_OVERLAY_COLOR_KEY_HIGH_RED_Start                                16
#define DCREG_OVERLAY_COLOR_KEY_HIGH_RED_Type                                U08

#define DCREG_OVERLAY_COLOR_KEY_HIGH_ALPHA                                 31:24
#define DCREG_OVERLAY_COLOR_KEY_HIGH_ALPHA_End                                31
#define DCREG_OVERLAY_COLOR_KEY_HIGH_ALPHA_Start                              24
#define DCREG_OVERLAY_COLOR_KEY_HIGH_ALPHA_Type                              U08



#define dcregOverlaySizeRegAddrs                                          0x05F0
#define DCREG_OVERLAY_SIZE_Address                                       0x017C0
#define DCREG_OVERLAY_SIZE_MSB                                                15
#define DCREG_OVERLAY_SIZE_LSB                                                 4
#define DCREG_OVERLAY_SIZE_BLK                                                 4
#define DCREG_OVERLAY_SIZE_Count                                              16
#define DCREG_OVERLAY_SIZE_FieldMask                                  0x3FFFFFFF
#define DCREG_OVERLAY_SIZE_ReadMask                                   0x3FFFFFFF
#define DCREG_OVERLAY_SIZE_WriteMask                                  0x3FFFFFFF
#define DCREG_OVERLAY_SIZE_ResetValue                                 0x00000000

#define DCREG_OVERLAY_SIZE_WIDTH                                            14:0
#define DCREG_OVERLAY_SIZE_WIDTH_End                                          14
#define DCREG_OVERLAY_SIZE_WIDTH_Start                                         0
#define DCREG_OVERLAY_SIZE_WIDTH_Type                                        U15

#define DCREG_OVERLAY_SIZE_HEIGHT                                          29:15
#define DCREG_OVERLAY_SIZE_HEIGHT_End                                         29
#define DCREG_OVERLAY_SIZE_HEIGHT_Start                                       15
#define DCREG_OVERLAY_SIZE_HEIGHT_Type                                       U15



#define dcregFrameBufferUStrideRegAddrs                                   0x0600
#define DCREG_FRAME_BUFFER_USTRIDE_Address                               0x01800
#define DCREG_FRAME_BUFFER_USTRIDE_MSB                                        15
#define DCREG_FRAME_BUFFER_USTRIDE_LSB                                         1
#define DCREG_FRAME_BUFFER_USTRIDE_BLK                                         1
#define DCREG_FRAME_BUFFER_USTRIDE_Count                                       2
#define DCREG_FRAME_BUFFER_USTRIDE_FieldMask                          0x0003FFFF
#define DCREG_FRAME_BUFFER_USTRIDE_ReadMask                           0x0003FFFF
#define DCREG_FRAME_BUFFER_USTRIDE_WriteMask                          0x0003FFFF
#define DCREG_FRAME_BUFFER_USTRIDE_ResetValue                         0x00000000


#define DCREG_FRAME_BUFFER_USTRIDE_STRIDE                                   17:0
#define DCREG_FRAME_BUFFER_USTRIDE_STRIDE_End                                 17
#define DCREG_FRAME_BUFFER_USTRIDE_STRIDE_Start                                0
#define DCREG_FRAME_BUFFER_USTRIDE_STRIDE_Type                               U18



#define dcregFrameBufferVStrideRegAddrs                                   0x0602
#define DCREG_FRAME_BUFFER_VSTRIDE_Address                               0x01808
#define DCREG_FRAME_BUFFER_VSTRIDE_MSB                                        15
#define DCREG_FRAME_BUFFER_VSTRIDE_LSB                                         1
#define DCREG_FRAME_BUFFER_VSTRIDE_BLK                                         1
#define DCREG_FRAME_BUFFER_VSTRIDE_Count                                       2
#define DCREG_FRAME_BUFFER_VSTRIDE_FieldMask                          0x0003FFFF
#define DCREG_FRAME_BUFFER_VSTRIDE_ReadMask                           0x0003FFFF
#define DCREG_FRAME_BUFFER_VSTRIDE_WriteMask                          0x0003FFFF
#define DCREG_FRAME_BUFFER_VSTRIDE_ResetValue                         0x00000000


#define DCREG_FRAME_BUFFER_VSTRIDE_STRIDE                                   17:0
#define DCREG_FRAME_BUFFER_VSTRIDE_STRIDE_End                                 17
#define DCREG_FRAME_BUFFER_VSTRIDE_STRIDE_Start                                0
#define DCREG_FRAME_BUFFER_VSTRIDE_STRIDE_Type                               U18



#define dcregFrameBufferSizeRegAddrs                                      0x0604
#define DCREG_FRAME_BUFFER_SIZE_Address                                  0x01810
#define DCREG_FRAME_BUFFER_SIZE_MSB                                           15
#define DCREG_FRAME_BUFFER_SIZE_LSB                                            1
#define DCREG_FRAME_BUFFER_SIZE_BLK                                            1
#define DCREG_FRAME_BUFFER_SIZE_Count                                          2
#define DCREG_FRAME_BUFFER_SIZE_FieldMask                             0x3FFFFFFF
#define DCREG_FRAME_BUFFER_SIZE_ReadMask                              0x3FFFFFFF
#define DCREG_FRAME_BUFFER_SIZE_WriteMask                             0x3FFFFFFF
#define DCREG_FRAME_BUFFER_SIZE_ResetValue                            0x00000000

#define DCREG_FRAME_BUFFER_SIZE_WIDTH                                       14:0
#define DCREG_FRAME_BUFFER_SIZE_WIDTH_End                                     14
#define DCREG_FRAME_BUFFER_SIZE_WIDTH_Start                                    0
#define DCREG_FRAME_BUFFER_SIZE_WIDTH_Type                                   U15

#define DCREG_FRAME_BUFFER_SIZE_HEIGHT                                     29:15
#define DCREG_FRAME_BUFFER_SIZE_HEIGHT_End                                    29
#define DCREG_FRAME_BUFFER_SIZE_HEIGHT_Start                                  15
#define DCREG_FRAME_BUFFER_SIZE_HEIGHT_Type                                  U15



#define dcregIndexColorTableIndexRegAddrs                                 0x0606
#define DCREG_INDEX_COLOR_TABLE_INDEX_Address                            0x01818
#define DCREG_INDEX_COLOR_TABLE_INDEX_MSB                                     15
#define DCREG_INDEX_COLOR_TABLE_INDEX_LSB                                      1
#define DCREG_INDEX_COLOR_TABLE_INDEX_BLK                                      1
#define DCREG_INDEX_COLOR_TABLE_INDEX_Count                                    2
#define DCREG_INDEX_COLOR_TABLE_INDEX_FieldMask                       0x000000FF
#define DCREG_INDEX_COLOR_TABLE_INDEX_ReadMask                        0x00000000
#define DCREG_INDEX_COLOR_TABLE_INDEX_WriteMask                       0x000000FF
#define DCREG_INDEX_COLOR_TABLE_INDEX_ResetValue                      0x00000000


#define DCREG_INDEX_COLOR_TABLE_INDEX_INDEX                                  7:0
#define DCREG_INDEX_COLOR_TABLE_INDEX_INDEX_End                                7
#define DCREG_INDEX_COLOR_TABLE_INDEX_INDEX_Start                              0
#define DCREG_INDEX_COLOR_TABLE_INDEX_INDEX_Type                             U08



#define dcregIndexColorTableDataRegAddrs                                  0x0608
#define DCREG_INDEX_COLOR_TABLE_DATA_Address                             0x01820
#define DCREG_INDEX_COLOR_TABLE_DATA_MSB                                      15
#define DCREG_INDEX_COLOR_TABLE_DATA_LSB                                       1
#define DCREG_INDEX_COLOR_TABLE_DATA_BLK                                       1
#define DCREG_INDEX_COLOR_TABLE_DATA_Count                                     2
#define DCREG_INDEX_COLOR_TABLE_DATA_FieldMask                        0xFFFFFFFF
#define DCREG_INDEX_COLOR_TABLE_DATA_ReadMask                         0x00000000
#define DCREG_INDEX_COLOR_TABLE_DATA_WriteMask                        0xFFFFFFFF
#define DCREG_INDEX_COLOR_TABLE_DATA_ResetValue                       0x00000000

#define DCREG_INDEX_COLOR_TABLE_DATA_BLUE                                    7:0
#define DCREG_INDEX_COLOR_TABLE_DATA_BLUE_End                                  7
#define DCREG_INDEX_COLOR_TABLE_DATA_BLUE_Start                                0
#define DCREG_INDEX_COLOR_TABLE_DATA_BLUE_Type                               U08

#define DCREG_INDEX_COLOR_TABLE_DATA_GREEN                                  15:8
#define DCREG_INDEX_COLOR_TABLE_DATA_GREEN_End                                15
#define DCREG_INDEX_COLOR_TABLE_DATA_GREEN_Start                               8
#define DCREG_INDEX_COLOR_TABLE_DATA_GREEN_Type                              U08

#define DCREG_INDEX_COLOR_TABLE_DATA_RED                                   23:16
#define DCREG_INDEX_COLOR_TABLE_DATA_RED_End                                  23
#define DCREG_INDEX_COLOR_TABLE_DATA_RED_Start                                16
#define DCREG_INDEX_COLOR_TABLE_DATA_RED_Type                                U08

#define DCREG_INDEX_COLOR_TABLE_DATA_ALPHA                                 31:24
#define DCREG_INDEX_COLOR_TABLE_DATA_ALPHA_End                                31
#define DCREG_INDEX_COLOR_TABLE_DATA_ALPHA_Start                              24
#define DCREG_INDEX_COLOR_TABLE_DATA_ALPHA_Type                              U08



#define dcregFrameBufferScaleFactorXRegAddrs                              0x060A
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_Address                        0x01828
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_MSB                                 15
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_LSB                                  1
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_BLK                                  1
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_Count                                2
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_FieldMask                   0x7FFFFFFF
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_ReadMask                    0x7FFFFFFF
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_WriteMask                   0x7FFFFFFF
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_ResetValue                  0x00000000

#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_X                                 30:0
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_X_End                               30
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_X_Start                              0
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_X_X_Type                             U31



#define dcregFrameBufferScaleFactorYRegAddrs                              0x060C
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_Address                        0x01830
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_MSB                                 15
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_LSB                                  1
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_BLK                                  1
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_Count                                2
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_FieldMask                   0x7FFFFFFF
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_ReadMask                    0x7FFFFFFF
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_WriteMask                   0x7FFFFFFF
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_ResetValue                  0x00000000

#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_Y                                 30:0
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_Y_End                               30
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_Y_Start                              0
#define DCREG_FRAME_BUFFER_SCALE_FACTOR_Y_Y_Type                             U31



#define dcregHoriFilterKernelIndexRegAddrs                                0x060E
#define DCREG_HORI_FILTER_KERNEL_INDEX_Address                           0x01838
#define DCREG_HORI_FILTER_KERNEL_INDEX_MSB                                    15
#define DCREG_HORI_FILTER_KERNEL_INDEX_LSB                                     1
#define DCREG_HORI_FILTER_KERNEL_INDEX_BLK                                     1
#define DCREG_HORI_FILTER_KERNEL_INDEX_Count                                   2
#define DCREG_HORI_FILTER_KERNEL_INDEX_FieldMask                      0x000000FF
#define DCREG_HORI_FILTER_KERNEL_INDEX_ReadMask                       0x00000000
#define DCREG_HORI_FILTER_KERNEL_INDEX_WriteMask                      0x000000FF
#define DCREG_HORI_FILTER_KERNEL_INDEX_ResetValue                     0x00000000

#define DCREG_HORI_FILTER_KERNEL_INDEX_INDEX                                 7:0
#define DCREG_HORI_FILTER_KERNEL_INDEX_INDEX_End                               7
#define DCREG_HORI_FILTER_KERNEL_INDEX_INDEX_Start                             0
#define DCREG_HORI_FILTER_KERNEL_INDEX_INDEX_Type                            U08



#define dcregOverlayUPlanarAddressRegAddrs                                0x0610
#define DCREG_OVERLAY_UPLANAR_ADDRESS_Address                            0x01840
#define DCREG_OVERLAY_UPLANAR_ADDRESS_MSB                                     15
#define DCREG_OVERLAY_UPLANAR_ADDRESS_LSB                                      4
#define DCREG_OVERLAY_UPLANAR_ADDRESS_BLK                                      4
#define DCREG_OVERLAY_UPLANAR_ADDRESS_Count                                   16
#define DCREG_OVERLAY_UPLANAR_ADDRESS_FieldMask                       0xFFFFFFFF
#define DCREG_OVERLAY_UPLANAR_ADDRESS_ReadMask                        0xFFFFFFFF
#define DCREG_OVERLAY_UPLANAR_ADDRESS_WriteMask                       0xFFFFFFFF
#define DCREG_OVERLAY_UPLANAR_ADDRESS_ResetValue                      0x00000000

#define DCREG_OVERLAY_UPLANAR_ADDRESS_ADDRESS                               31:0
#define DCREG_OVERLAY_UPLANAR_ADDRESS_ADDRESS_End                             31
#define DCREG_OVERLAY_UPLANAR_ADDRESS_ADDRESS_Start                            0
#define DCREG_OVERLAY_UPLANAR_ADDRESS_ADDRESS_Type                           U32



#define dcregOverlayVPlanarAddressRegAddrs                                0x0620
#define DCREG_OVERLAY_VPLANAR_ADDRESS_Address                            0x01880
#define DCREG_OVERLAY_VPLANAR_ADDRESS_MSB                                     15
#define DCREG_OVERLAY_VPLANAR_ADDRESS_LSB                                      4
#define DCREG_OVERLAY_VPLANAR_ADDRESS_BLK                                      4
#define DCREG_OVERLAY_VPLANAR_ADDRESS_Count                                   16
#define DCREG_OVERLAY_VPLANAR_ADDRESS_FieldMask                       0xFFFFFFFF
#define DCREG_OVERLAY_VPLANAR_ADDRESS_ReadMask                        0xFFFFFFFF
#define DCREG_OVERLAY_VPLANAR_ADDRESS_WriteMask                       0xFFFFFFFF
#define DCREG_OVERLAY_VPLANAR_ADDRESS_ResetValue                      0x00000000

#define DCREG_OVERLAY_VPLANAR_ADDRESS_ADDRESS                               31:0
#define DCREG_OVERLAY_VPLANAR_ADDRESS_ADDRESS_End                             31
#define DCREG_OVERLAY_VPLANAR_ADDRESS_ADDRESS_Start                            0
#define DCREG_OVERLAY_VPLANAR_ADDRESS_ADDRESS_Type                           U32



#define dcregOverlayUStrideRegAddrs                                       0x0630
#define DCREG_OVERLAY_USTRIDE_Address                                    0x018C0
#define DCREG_OVERLAY_USTRIDE_MSB                                             15
#define DCREG_OVERLAY_USTRIDE_LSB                                              4
#define DCREG_OVERLAY_USTRIDE_BLK                                              4
#define DCREG_OVERLAY_USTRIDE_Count                                           16
#define DCREG_OVERLAY_USTRIDE_FieldMask                               0x0003FFFF
#define DCREG_OVERLAY_USTRIDE_ReadMask                                0x0003FFFF
#define DCREG_OVERLAY_USTRIDE_WriteMask                               0x0003FFFF
#define DCREG_OVERLAY_USTRIDE_ResetValue                              0x00000000


#define DCREG_OVERLAY_USTRIDE_STRIDE                                        17:0
#define DCREG_OVERLAY_USTRIDE_STRIDE_End                                      17
#define DCREG_OVERLAY_USTRIDE_STRIDE_Start                                     0
#define DCREG_OVERLAY_USTRIDE_STRIDE_Type                                    U18



#define dcregOverlayVStrideRegAddrs                                       0x0640
#define DCREG_OVERLAY_VSTRIDE_Address                                    0x01900
#define DCREG_OVERLAY_VSTRIDE_MSB                                             15
#define DCREG_OVERLAY_VSTRIDE_LSB                                              4
#define DCREG_OVERLAY_VSTRIDE_BLK                                              4
#define DCREG_OVERLAY_VSTRIDE_Count                                           16
#define DCREG_OVERLAY_VSTRIDE_FieldMask                               0x0003FFFF
#define DCREG_OVERLAY_VSTRIDE_ReadMask                                0x0003FFFF
#define DCREG_OVERLAY_VSTRIDE_WriteMask                               0x0003FFFF
#define DCREG_OVERLAY_VSTRIDE_ResetValue                              0x00000000


#define DCREG_OVERLAY_VSTRIDE_STRIDE                                        17:0
#define DCREG_OVERLAY_VSTRIDE_STRIDE_End                                      17
#define DCREG_OVERLAY_VSTRIDE_STRIDE_Start                                     0
#define DCREG_OVERLAY_VSTRIDE_STRIDE_Type                                    U18



#define dcregOverlayClearValueRegAddrs                                    0x0650
#define DCREG_OVERLAY_CLEAR_VALUE_Address                                0x01940
#define DCREG_OVERLAY_CLEAR_VALUE_MSB                                         15
#define DCREG_OVERLAY_CLEAR_VALUE_LSB                                          4
#define DCREG_OVERLAY_CLEAR_VALUE_BLK                                          4
#define DCREG_OVERLAY_CLEAR_VALUE_Count                                       16
#define DCREG_OVERLAY_CLEAR_VALUE_FieldMask                           0xFFFFFFFF
#define DCREG_OVERLAY_CLEAR_VALUE_ReadMask                            0xFFFFFFFF
#define DCREG_OVERLAY_CLEAR_VALUE_WriteMask                           0xFFFFFFFF
#define DCREG_OVERLAY_CLEAR_VALUE_ResetValue                          0x00000000

#define DCREG_OVERLAY_CLEAR_VALUE_BLUE                                       7:0
#define DCREG_OVERLAY_CLEAR_VALUE_BLUE_End                                     7
#define DCREG_OVERLAY_CLEAR_VALUE_BLUE_Start                                   0
#define DCREG_OVERLAY_CLEAR_VALUE_BLUE_Type                                  U08

#define DCREG_OVERLAY_CLEAR_VALUE_GREEN                                     15:8
#define DCREG_OVERLAY_CLEAR_VALUE_GREEN_End                                   15
#define DCREG_OVERLAY_CLEAR_VALUE_GREEN_Start                                  8
#define DCREG_OVERLAY_CLEAR_VALUE_GREEN_Type                                 U08

#define DCREG_OVERLAY_CLEAR_VALUE_RED                                      23:16
#define DCREG_OVERLAY_CLEAR_VALUE_RED_End                                     23
#define DCREG_OVERLAY_CLEAR_VALUE_RED_Start                                   16
#define DCREG_OVERLAY_CLEAR_VALUE_RED_Type                                   U08

#define DCREG_OVERLAY_CLEAR_VALUE_ALPHA                                    31:24
#define DCREG_OVERLAY_CLEAR_VALUE_ALPHA_End                                   31
#define DCREG_OVERLAY_CLEAR_VALUE_ALPHA_Start                                 24
#define DCREG_OVERLAY_CLEAR_VALUE_ALPHA_Type                                 U08



#define dcregOverlayIndexColorTableIndexRegAddrs                          0x0660
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_Address                    0x01980
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_MSB                             15
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_LSB                              4
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_BLK                              4
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_Count                           16
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_FieldMask               0x000000FF
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_ReadMask                0x00000000
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_WriteMask               0x000000FF
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_ResetValue              0x00000000


#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_INDEX                          7:0
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_INDEX_End                        7
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_INDEX_Start                      0
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_INDEX_INDEX_Type                     U08



#define dcregOverlayIndexColorTableDataRegAddrs                           0x0670
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_Address                     0x019C0
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_MSB                              15
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_LSB                               4
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_BLK                               4
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_Count                            16
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_FieldMask                0xFFFFFFFF
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_ReadMask                 0x00000000
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_WriteMask                0xFFFFFFFF
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_ResetValue               0x00000000

#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_BLUE                            7:0
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_BLUE_End                          7
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_BLUE_Start                        0
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_BLUE_Type                       U08

#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_GREEN                          15:8
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_GREEN_End                        15
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_GREEN_Start                       8
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_GREEN_Type                      U08

#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_RED                           23:16
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_RED_End                          23
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_RED_Start                        16
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_RED_Type                        U08

#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_ALPHA                         31:24
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_ALPHA_End                        31
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_ALPHA_Start                      24
#define DCREG_OVERLAY_INDEX_COLOR_TABLE_DATA_ALPHA_Type                      U08



#define dcregHoriFilterKernelRegAddrs                                     0x0680
#define DCREG_HORI_FILTER_KERNEL_Address                                 0x01A00
#define DCREG_HORI_FILTER_KERNEL_MSB                                          15
#define DCREG_HORI_FILTER_KERNEL_LSB                                           1
#define DCREG_HORI_FILTER_KERNEL_BLK                                           1
#define DCREG_HORI_FILTER_KERNEL_Count                                         2
#define DCREG_HORI_FILTER_KERNEL_FieldMask                            0xFFFFFFFF
#define DCREG_HORI_FILTER_KERNEL_ReadMask                             0x00000000
#define DCREG_HORI_FILTER_KERNEL_WriteMask                            0xFFFFFFFF
#define DCREG_HORI_FILTER_KERNEL_ResetValue                           0x00000000

#define DCREG_HORI_FILTER_KERNEL_COEFFICIENT0                               15:0
#define DCREG_HORI_FILTER_KERNEL_COEFFICIENT0_End                             15
#define DCREG_HORI_FILTER_KERNEL_COEFFICIENT0_Start                            0
#define DCREG_HORI_FILTER_KERNEL_COEFFICIENT0_Type                           U16

#define DCREG_HORI_FILTER_KERNEL_COEFFICIENT1                              31:16
#define DCREG_HORI_FILTER_KERNEL_COEFFICIENT1_End                             31
#define DCREG_HORI_FILTER_KERNEL_COEFFICIENT1_Start                           16
#define DCREG_HORI_FILTER_KERNEL_COEFFICIENT1_Type                           U16



#define dcregVertiFilterKernelIndexRegAddrs                               0x0682
#define DCREG_VERTI_FILTER_KERNEL_INDEX_Address                          0x01A08
#define DCREG_VERTI_FILTER_KERNEL_INDEX_MSB                                   15
#define DCREG_VERTI_FILTER_KERNEL_INDEX_LSB                                    1
#define DCREG_VERTI_FILTER_KERNEL_INDEX_BLK                                    1
#define DCREG_VERTI_FILTER_KERNEL_INDEX_Count                                  2
#define DCREG_VERTI_FILTER_KERNEL_INDEX_FieldMask                     0x000000FF
#define DCREG_VERTI_FILTER_KERNEL_INDEX_ReadMask                      0x00000000
#define DCREG_VERTI_FILTER_KERNEL_INDEX_WriteMask                     0x000000FF
#define DCREG_VERTI_FILTER_KERNEL_INDEX_ResetValue                    0x00000000

#define DCREG_VERTI_FILTER_KERNEL_INDEX_INDEX                                7:0
#define DCREG_VERTI_FILTER_KERNEL_INDEX_INDEX_End                              7
#define DCREG_VERTI_FILTER_KERNEL_INDEX_INDEX_Start                            0
#define DCREG_VERTI_FILTER_KERNEL_INDEX_INDEX_Type                           U08



#define dcregVertiFilterKernelRegAddrs                                    0x0684
#define DCREG_VERTI_FILTER_KERNEL_Address                                0x01A10
#define DCREG_VERTI_FILTER_KERNEL_MSB                                         15
#define DCREG_VERTI_FILTER_KERNEL_LSB                                          1
#define DCREG_VERTI_FILTER_KERNEL_BLK                                          1
#define DCREG_VERTI_FILTER_KERNEL_Count                                        2
#define DCREG_VERTI_FILTER_KERNEL_FieldMask                           0xFFFFFFFF
#define DCREG_VERTI_FILTER_KERNEL_ReadMask                            0x00000000
#define DCREG_VERTI_FILTER_KERNEL_WriteMask                           0xFFFFFFFF
#define DCREG_VERTI_FILTER_KERNEL_ResetValue                          0x00000000

#define DCREG_VERTI_FILTER_KERNEL_COEFFICIENT0                              15:0
#define DCREG_VERTI_FILTER_KERNEL_COEFFICIENT0_End                            15
#define DCREG_VERTI_FILTER_KERNEL_COEFFICIENT0_Start                           0
#define DCREG_VERTI_FILTER_KERNEL_COEFFICIENT0_Type                          U16

#define DCREG_VERTI_FILTER_KERNEL_COEFFICIENT1                             31:16
#define DCREG_VERTI_FILTER_KERNEL_COEFFICIENT1_End                            31
#define DCREG_VERTI_FILTER_KERNEL_COEFFICIENT1_Start                          16
#define DCREG_VERTI_FILTER_KERNEL_COEFFICIENT1_Type                          U16



#define dcregFrameBufferClearValueRegAddrs                                0x0686
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_Address                           0x01A18
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_MSB                                    15
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_LSB                                     1
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_BLK                                     1
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_Count                                   2
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_FieldMask                      0xFFFFFFFF
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_ReadMask                       0xFFFFFFFF
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_WriteMask                      0xFFFFFFFF
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_ResetValue                     0x00000000

#define DCREG_FRAME_BUFFER_CLEAR_VALUE_BLUE                                  7:0
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_BLUE_End                                7
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_BLUE_Start                              0
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_BLUE_Type                             U08

#define DCREG_FRAME_BUFFER_CLEAR_VALUE_GREEN                                15:8
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_GREEN_End                              15
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_GREEN_Start                             8
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_GREEN_Type                            U08

#define DCREG_FRAME_BUFFER_CLEAR_VALUE_RED                                 23:16
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_RED_End                                23
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_RED_Start                              16
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_RED_Type                              U08

#define DCREG_FRAME_BUFFER_CLEAR_VALUE_ALPHA                               31:24
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_ALPHA_End                              31
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_ALPHA_Start                            24
#define DCREG_FRAME_BUFFER_CLEAR_VALUE_ALPHA_Type                            U08



#define dcregFrameBufferInitialOffsetRegAddrs                             0x0688
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_Address                        0x01A20
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_MSB                                 15
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_LSB                                  1
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_BLK                                  1
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_Count                                2
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_FieldMask                   0xFFFFFFFF
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_ReadMask                    0xFFFFFFFF
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_WriteMask                   0xFFFFFFFF
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_ResetValue                  0x00000000

#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_X                                 15:0
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_X_End                               15
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_X_Start                              0
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_X_Type                             U16

#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_Y                                31:16
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_Y_End                               31
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_Y_Start                             16
#define DCREG_FRAME_BUFFER_INITIAL_OFFSET_Y_Type                             U16




#define dcregModuleClockGatingControlRegAddrs                             0x068A
#define DCREG_MODULE_CLOCK_GATING_CONTROL_Address                        0x01A28
#define DCREG_MODULE_CLOCK_GATING_CONTROL_MSB                                 15
#define DCREG_MODULE_CLOCK_GATING_CONTROL_LSB                                  1
#define DCREG_MODULE_CLOCK_GATING_CONTROL_BLK                                  1
#define DCREG_MODULE_CLOCK_GATING_CONTROL_Count                                2
#define DCREG_MODULE_CLOCK_GATING_CONTROL_FieldMask                   0x00000FFF
#define DCREG_MODULE_CLOCK_GATING_CONTROL_ReadMask                    0x00000FFF
#define DCREG_MODULE_CLOCK_GATING_CONTROL_WriteMask                   0x00000FFF
#define DCREG_MODULE_CLOCK_GATING_CONTROL_ResetValue                  0x00000FFF

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_VIDEO  0:0
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_VIDEO_End 0
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_VIDEO_Start 0
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_VIDEO_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY0 1:1
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY0_End 1
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY0_Start 1
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY0_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY1 2:2
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY1_End 2
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY1_Start 2
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY1_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY2 3:3
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY2_End 3
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY2_Start 3
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY2_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY3 4:4
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY3_End 4
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY3_Start 4
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY3_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY4 5:5
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY4_End 5
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY4_Start 5
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY4_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY5 6:6
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY5_End 6
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY5_Start 6
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY5_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY6 7:7
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY6_End 7
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY6_Start 7
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY6_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY7 8:8
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY7_End 8
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY7_Start 8
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY7_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_WB_FIFO 9:9
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_WB_FIFO_End 9
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_WB_FIFO_Start 9
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_WB_FIFO_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_SCALER 10:10
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_SCALER_End 10
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_SCALER_Start 10
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_SCALER_Type U01

#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY0_SCALER 11:11
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY0_SCALER_End 11
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY0_SCALER_Start 11
#define DCREG_MODULE_CLOCK_GATING_CONTROL_DISABLE_MODULE_CLOCK_GATING_OVERLAY0_SCALER_Type U01

#define dcregLatencyCounterRegAddrs                                       0x068C
#define DCREG_LATENCY_COUNTER_Address                                    0x01A30
#define DCREG_LATENCY_COUNTER_MSB                                             15
#define DCREG_LATENCY_COUNTER_LSB                                              1
#define DCREG_LATENCY_COUNTER_BLK                                              1
#define DCREG_LATENCY_COUNTER_Count                                            2
#define DCREG_LATENCY_COUNTER_FieldMask                               0xFFFFFFFF
#define DCREG_LATENCY_COUNTER_ReadMask                                0xFFFFFFFF
#define DCREG_LATENCY_COUNTER_WriteMask                               0xFFFFFFFF
#define DCREG_LATENCY_COUNTER_ResetValue                              0x00000000

#define DCREG_LATENCY_COUNTER_COUNTER                                       31:0
#define DCREG_LATENCY_COUNTER_COUNTER_End                                     31
#define DCREG_LATENCY_COUNTER_COUNTER_Start                                    0
#define DCREG_LATENCY_COUNTER_COUNTER_Type                                   U32

#define dcregQosRegAddrs                                                  0x068E
#define DCREG_QOS_Address                                                0x01A38
#define DCREG_QOS_MSB                                                         15
#define DCREG_QOS_LSB                                                          1
#define DCREG_QOS_BLK                                                          1
#define DCREG_QOS_Count                                                        2
#define DCREG_QOS_FieldMask                                           0x000000FF
#define DCREG_QOS_ReadMask                                            0x000000FF
#define DCREG_QOS_WriteMask                                           0x000000FF
#define DCREG_QOS_ResetValue                                          0x00000000


#define DCREG_QOS_LOW                                                        3:0
#define DCREG_QOS_LOW_End                                                      3
#define DCREG_QOS_LOW_Start                                                    0
#define DCREG_QOS_LOW_Type                                                   U04


#define DCREG_QOS_HIGH                                                       7:4
#define DCREG_QOS_HIGH_End                                                     7
#define DCREG_QOS_HIGH_Start                                                   4
#define DCREG_QOS_HIGH_Type                                                  U04



#define dcregOverlayScaleFactorXRegAddrs                                  0x0690
#define DCREG_OVERLAY_SCALE_FACTOR_X_Address                             0x01A40
#define DCREG_OVERLAY_SCALE_FACTOR_X_MSB                                      15
#define DCREG_OVERLAY_SCALE_FACTOR_X_LSB                                       4
#define DCREG_OVERLAY_SCALE_FACTOR_X_BLK                                       4
#define DCREG_OVERLAY_SCALE_FACTOR_X_Count                                    16
#define DCREG_OVERLAY_SCALE_FACTOR_X_FieldMask                        0x7FFFFFFF
#define DCREG_OVERLAY_SCALE_FACTOR_X_ReadMask                         0x7FFFFFFF
#define DCREG_OVERLAY_SCALE_FACTOR_X_WriteMask                        0x7FFFFFFF
#define DCREG_OVERLAY_SCALE_FACTOR_X_ResetValue                       0x00000000

#define DCREG_OVERLAY_SCALE_FACTOR_X_X                                      30:0
#define DCREG_OVERLAY_SCALE_FACTOR_X_X_End                                    30
#define DCREG_OVERLAY_SCALE_FACTOR_X_X_Start                                   0
#define DCREG_OVERLAY_SCALE_FACTOR_X_X_Type                                  U31



#define dcregOverlayScaleFactorYRegAddrs                                  0x06A0
#define DCREG_OVERLAY_SCALE_FACTOR_Y_Address                             0x01A80
#define DCREG_OVERLAY_SCALE_FACTOR_Y_MSB                                      15
#define DCREG_OVERLAY_SCALE_FACTOR_Y_LSB                                       4
#define DCREG_OVERLAY_SCALE_FACTOR_Y_BLK                                       4
#define DCREG_OVERLAY_SCALE_FACTOR_Y_Count                                    16
#define DCREG_OVERLAY_SCALE_FACTOR_Y_FieldMask                        0x7FFFFFFF
#define DCREG_OVERLAY_SCALE_FACTOR_Y_ReadMask                         0x7FFFFFFF
#define DCREG_OVERLAY_SCALE_FACTOR_Y_WriteMask                        0x7FFFFFFF
#define DCREG_OVERLAY_SCALE_FACTOR_Y_ResetValue                       0x00000000

#define DCREG_OVERLAY_SCALE_FACTOR_Y_Y                                      30:0
#define DCREG_OVERLAY_SCALE_FACTOR_Y_Y_End                                    30
#define DCREG_OVERLAY_SCALE_FACTOR_Y_Y_Start                                   0
#define DCREG_OVERLAY_SCALE_FACTOR_Y_Y_Type                                  U31



#define dcregOverlayHoriFilterKernelIndexRegAddrs                         0x06B0
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_Address                   0x01AC0
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_MSB                            15
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_LSB                             4
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_BLK                             4
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_Count                          16
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_FieldMask              0x000000FF
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_ReadMask               0x00000000
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_WriteMask              0x000000FF
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_ResetValue             0x00000000

#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_INDEX                         7:0
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_INDEX_End                       7
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_INDEX_Start                     0
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_INDEX_INDEX_Type                    U08



#define dcregOverlayHoriFilterKernelRegAddrs                              0x06C0
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_Address                         0x01B00
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_MSB                                  15
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_LSB                                   4
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_BLK                                   4
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_Count                                16
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_FieldMask                    0xFFFFFFFF
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_ReadMask                     0x00000000
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_WriteMask                    0xFFFFFFFF
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_ResetValue                   0x00000000

#define DCREG_OVERLAY_HORI_FILTER_KERNEL_COEFFICIENT0                       15:0
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_COEFFICIENT0_End                     15
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_COEFFICIENT0_Start                    0
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_COEFFICIENT0_Type                   U16

#define DCREG_OVERLAY_HORI_FILTER_KERNEL_COEFFICIENT1                      31:16
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_COEFFICIENT1_End                     31
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_COEFFICIENT1_Start                   16
#define DCREG_OVERLAY_HORI_FILTER_KERNEL_COEFFICIENT1_Type                   U16



#define dcregOverlayVertiFilterKernelIndexRegAddrs                        0x06D0
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_Address                  0x01B40
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_MSB                           15
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_LSB                            4
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_BLK                            4
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_Count                         16
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_FieldMask             0x000000FF
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_ReadMask              0x00000000
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_WriteMask             0x000000FF
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_ResetValue            0x00000000

#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_INDEX                        7:0
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_INDEX_End                      7
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_INDEX_Start                    0
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_INDEX_INDEX_Type                   U08



#define dcregOverlayVertiFilterKernelRegAddrs                             0x06E0
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_Address                        0x01B80
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_MSB                                 15
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_LSB                                  4
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_BLK                                  4
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_Count                               16
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_FieldMask                   0xFFFFFFFF
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_ReadMask                    0x00000000
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_WriteMask                   0xFFFFFFFF
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_ResetValue                  0x00000000

#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_COEFFICIENT0                      15:0
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_COEFFICIENT0_End                    15
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_COEFFICIENT0_Start                   0
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_COEFFICIENT0_Type                  U16

#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_COEFFICIENT1                     31:16
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_COEFFICIENT1_End                    31
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_COEFFICIENT1_Start                  16
#define DCREG_OVERLAY_VERTI_FILTER_KERNEL_COEFFICIENT1_Type                  U16



#define dcregOverlayInitialOffsetRegAddrs                                 0x06F0
#define DCREG_OVERLAY_INITIAL_OFFSET_Address                             0x01BC0
#define DCREG_OVERLAY_INITIAL_OFFSET_MSB                                      15
#define DCREG_OVERLAY_INITIAL_OFFSET_LSB                                       4
#define DCREG_OVERLAY_INITIAL_OFFSET_BLK                                       4
#define DCREG_OVERLAY_INITIAL_OFFSET_Count                                    16
#define DCREG_OVERLAY_INITIAL_OFFSET_FieldMask                        0xFFFFFFFF
#define DCREG_OVERLAY_INITIAL_OFFSET_ReadMask                         0xFFFFFFFF
#define DCREG_OVERLAY_INITIAL_OFFSET_WriteMask                        0xFFFFFFFF
#define DCREG_OVERLAY_INITIAL_OFFSET_ResetValue                       0x00000000

#define DCREG_OVERLAY_INITIAL_OFFSET_X                                      15:0
#define DCREG_OVERLAY_INITIAL_OFFSET_X_End                                    15
#define DCREG_OVERLAY_INITIAL_OFFSET_X_Start                                   0
#define DCREG_OVERLAY_INITIAL_OFFSET_X_Type                                  U16

#define DCREG_OVERLAY_INITIAL_OFFSET_Y                                     31:16
#define DCREG_OVERLAY_INITIAL_OFFSET_Y_End                                    31
#define DCREG_OVERLAY_INITIAL_OFFSET_Y_Start                                  16
#define DCREG_OVERLAY_INITIAL_OFFSET_Y_Type                                  U16




#define dcregOverlayScaleConfigRegAddrs                                   0x0700
#define DCREG_OVERLAY_SCALE_CONFIG_Address                               0x01C00
#define DCREG_OVERLAY_SCALE_CONFIG_MSB                                        15
#define DCREG_OVERLAY_SCALE_CONFIG_LSB                                         4
#define DCREG_OVERLAY_SCALE_CONFIG_BLK                                         4
#define DCREG_OVERLAY_SCALE_CONFIG_Count                                      16
#define DCREG_OVERLAY_SCALE_CONFIG_FieldMask                          0x000001FF
#define DCREG_OVERLAY_SCALE_CONFIG_ReadMask                           0x000001FF
#define DCREG_OVERLAY_SCALE_CONFIG_WriteMask                          0x000001FF
#define DCREG_OVERLAY_SCALE_CONFIG_ResetValue                         0x00000000

#define DCREG_OVERLAY_SCALE_CONFIG_VERTICAL_FILTER_TAP                       3:0
#define DCREG_OVERLAY_SCALE_CONFIG_VERTICAL_FILTER_TAP_End                     3
#define DCREG_OVERLAY_SCALE_CONFIG_VERTICAL_FILTER_TAP_Start                   0
#define DCREG_OVERLAY_SCALE_CONFIG_VERTICAL_FILTER_TAP_Type                  U04

#define DCREG_OVERLAY_SCALE_CONFIG_HORIZONTAL_FILTER_TAP                     7:4
#define DCREG_OVERLAY_SCALE_CONFIG_HORIZONTAL_FILTER_TAP_End                   7
#define DCREG_OVERLAY_SCALE_CONFIG_HORIZONTAL_FILTER_TAP_Start                 4
#define DCREG_OVERLAY_SCALE_CONFIG_HORIZONTAL_FILTER_TAP_Type                U04

#define DCREG_OVERLAY_SCALE_CONFIG_SCALE                                     8:8
#define DCREG_OVERLAY_SCALE_CONFIG_SCALE_End                                   8
#define DCREG_OVERLAY_SCALE_CONFIG_SCALE_Start                                 8
#define DCREG_OVERLAY_SCALE_CONFIG_SCALE_Type                                U01
#define   DCREG_OVERLAY_SCALE_CONFIG_SCALE_DISABLED                          0x0
#define   DCREG_OVERLAY_SCALE_CONFIG_SCALE_ENABLED                           0x1

#define dcregMpuIntfCmdRegAddrs                                           0x0710
#define DCREG_MPU_INTF_CMD_Address                                       0x01C40
#define DCREG_MPU_INTF_CMD_MSB                                                15
#define DCREG_MPU_INTF_CMD_LSB                                                 1
#define DCREG_MPU_INTF_CMD_BLK                                                 1
#define DCREG_MPU_INTF_CMD_Count                                               2
#define DCREG_MPU_INTF_CMD_FieldMask                                  0xE700FFFF
#define DCREG_MPU_INTF_CMD_ReadMask                                   0xC700FFFF
#define DCREG_MPU_INTF_CMD_WriteMask                                  0xE700FFFF
#define DCREG_MPU_INTF_CMD_ResetValue                                 0x00000000


#define DCREG_MPU_INTF_CMD_REG_DATA                                         15:0
#define DCREG_MPU_INTF_CMD_REG_DATA_End                                       15
#define DCREG_MPU_INTF_CMD_REG_DATA_Start                                      0
#define DCREG_MPU_INTF_CMD_REG_DATA_Type                                     U16

#define DCREG_MPU_INTF_CMD_READ_COUNT                                      26:24
#define DCREG_MPU_INTF_CMD_READ_COUNT_End                                     26
#define DCREG_MPU_INTF_CMD_READ_COUNT_Start                                   24
#define DCREG_MPU_INTF_CMD_READ_COUNT_Type                                   U03

#define DCREG_MPU_INTF_CMD_START                                           29:29
#define DCREG_MPU_INTF_CMD_START_End                                          29
#define DCREG_MPU_INTF_CMD_START_Start                                        29
#define DCREG_MPU_INTF_CMD_START_Type                                        U01

#define DCREG_MPU_INTF_CMD_CMD                                             31:30
#define DCREG_MPU_INTF_CMD_CMD_End                                            31
#define DCREG_MPU_INTF_CMD_CMD_Start                                          30
#define DCREG_MPU_INTF_CMD_CMD_Type                                          U02

#define dcregMpuIntfReadPara0RegAddrs                                     0x0712
#define DCREG_MPU_INTF_READ_PARA0_Address                                0x01C48
#define DCREG_MPU_INTF_READ_PARA0_MSB                                         15
#define DCREG_MPU_INTF_READ_PARA0_LSB                                          1
#define DCREG_MPU_INTF_READ_PARA0_BLK                                          1
#define DCREG_MPU_INTF_READ_PARA0_Count                                        2
#define DCREG_MPU_INTF_READ_PARA0_FieldMask                           0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA0_ReadMask                            0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA0_WriteMask                           0x00000000
#define DCREG_MPU_INTF_READ_PARA0_ResetValue                          0x00000000


#define DCREG_MPU_INTF_READ_PARA0_DATA                                      17:0
#define DCREG_MPU_INTF_READ_PARA0_DATA_End                                    17
#define DCREG_MPU_INTF_READ_PARA0_DATA_Start                                   0
#define DCREG_MPU_INTF_READ_PARA0_DATA_Type                                  U18

#define dcregMpuIntfReadPara1RegAddrs                                     0x0714
#define DCREG_MPU_INTF_READ_PARA1_Address                                0x01C50
#define DCREG_MPU_INTF_READ_PARA1_MSB                                         15
#define DCREG_MPU_INTF_READ_PARA1_LSB                                          1
#define DCREG_MPU_INTF_READ_PARA1_BLK                                          1
#define DCREG_MPU_INTF_READ_PARA1_Count                                        2
#define DCREG_MPU_INTF_READ_PARA1_FieldMask                           0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA1_ReadMask                            0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA1_WriteMask                           0x00000000
#define DCREG_MPU_INTF_READ_PARA1_ResetValue                          0x00000000


#define DCREG_MPU_INTF_READ_PARA1_DATA                                      17:0
#define DCREG_MPU_INTF_READ_PARA1_DATA_End                                    17
#define DCREG_MPU_INTF_READ_PARA1_DATA_Start                                   0
#define DCREG_MPU_INTF_READ_PARA1_DATA_Type                                  U18

#define dcregMpuIntfReadPara2RegAddrs                                     0x0716
#define DCREG_MPU_INTF_READ_PARA2_Address                                0x01C58
#define DCREG_MPU_INTF_READ_PARA2_MSB                                         15
#define DCREG_MPU_INTF_READ_PARA2_LSB                                          1
#define DCREG_MPU_INTF_READ_PARA2_BLK                                          1
#define DCREG_MPU_INTF_READ_PARA2_Count                                        2
#define DCREG_MPU_INTF_READ_PARA2_FieldMask                           0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA2_ReadMask                            0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA2_WriteMask                           0x00000000
#define DCREG_MPU_INTF_READ_PARA2_ResetValue                          0x00000000


#define DCREG_MPU_INTF_READ_PARA2_DATA                                      17:0
#define DCREG_MPU_INTF_READ_PARA2_DATA_End                                    17
#define DCREG_MPU_INTF_READ_PARA2_DATA_Start                                   0
#define DCREG_MPU_INTF_READ_PARA2_DATA_Type                                  U18

#define dcregMpuIntfReadPara3RegAddrs                                     0x0718
#define DCREG_MPU_INTF_READ_PARA3_Address                                0x01C60
#define DCREG_MPU_INTF_READ_PARA3_MSB                                         15
#define DCREG_MPU_INTF_READ_PARA3_LSB                                          1
#define DCREG_MPU_INTF_READ_PARA3_BLK                                          1
#define DCREG_MPU_INTF_READ_PARA3_Count                                        2
#define DCREG_MPU_INTF_READ_PARA3_FieldMask                           0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA3_ReadMask                            0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA3_WriteMask                           0x00000000
#define DCREG_MPU_INTF_READ_PARA3_ResetValue                          0x00000000


#define DCREG_MPU_INTF_READ_PARA3_DATA                                      17:0
#define DCREG_MPU_INTF_READ_PARA3_DATA_End                                    17
#define DCREG_MPU_INTF_READ_PARA3_DATA_Start                                   0
#define DCREG_MPU_INTF_READ_PARA3_DATA_Type                                  U18

#define dcregMpuIntfReadPara4RegAddrs                                     0x071A
#define DCREG_MPU_INTF_READ_PARA4_Address                                0x01C68
#define DCREG_MPU_INTF_READ_PARA4_MSB                                         15
#define DCREG_MPU_INTF_READ_PARA4_LSB                                          1
#define DCREG_MPU_INTF_READ_PARA4_BLK                                          1
#define DCREG_MPU_INTF_READ_PARA4_Count                                        2
#define DCREG_MPU_INTF_READ_PARA4_FieldMask                           0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA4_ReadMask                            0x0003FFFF
#define DCREG_MPU_INTF_READ_PARA4_WriteMask                           0x00000000
#define DCREG_MPU_INTF_READ_PARA4_ResetValue                          0x00000000


#define DCREG_MPU_INTF_READ_PARA4_DATA                                      17:0
#define DCREG_MPU_INTF_READ_PARA4_DATA_End                                    17
#define DCREG_MPU_INTF_READ_PARA4_DATA_Start                                   0
#define DCREG_MPU_INTF_READ_PARA4_DATA_Type                                  U18

#define dcregMpuIntfReadStatusRegAddrs                                    0x071C
#define DCREG_MPU_INTF_READ_STATUS_Address                               0x01C70
#define DCREG_MPU_INTF_READ_STATUS_MSB                                        15
#define DCREG_MPU_INTF_READ_STATUS_LSB                                         1
#define DCREG_MPU_INTF_READ_STATUS_BLK                                         1
#define DCREG_MPU_INTF_READ_STATUS_Count                                       2
#define DCREG_MPU_INTF_READ_STATUS_FieldMask                          0x00000001
#define DCREG_MPU_INTF_READ_STATUS_ReadMask                           0x00000001
#define DCREG_MPU_INTF_READ_STATUS_WriteMask                          0x00000000
#define DCREG_MPU_INTF_READ_STATUS_ResetValue                         0x00000000

#define DCREG_MPU_INTF_READ_STATUS_DATA                                      0:0
#define DCREG_MPU_INTF_READ_STATUS_DATA_End                                    0
#define DCREG_MPU_INTF_READ_STATUS_DATA_Start                                  0
#define DCREG_MPU_INTF_READ_STATUS_DATA_Type                                 U01
#define   DCREG_MPU_INTF_READ_STATUS_DATA_UNREADY                            0x0
#define   DCREG_MPU_INTF_READ_STATUS_DATA_READY                              0x1

#define dcregMpuIntfConfigRegAddrs                                        0x071E
#define DCREG_MPU_INTF_CONFIG_Address                                    0x01C78
#define DCREG_MPU_INTF_CONFIG_MSB                                             15
#define DCREG_MPU_INTF_CONFIG_LSB                                              1
#define DCREG_MPU_INTF_CONFIG_BLK                                              1
#define DCREG_MPU_INTF_CONFIG_Count                                            2
#define DCREG_MPU_INTF_CONFIG_FieldMask                               0x00001FFF
#define DCREG_MPU_INTF_CONFIG_ReadMask                                0x000017FF
#define DCREG_MPU_INTF_CONFIG_WriteMask                               0x00001FFF
#define DCREG_MPU_INTF_CONFIG_ResetValue                              0x00000000

#define DCREG_MPU_INTF_CONFIG_REGISTER_MODE                                  0:0
#define DCREG_MPU_INTF_CONFIG_REGISTER_MODE_End                                0
#define DCREG_MPU_INTF_CONFIG_REGISTER_MODE_Start                              0
#define DCREG_MPU_INTF_CONFIG_REGISTER_MODE_Type                             U01
#define   DCREG_MPU_INTF_CONFIG_REGISTER_MODE_MODE_8_BIT                     0x0
#define   DCREG_MPU_INTF_CONFIG_REGISTER_MODE_MODE_16_BIT                    0x1

#define DCREG_MPU_INTF_CONFIG_DATA_BUS_WIDTH                                 2:1
#define DCREG_MPU_INTF_CONFIG_DATA_BUS_WIDTH_End                               2
#define DCREG_MPU_INTF_CONFIG_DATA_BUS_WIDTH_Start                             1
#define DCREG_MPU_INTF_CONFIG_DATA_BUS_WIDTH_Type                            U02
#define   DCREG_MPU_INTF_CONFIG_DATA_BUS_WIDTH_WIDTH_8_BIT                   0x0
#define   DCREG_MPU_INTF_CONFIG_DATA_BUS_WIDTH_WIDTH_9_BIT                   0x1
#define   DCREG_MPU_INTF_CONFIG_DATA_BUS_WIDTH_WIDTH_16_BIT                  0x2
#define   DCREG_MPU_INTF_CONFIG_DATA_BUS_WIDTH_WIDTH_18_BIT                  0x3

#define DCREG_MPU_INTF_CONFIG_DATA_BUS_MODE                                  3:3
#define DCREG_MPU_INTF_CONFIG_DATA_BUS_MODE_End                                3
#define DCREG_MPU_INTF_CONFIG_DATA_BUS_MODE_Start                              3
#define DCREG_MPU_INTF_CONFIG_DATA_BUS_MODE_Type                             U01
#define   DCREG_MPU_INTF_CONFIG_DATA_BUS_MODE_MODE0                          0x0
#define   DCREG_MPU_INTF_CONFIG_DATA_BUS_MODE_MODE1                          0x1


#define DCREG_MPU_INTF_CONFIG_INTERFACE_MODE                                 4:4
#define DCREG_MPU_INTF_CONFIG_INTERFACE_MODE_End                               4
#define DCREG_MPU_INTF_CONFIG_INTERFACE_MODE_Start                             4
#define DCREG_MPU_INTF_CONFIG_INTERFACE_MODE_Type                            U01
#define   DCREG_MPU_INTF_CONFIG_INTERFACE_MODE_I80                           0x0
#define   DCREG_MPU_INTF_CONFIG_INTERFACE_MODE_M68                           0x1


#define DCREG_MPU_INTF_CONFIG_ENABLE_VSYNC                                   5:5
#define DCREG_MPU_INTF_CONFIG_ENABLE_VSYNC_End                                 5
#define DCREG_MPU_INTF_CONFIG_ENABLE_VSYNC_Start                               5
#define DCREG_MPU_INTF_CONFIG_ENABLE_VSYNC_Type                              U01
#define   DCREG_MPU_INTF_CONFIG_ENABLE_VSYNC_DISABLE                         0x0
#define   DCREG_MPU_INTF_CONFIG_ENABLE_VSYNC_ENABLE                          0x1


#define DCREG_MPU_INTF_CONFIG_VSYNC_POLARITY                                 6:6
#define DCREG_MPU_INTF_CONFIG_VSYNC_POLARITY_End                               6
#define DCREG_MPU_INTF_CONFIG_VSYNC_POLARITY_Start                             6
#define DCREG_MPU_INTF_CONFIG_VSYNC_POLARITY_Type                            U01
#define   DCREG_MPU_INTF_CONFIG_VSYNC_POLARITY_NEGATIVE                      0x0
#define   DCREG_MPU_INTF_CONFIG_VSYNC_POLARITY_POSITIVE                      0x1


#define DCREG_MPU_INTF_CONFIG_ENABLE_TE                                      7:7
#define DCREG_MPU_INTF_CONFIG_ENABLE_TE_End                                    7
#define DCREG_MPU_INTF_CONFIG_ENABLE_TE_Start                                  7
#define DCREG_MPU_INTF_CONFIG_ENABLE_TE_Type                                 U01
#define   DCREG_MPU_INTF_CONFIG_ENABLE_TE_DISABLE                            0x0
#define   DCREG_MPU_INTF_CONFIG_ENABLE_TE_ENABLE                             0x1


#define DCREG_MPU_INTF_CONFIG_TE_POLARITY                                    8:8
#define DCREG_MPU_INTF_CONFIG_TE_POLARITY_End                                  8
#define DCREG_MPU_INTF_CONFIG_TE_POLARITY_Start                                8
#define DCREG_MPU_INTF_CONFIG_TE_POLARITY_Type                               U01
#define   DCREG_MPU_INTF_CONFIG_TE_POLARITY_POSITIVE                         0x0
#define   DCREG_MPU_INTF_CONFIG_TE_POLARITY_NEGATIVE                         0x1


#define DCREG_MPU_INTF_CONFIG_DCX_POLARITY                                   9:9
#define DCREG_MPU_INTF_CONFIG_DCX_POLARITY_End                                 9
#define DCREG_MPU_INTF_CONFIG_DCX_POLARITY_Start                               9
#define DCREG_MPU_INTF_CONFIG_DCX_POLARITY_Type                              U01
#define   DCREG_MPU_INTF_CONFIG_DCX_POLARITY_MODE0                           0x0
#define   DCREG_MPU_INTF_CONFIG_DCX_POLARITY_MODE1                           0x1

#define DCREG_MPU_INTF_CONFIG_DATA_MODE24_BIT                              10:10
#define DCREG_MPU_INTF_CONFIG_DATA_MODE24_BIT_End                             10
#define DCREG_MPU_INTF_CONFIG_DATA_MODE24_BIT_Start                           10
#define DCREG_MPU_INTF_CONFIG_DATA_MODE24_BIT_Type                           U01
#define   DCREG_MPU_INTF_CONFIG_DATA_MODE24_BIT_MODE0                        0x0
#define   DCREG_MPU_INTF_CONFIG_DATA_MODE24_BIT_MODE1                        0x1


#define DCREG_MPU_INTF_CONFIG_INTERFACE_RESET                              11:11
#define DCREG_MPU_INTF_CONFIG_INTERFACE_RESET_End                             11
#define DCREG_MPU_INTF_CONFIG_INTERFACE_RESET_Start                           11
#define DCREG_MPU_INTF_CONFIG_INTERFACE_RESET_Type                           U01


#define DCREG_MPU_INTF_CONFIG_ENABLE_MPU_INTF                              12:12
#define DCREG_MPU_INTF_CONFIG_ENABLE_MPU_INTF_End                             12
#define DCREG_MPU_INTF_CONFIG_ENABLE_MPU_INTF_Start                           12
#define DCREG_MPU_INTF_CONFIG_ENABLE_MPU_INTF_Type                           U01
#define   DCREG_MPU_INTF_CONFIG_ENABLE_MPU_INTF_DISABLE                      0x0
#define   DCREG_MPU_INTF_CONFIG_ENABLE_MPU_INTF_ENABLE                       0x1

#define dcregMpuIntfFrameRegAddrs                                         0x0720
#define DCREG_MPU_INTF_FRAME_Address                                     0x01C80
#define DCREG_MPU_INTF_FRAME_MSB                                              15
#define DCREG_MPU_INTF_FRAME_LSB                                               1
#define DCREG_MPU_INTF_FRAME_BLK                                               1
#define DCREG_MPU_INTF_FRAME_Count                                             2
#define DCREG_MPU_INTF_FRAME_FieldMask                                0x0000000F
#define DCREG_MPU_INTF_FRAME_ReadMask                                 0x0000000F
#define DCREG_MPU_INTF_FRAME_WriteMask                                0x0000000F
#define DCREG_MPU_INTF_FRAME_ResetValue                               0x00000000

#define DCREG_MPU_INTF_FRAME_FRAME_UPDATE                                    0:0
#define DCREG_MPU_INTF_FRAME_FRAME_UPDATE_End                                  0
#define DCREG_MPU_INTF_FRAME_FRAME_UPDATE_Start                                0
#define DCREG_MPU_INTF_FRAME_FRAME_UPDATE_Type                               U01
#define   DCREG_MPU_INTF_FRAME_FRAME_UPDATE_NO                               0x0
#define   DCREG_MPU_INTF_FRAME_FRAME_UPDATE_YES                              0x1

#define DCREG_MPU_INTF_FRAME_DATA_FORMAT                                     2:1
#define DCREG_MPU_INTF_FRAME_DATA_FORMAT_End                                   2
#define DCREG_MPU_INTF_FRAME_DATA_FORMAT_Start                                 1
#define DCREG_MPU_INTF_FRAME_DATA_FORMAT_Type                                U02
#define   DCREG_MPU_INTF_FRAME_DATA_FORMAT_R5G6B5                            0x0
#define   DCREG_MPU_INTF_FRAME_DATA_FORMAT_R6G6B6                            0x1
#define   DCREG_MPU_INTF_FRAME_DATA_FORMAT_R8G8B8                            0x2


#define DCREG_MPU_INTF_FRAME_MPU_WRITE_BACK                                  3:3
#define DCREG_MPU_INTF_FRAME_MPU_WRITE_BACK_End                                3
#define DCREG_MPU_INTF_FRAME_MPU_WRITE_BACK_Start                              3
#define DCREG_MPU_INTF_FRAME_MPU_WRITE_BACK_Type                             U01
#define   DCREG_MPU_INTF_FRAME_MPU_WRITE_BACK_DISABLE                        0x0
#define   DCREG_MPU_INTF_FRAME_MPU_WRITE_BACK_ENABLE                         0x1

#define dcregMpuIntfACWrI80RegAddrs                                       0x0722
#define DCREG_MPU_INTF_AC_WR_I80_Address                                 0x01C88
#define DCREG_MPU_INTF_AC_WR_I80_MSB                                          15
#define DCREG_MPU_INTF_AC_WR_I80_LSB                                           1
#define DCREG_MPU_INTF_AC_WR_I80_BLK                                           1
#define DCREG_MPU_INTF_AC_WR_I80_Count                                         2
#define DCREG_MPU_INTF_AC_WR_I80_FieldMask                            0x3FFFFFFF
#define DCREG_MPU_INTF_AC_WR_I80_ReadMask                             0x3FFFFFFF
#define DCREG_MPU_INTF_AC_WR_I80_WriteMask                            0x3FFFFFFF
#define DCREG_MPU_INTF_AC_WR_I80_ResetValue                           0x00000000

#define DCREG_MPU_INTF_AC_WR_I80_WR_PERIOD_I80                               9:0
#define DCREG_MPU_INTF_AC_WR_I80_WR_PERIOD_I80_End                             9
#define DCREG_MPU_INTF_AC_WR_I80_WR_PERIOD_I80_Start                           0
#define DCREG_MPU_INTF_AC_WR_I80_WR_PERIOD_I80_Type                          U10

#define DCREG_MPU_INTF_AC_WR_I80_WRX_ASSERT                                19:10
#define DCREG_MPU_INTF_AC_WR_I80_WRX_ASSERT_End                               19
#define DCREG_MPU_INTF_AC_WR_I80_WRX_ASSERT_Start                             10
#define DCREG_MPU_INTF_AC_WR_I80_WRX_ASSERT_Type                             U10

#define DCREG_MPU_INTF_AC_WR_I80_WRX_DE_ASSERT                             29:20
#define DCREG_MPU_INTF_AC_WR_I80_WRX_DE_ASSERT_End                            29
#define DCREG_MPU_INTF_AC_WR_I80_WRX_DE_ASSERT_Start                          20
#define DCREG_MPU_INTF_AC_WR_I80_WRX_DE_ASSERT_Type                          U10

#define dcregMpuIntfACRdI80RegAddrs                                       0x0724
#define DCREG_MPU_INTF_AC_RD_I80_Address                                 0x01C90
#define DCREG_MPU_INTF_AC_RD_I80_MSB                                          15
#define DCREG_MPU_INTF_AC_RD_I80_LSB                                           1
#define DCREG_MPU_INTF_AC_RD_I80_BLK                                           1
#define DCREG_MPU_INTF_AC_RD_I80_Count                                         2
#define DCREG_MPU_INTF_AC_RD_I80_FieldMask                            0x3FFFFFFF
#define DCREG_MPU_INTF_AC_RD_I80_ReadMask                             0x3FFFFFFF
#define DCREG_MPU_INTF_AC_RD_I80_WriteMask                            0x3FFFFFFF
#define DCREG_MPU_INTF_AC_RD_I80_ResetValue                           0x00000000

#define DCREG_MPU_INTF_AC_RD_I80_RD_PERIOD_I80                               9:0
#define DCREG_MPU_INTF_AC_RD_I80_RD_PERIOD_I80_End                             9
#define DCREG_MPU_INTF_AC_RD_I80_RD_PERIOD_I80_Start                           0
#define DCREG_MPU_INTF_AC_RD_I80_RD_PERIOD_I80_Type                          U10

#define DCREG_MPU_INTF_AC_RD_I80_RDX_ASSERT                                19:10
#define DCREG_MPU_INTF_AC_RD_I80_RDX_ASSERT_End                               19
#define DCREG_MPU_INTF_AC_RD_I80_RDX_ASSERT_Start                             10
#define DCREG_MPU_INTF_AC_RD_I80_RDX_ASSERT_Type                             U10

#define DCREG_MPU_INTF_AC_RD_I80_RDX_DE_ASSERT                             29:20
#define DCREG_MPU_INTF_AC_RD_I80_RDX_DE_ASSERT_End                            29
#define DCREG_MPU_INTF_AC_RD_I80_RDX_DE_ASSERT_Start                          20
#define DCREG_MPU_INTF_AC_RD_I80_RDX_DE_ASSERT_Type                          U10

#define dcregMpuIntfACWrM68RegAddrs                                       0x0726
#define DCREG_MPU_INTF_AC_WR_M68_Address                                 0x01C98
#define DCREG_MPU_INTF_AC_WR_M68_MSB                                          15
#define DCREG_MPU_INTF_AC_WR_M68_LSB                                           1
#define DCREG_MPU_INTF_AC_WR_M68_BLK                                           1
#define DCREG_MPU_INTF_AC_WR_M68_Count                                         2
#define DCREG_MPU_INTF_AC_WR_M68_FieldMask                            0x3FFFFFFF
#define DCREG_MPU_INTF_AC_WR_M68_ReadMask                             0x3FFFFFFF
#define DCREG_MPU_INTF_AC_WR_M68_WriteMask                            0x3FFFFFFF
#define DCREG_MPU_INTF_AC_WR_M68_ResetValue                           0x00000000

#define DCREG_MPU_INTF_AC_WR_M68_WR_PERIOD_M68                               9:0
#define DCREG_MPU_INTF_AC_WR_M68_WR_PERIOD_M68_End                             9
#define DCREG_MPU_INTF_AC_WR_M68_WR_PERIOD_M68_Start                           0
#define DCREG_MPU_INTF_AC_WR_M68_WR_PERIOD_M68_Type                          U10

#define DCREG_MPU_INTF_AC_WR_M68_WR_EASSERT                                19:10
#define DCREG_MPU_INTF_AC_WR_M68_WR_EASSERT_End                               19
#define DCREG_MPU_INTF_AC_WR_M68_WR_EASSERT_Start                             10
#define DCREG_MPU_INTF_AC_WR_M68_WR_EASSERT_Type                             U10

#define DCREG_MPU_INTF_AC_WR_M68_WR_EDE_ASSERT                             29:20
#define DCREG_MPU_INTF_AC_WR_M68_WR_EDE_ASSERT_End                            29
#define DCREG_MPU_INTF_AC_WR_M68_WR_EDE_ASSERT_Start                          20
#define DCREG_MPU_INTF_AC_WR_M68_WR_EDE_ASSERT_Type                          U10

#define dcregMpuIntfACRdM68RegAddrs                                       0x0728
#define DCREG_MPU_INTF_AC_RD_M68_Address                                 0x01CA0
#define DCREG_MPU_INTF_AC_RD_M68_MSB                                          15
#define DCREG_MPU_INTF_AC_RD_M68_LSB                                           1
#define DCREG_MPU_INTF_AC_RD_M68_BLK                                           1
#define DCREG_MPU_INTF_AC_RD_M68_Count                                         2
#define DCREG_MPU_INTF_AC_RD_M68_FieldMask                            0x3FFFFFFF
#define DCREG_MPU_INTF_AC_RD_M68_ReadMask                             0x3FFFFFFF
#define DCREG_MPU_INTF_AC_RD_M68_WriteMask                            0x3FFFFFFF
#define DCREG_MPU_INTF_AC_RD_M68_ResetValue                           0x00000000

#define DCREG_MPU_INTF_AC_RD_M68_RD_PERIOD_M68                               9:0
#define DCREG_MPU_INTF_AC_RD_M68_RD_PERIOD_M68_End                             9
#define DCREG_MPU_INTF_AC_RD_M68_RD_PERIOD_M68_Start                           0
#define DCREG_MPU_INTF_AC_RD_M68_RD_PERIOD_M68_Type                          U10

#define DCREG_MPU_INTF_AC_RD_M68_RD_EASSERT                                19:10
#define DCREG_MPU_INTF_AC_RD_M68_RD_EASSERT_End                               19
#define DCREG_MPU_INTF_AC_RD_M68_RD_EASSERT_Start                             10
#define DCREG_MPU_INTF_AC_RD_M68_RD_EASSERT_Type                             U10

#define DCREG_MPU_INTF_AC_RD_M68_RD_EDE_ASSERT                             29:20
#define DCREG_MPU_INTF_AC_RD_M68_RD_EDE_ASSERT_End                            29
#define DCREG_MPU_INTF_AC_RD_M68_RD_EDE_ASSERT_Start                          20
#define DCREG_MPU_INTF_AC_RD_M68_RD_EDE_ASSERT_Type                          U10

#define dcregMpuIntfACVsyncCSXRegAddrs                                    0x072A
#define DCREG_MPU_INTF_AC_VSYNC_CSX_Address                              0x01CA8
#define DCREG_MPU_INTF_AC_VSYNC_CSX_MSB                                       15
#define DCREG_MPU_INTF_AC_VSYNC_CSX_LSB                                        1
#define DCREG_MPU_INTF_AC_VSYNC_CSX_BLK                                        1
#define DCREG_MPU_INTF_AC_VSYNC_CSX_Count                                      2
#define DCREG_MPU_INTF_AC_VSYNC_CSX_FieldMask                         0x000003FF
#define DCREG_MPU_INTF_AC_VSYNC_CSX_ReadMask                          0x000003FF
#define DCREG_MPU_INTF_AC_VSYNC_CSX_WriteMask                         0x000003FF
#define DCREG_MPU_INTF_AC_VSYNC_CSX_ResetValue                        0x00000000

#define DCREG_MPU_INTF_AC_VSYNC_CSX_CSX_ASSERT                               9:0
#define DCREG_MPU_INTF_AC_VSYNC_CSX_CSX_ASSERT_End                             9
#define DCREG_MPU_INTF_AC_VSYNC_CSX_CSX_ASSERT_Start                           0
#define DCREG_MPU_INTF_AC_VSYNC_CSX_CSX_ASSERT_Type                          U10



#define dcregFrameBufferROIOriginRegAddrs                                 0x072C
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_Address                            0x01CB0
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_MSB                                     15
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_LSB                                      1
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_BLK                                      1
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_Count                                    2
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_FieldMask                       0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_ReadMask                        0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_WriteMask                       0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_ResetValue                      0x00000000


#define DCREG_FRAME_BUFFER_ROI_ORIGIN_X                                     15:0
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_X_End                                   15
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_X_Start                                  0
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_X_Type                                 U16


#define DCREG_FRAME_BUFFER_ROI_ORIGIN_Y                                    31:16
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_Y_End                                   31
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_Y_Start                                 16
#define DCREG_FRAME_BUFFER_ROI_ORIGIN_Y_Type                                 U16



#define dcregFrameBufferROISizeRegAddrs                                   0x072E
#define DCREG_FRAME_BUFFER_ROI_SIZE_Address                              0x01CB8
#define DCREG_FRAME_BUFFER_ROI_SIZE_MSB                                       15
#define DCREG_FRAME_BUFFER_ROI_SIZE_LSB                                        1
#define DCREG_FRAME_BUFFER_ROI_SIZE_BLK                                        1
#define DCREG_FRAME_BUFFER_ROI_SIZE_Count                                      2
#define DCREG_FRAME_BUFFER_ROI_SIZE_FieldMask                         0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ROI_SIZE_ReadMask                          0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ROI_SIZE_WriteMask                         0xFFFFFFFF
#define DCREG_FRAME_BUFFER_ROI_SIZE_ResetValue                        0x00000000


#define DCREG_FRAME_BUFFER_ROI_SIZE_WIDTH                                   15:0
#define DCREG_FRAME_BUFFER_ROI_SIZE_WIDTH_End                                 15
#define DCREG_FRAME_BUFFER_ROI_SIZE_WIDTH_Start                                0
#define DCREG_FRAME_BUFFER_ROI_SIZE_WIDTH_Type                               U16


#define DCREG_FRAME_BUFFER_ROI_SIZE_HEIGHT                                 31:16
#define DCREG_FRAME_BUFFER_ROI_SIZE_HEIGHT_End                                31
#define DCREG_FRAME_BUFFER_ROI_SIZE_HEIGHT_Start                              16
#define DCREG_FRAME_BUFFER_ROI_SIZE_HEIGHT_Type                              U16



#define dcregFrameBufferConfigExRegAddrs                                  0x0730
#define DCREG_FRAME_BUFFER_CONFIG_EX_Address                             0x01CC0
#define DCREG_FRAME_BUFFER_CONFIG_EX_MSB                                      15
#define DCREG_FRAME_BUFFER_CONFIG_EX_LSB                                       1
#define DCREG_FRAME_BUFFER_CONFIG_EX_BLK                                       1
#define DCREG_FRAME_BUFFER_CONFIG_EX_Count                                     2
#define DCREG_FRAME_BUFFER_CONFIG_EX_FieldMask                        0x000001FF
#define DCREG_FRAME_BUFFER_CONFIG_EX_ReadMask                         0x000001FF
#define DCREG_FRAME_BUFFER_CONFIG_EX_WriteMask                        0x000001FF
#define DCREG_FRAME_BUFFER_CONFIG_EX_ResetValue                       0x00000000


#define DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_ROI                              0:0
#define DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_ROI_End                            0
#define DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_ROI_Start                          0
#define DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_ROI_Type                         U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_ROI_DISABLE                    0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_ROI_ENABLE                     0x1


#define DCREG_FRAME_BUFFER_CONFIG_EX_COMPRESSED                              1:1
#define DCREG_FRAME_BUFFER_CONFIG_EX_COMPRESSED_End                            1
#define DCREG_FRAME_BUFFER_CONFIG_EX_COMPRESSED_Start                          1
#define DCREG_FRAME_BUFFER_CONFIG_EX_COMPRESSED_Type                         U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_COMPRESSED_UNCOMPRESSED               0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_COMPRESSED_COMPRESSED                 0x1


#define DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_THREED_LUT                       2:2
#define DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_THREED_LUT_End                     2
#define DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_THREED_LUT_Start                   2
#define DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_THREED_LUT_Type                  U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_THREED_LUT_DISABLE             0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_ENABLE_THREED_LUT_ENABLE              0x1


#define DCREG_FRAME_BUFFER_CONFIG_EX_MULTI_SYNC                              3:3
#define DCREG_FRAME_BUFFER_CONFIG_EX_MULTI_SYNC_End                            3
#define DCREG_FRAME_BUFFER_CONFIG_EX_MULTI_SYNC_Start                          3
#define DCREG_FRAME_BUFFER_CONFIG_EX_MULTI_SYNC_Type                         U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_MULTI_SYNC_DISABLE                    0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_MULTI_SYNC_ENABLE                     0x1


#define DCREG_FRAME_BUFFER_CONFIG_EX_MASTER                                  4:4
#define DCREG_FRAME_BUFFER_CONFIG_EX_MASTER_End                                4
#define DCREG_FRAME_BUFFER_CONFIG_EX_MASTER_Start                              4
#define DCREG_FRAME_BUFFER_CONFIG_EX_MASTER_Type                             U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_MASTER_DISABLE                        0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_MASTER_ENABLE                         0x1

#define DCREG_FRAME_BUFFER_CONFIG_EX_DE_GAMMA                                5:5
#define DCREG_FRAME_BUFFER_CONFIG_EX_DE_GAMMA_End                              5
#define DCREG_FRAME_BUFFER_CONFIG_EX_DE_GAMMA_Start                            5
#define DCREG_FRAME_BUFFER_CONFIG_EX_DE_GAMMA_Type                           U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_DE_GAMMA_DISABLED                     0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_DE_GAMMA_ENABLED                      0x1


#define DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_RGB                              6:6
#define DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_RGB_End                            6
#define DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_RGB_Start                          6
#define DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_RGB_Type                         U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_RGB_DISABLED                   0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_RGB_ENABLED                    0x1


#define DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_YUV                              7:7
#define DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_YUV_End                            7
#define DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_YUV_Start                          7
#define DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_YUV_Type                         U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_YUV_DISABLED                   0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_RGB_TO_YUV_ENABLED                    0x1


#define DCREG_FRAME_BUFFER_CONFIG_EX_YUV_CLAMP                               8:8
#define DCREG_FRAME_BUFFER_CONFIG_EX_YUV_CLAMP_End                             8
#define DCREG_FRAME_BUFFER_CONFIG_EX_YUV_CLAMP_Start                           8
#define DCREG_FRAME_BUFFER_CONFIG_EX_YUV_CLAMP_Type                          U01
#define   DCREG_FRAME_BUFFER_CONFIG_EX_YUV_CLAMP_DISABLED                    0x0
#define   DCREG_FRAME_BUFFER_CONFIG_EX_YUV_CLAMP_ENABLED                     0x1

#define dcregReadOTRegAddrs                                               0x0732
#define DCREG_READ_OT_Address                                            0x01CC8
#define DCREG_READ_OT_MSB                                                     15
#define DCREG_READ_OT_LSB                                                      0
#define DCREG_READ_OT_BLK                                                      0
#define DCREG_READ_OT_Count                                                    1
#define DCREG_READ_OT_FieldMask                                       0x0000007F
#define DCREG_READ_OT_ReadMask                                        0x0000007F
#define DCREG_READ_OT_WriteMask                                       0x0000007F
#define DCREG_READ_OT_ResetValue                                      0x00000000


#define DCREG_READ_OT_VALUE                                                  6:0
#define DCREG_READ_OT_VALUE_End                                                6
#define DCREG_READ_OT_VALUE_Start                                              0
#define DCREG_READ_OT_VALUE_Type                                             U07



#define dcregDpConfigRegAddrs                                             0x0734
#define DCREG_DP_CONFIG_Address                                          0x01CD0
#define DCREG_DP_CONFIG_MSB                                                   15
#define DCREG_DP_CONFIG_LSB                                                    1
#define DCREG_DP_CONFIG_BLK                                                    1
#define DCREG_DP_CONFIG_Count                                                  2
#define DCREG_DP_CONFIG_FieldMask                                     0x000000FF
#define DCREG_DP_CONFIG_ReadMask                                      0x000000FF
#define DCREG_DP_CONFIG_WriteMask                                     0x000000FF
#define DCREG_DP_CONFIG_ResetValue                                    0x00000000

#define DCREG_DP_CONFIG_DP_DATA_FORMAT                                       2:0
#define DCREG_DP_CONFIG_DP_DATA_FORMAT_End                                     2
#define DCREG_DP_CONFIG_DP_DATA_FORMAT_Start                                   0
#define DCREG_DP_CONFIG_DP_DATA_FORMAT_Type                                  U03
#define   DCREG_DP_CONFIG_DP_DATA_FORMAT_RGB565                              0x0
#define   DCREG_DP_CONFIG_DP_DATA_FORMAT_RGB666                              0x1
#define   DCREG_DP_CONFIG_DP_DATA_FORMAT_RGB888                              0x2
#define   DCREG_DP_CONFIG_DP_DATA_FORMAT_RGB101010                           0x3


#define DCREG_DP_CONFIG_BUS_OUTPUT_SEL                                       3:3
#define DCREG_DP_CONFIG_BUS_OUTPUT_SEL_End                                     3
#define DCREG_DP_CONFIG_BUS_OUTPUT_SEL_Start                                   3
#define DCREG_DP_CONFIG_BUS_OUTPUT_SEL_Type                                  U01
#define   DCREG_DP_CONFIG_BUS_OUTPUT_SEL_DPI                                 0x0
#define   DCREG_DP_CONFIG_BUS_OUTPUT_SEL_DP                                  0x1

#define DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT                                   7:4
#define DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_End                                 7
#define DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_Start                               4
#define DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_Type                              U04
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV420BIT8CFG1                  0x0
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV420BIT8CFG2                  0x1
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV422BIT8CFG1                  0x2
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV422BIT8CFG2                  0x3
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV444BIT8CFG1                  0x4
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV444BIT8CFG2                  0x5
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV420BIT10CFG1                 0x6
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV420BIT10CFG2                 0x7
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV422BIT10CFG1                 0x8
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV422BIT10CFG2                 0x9
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV444BIT10CFG1                 0xA
#define   DCREG_DP_CONFIG_DP_DATA_YUV_FORMAT_YUV444BIT10CFG2                 0xB




#define dcregThreedLutIndexRegAddrs                                       0x0736
#define DCREG_THREED_LUT_INDEX_Address                                   0x01CD8
#define DCREG_THREED_LUT_INDEX_MSB                                            15
#define DCREG_THREED_LUT_INDEX_LSB                                             1
#define DCREG_THREED_LUT_INDEX_BLK                                             1
#define DCREG_THREED_LUT_INDEX_Count                                           2
#define DCREG_THREED_LUT_INDEX_FieldMask                              0x001F1F1F
#define DCREG_THREED_LUT_INDEX_ReadMask                               0x001F1F1F
#define DCREG_THREED_LUT_INDEX_WriteMask                              0x001F1F1F
#define DCREG_THREED_LUT_INDEX_ResetValue                             0x00000000

#define DCREG_THREED_LUT_INDEX_B                                             4:0
#define DCREG_THREED_LUT_INDEX_B_End                                           4
#define DCREG_THREED_LUT_INDEX_B_Start                                         0
#define DCREG_THREED_LUT_INDEX_B_Type                                        U05

#define DCREG_THREED_LUT_INDEX_G                                            12:8
#define DCREG_THREED_LUT_INDEX_G_End                                          12
#define DCREG_THREED_LUT_INDEX_G_Start                                         8
#define DCREG_THREED_LUT_INDEX_G_Type                                        U05

#define DCREG_THREED_LUT_INDEX_R                                           20:16
#define DCREG_THREED_LUT_INDEX_R_End                                          20
#define DCREG_THREED_LUT_INDEX_R_Start                                        16
#define DCREG_THREED_LUT_INDEX_R_Type                                        U05




#define dcregThreedLutDataRegAddrs                                        0x0738
#define DCREG_THREED_LUT_DATA_Address                                    0x01CE0
#define DCREG_THREED_LUT_DATA_MSB                                             15
#define DCREG_THREED_LUT_DATA_LSB                                              1
#define DCREG_THREED_LUT_DATA_BLK                                              1
#define DCREG_THREED_LUT_DATA_Count                                            2
#define DCREG_THREED_LUT_DATA_FieldMask                               0x3FFFFFFF
#define DCREG_THREED_LUT_DATA_ReadMask                                0x3FFFFFFF
#define DCREG_THREED_LUT_DATA_WriteMask                               0x3FFFFFFF
#define DCREG_THREED_LUT_DATA_ResetValue                              0x00000000

#define DCREG_THREED_LUT_DATA_B                                              9:0
#define DCREG_THREED_LUT_DATA_B_End                                            9
#define DCREG_THREED_LUT_DATA_B_Start                                          0
#define DCREG_THREED_LUT_DATA_B_Type                                         U10

#define DCREG_THREED_LUT_DATA_G                                            19:10
#define DCREG_THREED_LUT_DATA_G_End                                           19
#define DCREG_THREED_LUT_DATA_G_Start                                         10
#define DCREG_THREED_LUT_DATA_G_Type                                         U10

#define DCREG_THREED_LUT_DATA_R                                            29:20
#define DCREG_THREED_LUT_DATA_R_End                                           29
#define DCREG_THREED_LUT_DATA_R_Start                                         20
#define DCREG_THREED_LUT_DATA_R_Type                                         U10



#define dcregFrameBufferWaterMarkRegAddrs                                 0x073A
#define DCREG_FRAME_BUFFER_WATER_MARK_Address                            0x01CE8
#define DCREG_FRAME_BUFFER_WATER_MARK_MSB                                     15
#define DCREG_FRAME_BUFFER_WATER_MARK_LSB                                      1
#define DCREG_FRAME_BUFFER_WATER_MARK_BLK                                      1
#define DCREG_FRAME_BUFFER_WATER_MARK_Count                                    2
#define DCREG_FRAME_BUFFER_WATER_MARK_FieldMask                       0x000FFFFF
#define DCREG_FRAME_BUFFER_WATER_MARK_ReadMask                        0x000FFFFF
#define DCREG_FRAME_BUFFER_WATER_MARK_WriteMask                       0x000FFFFF
#define DCREG_FRAME_BUFFER_WATER_MARK_ResetValue                      0x00000000

#define DCREG_FRAME_BUFFER_WATER_MARK_VALUE                                 19:0
#define DCREG_FRAME_BUFFER_WATER_MARK_VALUE_End                               19
#define DCREG_FRAME_BUFFER_WATER_MARK_VALUE_Start                              0
#define DCREG_FRAME_BUFFER_WATER_MARK_VALUE_Type                             U20



#define dcregGammaExIndexRegAddrs                                         0x073C
#define DCREG_GAMMA_EX_INDEX_Address                                     0x01CF0
#define DCREG_GAMMA_EX_INDEX_MSB                                              15
#define DCREG_GAMMA_EX_INDEX_LSB                                               1
#define DCREG_GAMMA_EX_INDEX_BLK                                               1
#define DCREG_GAMMA_EX_INDEX_Count                                             2
#define DCREG_GAMMA_EX_INDEX_FieldMask                                0x000001FF
#define DCREG_GAMMA_EX_INDEX_ReadMask                                 0x00000000
#define DCREG_GAMMA_EX_INDEX_WriteMask                                0x000001FF
#define DCREG_GAMMA_EX_INDEX_ResetValue                               0x00000000


#define DCREG_GAMMA_EX_INDEX_INDEX                                           8:0
#define DCREG_GAMMA_EX_INDEX_INDEX_End                                         8
#define DCREG_GAMMA_EX_INDEX_INDEX_Start                                       0
#define DCREG_GAMMA_EX_INDEX_INDEX_Type                                      U09



#define dcregGammaExDataRegAddrs                                          0x073E
#define DCREG_GAMMA_EX_DATA_Address                                      0x01CF8
#define DCREG_GAMMA_EX_DATA_MSB                                               15
#define DCREG_GAMMA_EX_DATA_LSB                                                1
#define DCREG_GAMMA_EX_DATA_BLK                                                1
#define DCREG_GAMMA_EX_DATA_Count                                              2
#define DCREG_GAMMA_EX_DATA_FieldMask                                 0x0FFF0FFF
#define DCREG_GAMMA_EX_DATA_ReadMask                                  0x00000000
#define DCREG_GAMMA_EX_DATA_WriteMask                                 0x0FFF0FFF
#define DCREG_GAMMA_EX_DATA_ResetValue                                0x00000000


#define DCREG_GAMMA_EX_DATA_BLUE                                            11:0
#define DCREG_GAMMA_EX_DATA_BLUE_End                                          11
#define DCREG_GAMMA_EX_DATA_BLUE_Start                                         0
#define DCREG_GAMMA_EX_DATA_BLUE_Type                                        U12


#define DCREG_GAMMA_EX_DATA_GREEN                                          27:16
#define DCREG_GAMMA_EX_DATA_GREEN_End                                         27
#define DCREG_GAMMA_EX_DATA_GREEN_Start                                       16
#define DCREG_GAMMA_EX_DATA_GREEN_Type                                       U12

#define dcregOverlayROIOriginRegAddrs                                     0x0740
#define DCREG_OVERLAY_ROI_ORIGIN_Address                                 0x01D00
#define DCREG_OVERLAY_ROI_ORIGIN_MSB                                          15
#define DCREG_OVERLAY_ROI_ORIGIN_LSB                                           4
#define DCREG_OVERLAY_ROI_ORIGIN_BLK                                           4
#define DCREG_OVERLAY_ROI_ORIGIN_Count                                        16
#define DCREG_OVERLAY_ROI_ORIGIN_FieldMask                            0xFFFFFFFF
#define DCREG_OVERLAY_ROI_ORIGIN_ReadMask                             0xFFFFFFFF
#define DCREG_OVERLAY_ROI_ORIGIN_WriteMask                            0xFFFFFFFF
#define DCREG_OVERLAY_ROI_ORIGIN_ResetValue                           0x00000000


#define DCREG_OVERLAY_ROI_ORIGIN_X                                          15:0
#define DCREG_OVERLAY_ROI_ORIGIN_X_End                                        15
#define DCREG_OVERLAY_ROI_ORIGIN_X_Start                                       0
#define DCREG_OVERLAY_ROI_ORIGIN_X_Type                                      U16


#define DCREG_OVERLAY_ROI_ORIGIN_Y                                         31:16
#define DCREG_OVERLAY_ROI_ORIGIN_Y_End                                        31
#define DCREG_OVERLAY_ROI_ORIGIN_Y_Start                                      16
#define DCREG_OVERLAY_ROI_ORIGIN_Y_Type                                      U16

#define dcregOverlayROISizeRegAddrs                                       0x0750
#define DCREG_OVERLAY_ROI_SIZE_Address                                   0x01D40
#define DCREG_OVERLAY_ROI_SIZE_MSB                                            15
#define DCREG_OVERLAY_ROI_SIZE_LSB                                             4
#define DCREG_OVERLAY_ROI_SIZE_BLK                                             4
#define DCREG_OVERLAY_ROI_SIZE_Count                                          16
#define DCREG_OVERLAY_ROI_SIZE_FieldMask                              0xFFFFFFFF
#define DCREG_OVERLAY_ROI_SIZE_ReadMask                               0xFFFFFFFF
#define DCREG_OVERLAY_ROI_SIZE_WriteMask                              0xFFFFFFFF
#define DCREG_OVERLAY_ROI_SIZE_ResetValue                             0x00000000


#define DCREG_OVERLAY_ROI_SIZE_WIDTH                                        15:0
#define DCREG_OVERLAY_ROI_SIZE_WIDTH_End                                      15
#define DCREG_OVERLAY_ROI_SIZE_WIDTH_Start                                     0
#define DCREG_OVERLAY_ROI_SIZE_WIDTH_Type                                    U16


#define DCREG_OVERLAY_ROI_SIZE_HEIGHT                                      31:16
#define DCREG_OVERLAY_ROI_SIZE_HEIGHT_End                                     31
#define DCREG_OVERLAY_ROI_SIZE_HEIGHT_Start                                   16
#define DCREG_OVERLAY_ROI_SIZE_HEIGHT_Type                                   U16



#define dcregGammaExOneDataRegAddrs                                       0x0760
#define DCREG_GAMMA_EX_ONE_DATA_Address                                  0x01D80
#define DCREG_GAMMA_EX_ONE_DATA_MSB                                           15
#define DCREG_GAMMA_EX_ONE_DATA_LSB                                            1
#define DCREG_GAMMA_EX_ONE_DATA_BLK                                            1
#define DCREG_GAMMA_EX_ONE_DATA_Count                                          2
#define DCREG_GAMMA_EX_ONE_DATA_FieldMask                             0x00000FFF
#define DCREG_GAMMA_EX_ONE_DATA_ReadMask                              0x00000000
#define DCREG_GAMMA_EX_ONE_DATA_WriteMask                             0x00000FFF
#define DCREG_GAMMA_EX_ONE_DATA_ResetValue                            0x00000000


#define DCREG_GAMMA_EX_ONE_DATA_RED                                         11:0
#define DCREG_GAMMA_EX_ONE_DATA_RED_End                                       11
#define DCREG_GAMMA_EX_ONE_DATA_RED_Start                                      0
#define DCREG_GAMMA_EX_ONE_DATA_RED_Type                                     U12



#define dcregDeGammaIndexRegAddrs                                         0x0762
#define DCREG_DE_GAMMA_INDEX_Address                                     0x01D88
#define DCREG_DE_GAMMA_INDEX_MSB                                              15
#define DCREG_DE_GAMMA_INDEX_LSB                                               1
#define DCREG_DE_GAMMA_INDEX_BLK                                               1
#define DCREG_DE_GAMMA_INDEX_Count                                             2
#define DCREG_DE_GAMMA_INDEX_FieldMask                                0x000001FF
#define DCREG_DE_GAMMA_INDEX_ReadMask                                 0x00000000
#define DCREG_DE_GAMMA_INDEX_WriteMask                                0x000001FF
#define DCREG_DE_GAMMA_INDEX_ResetValue                               0x00000000


#define DCREG_DE_GAMMA_INDEX_INDEX                                           8:0
#define DCREG_DE_GAMMA_INDEX_INDEX_End                                         8
#define DCREG_DE_GAMMA_INDEX_INDEX_Start                                       0
#define DCREG_DE_GAMMA_INDEX_INDEX_Type                                      U09



#define dcregDeGammaDataRegAddrs                                          0x0764
#define DCREG_DE_GAMMA_DATA_Address                                      0x01D90
#define DCREG_DE_GAMMA_DATA_MSB                                               15
#define DCREG_DE_GAMMA_DATA_LSB                                                1
#define DCREG_DE_GAMMA_DATA_BLK                                                1
#define DCREG_DE_GAMMA_DATA_Count                                              2
#define DCREG_DE_GAMMA_DATA_FieldMask                                 0x3FFFFFFF
#define DCREG_DE_GAMMA_DATA_ReadMask                                  0x00000000
#define DCREG_DE_GAMMA_DATA_WriteMask                                 0x3FFFFFFF
#define DCREG_DE_GAMMA_DATA_ResetValue                                0x00000000


#define DCREG_DE_GAMMA_DATA_BLUE                                            14:0
#define DCREG_DE_GAMMA_DATA_BLUE_End                                          14
#define DCREG_DE_GAMMA_DATA_BLUE_Start                                         0
#define DCREG_DE_GAMMA_DATA_BLUE_Type                                        U15


#define DCREG_DE_GAMMA_DATA_GREEN                                          29:15
#define DCREG_DE_GAMMA_DATA_GREEN_End                                         29
#define DCREG_DE_GAMMA_DATA_GREEN_Start                                       15
#define DCREG_DE_GAMMA_DATA_GREEN_Type                                       U15



#define dcregDeGammaExDataRegAddrs                                        0x0766
#define DCREG_DE_GAMMA_EX_DATA_Address                                   0x01D98
#define DCREG_DE_GAMMA_EX_DATA_MSB                                            15
#define DCREG_DE_GAMMA_EX_DATA_LSB                                             1
#define DCREG_DE_GAMMA_EX_DATA_BLK                                             1
#define DCREG_DE_GAMMA_EX_DATA_Count                                           2
#define DCREG_DE_GAMMA_EX_DATA_FieldMask                              0x00007FFF
#define DCREG_DE_GAMMA_EX_DATA_ReadMask                               0x00000000
#define DCREG_DE_GAMMA_EX_DATA_WriteMask                              0x00007FFF
#define DCREG_DE_GAMMA_EX_DATA_ResetValue                             0x00000000


#define DCREG_DE_GAMMA_EX_DATA_RED                                          14:0
#define DCREG_DE_GAMMA_EX_DATA_RED_End                                        14
#define DCREG_DE_GAMMA_EX_DATA_RED_Start                                       0
#define DCREG_DE_GAMMA_EX_DATA_RED_Type                                      U15




#define dcregFrameYUVToRGBCoef0RegAddrs                                   0x0768
#define DCREG_FRAME_YUV_TO_RGB_COEF0_Address                             0x01DA0
#define DCREG_FRAME_YUV_TO_RGB_COEF0_MSB                                      15
#define DCREG_FRAME_YUV_TO_RGB_COEF0_LSB                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF0_BLK                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF0_Count                                     2
#define DCREG_FRAME_YUV_TO_RGB_COEF0_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF0_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF0_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF0_ResetValue                       0x00000000

#define DCREG_FRAME_YUV_TO_RGB_COEF0_COEFFICIENT0                           15:0
#define DCREG_FRAME_YUV_TO_RGB_COEF0_COEFFICIENT0_End                         15
#define DCREG_FRAME_YUV_TO_RGB_COEF0_COEFFICIENT0_Start                        0
#define DCREG_FRAME_YUV_TO_RGB_COEF0_COEFFICIENT0_Type                       U16

#define DCREG_FRAME_YUV_TO_RGB_COEF0_COEFFICIENT1                          31:16
#define DCREG_FRAME_YUV_TO_RGB_COEF0_COEFFICIENT1_End                         31
#define DCREG_FRAME_YUV_TO_RGB_COEF0_COEFFICIENT1_Start                       16
#define DCREG_FRAME_YUV_TO_RGB_COEF0_COEFFICIENT1_Type                       U16




#define dcregFrameYUVToRGBCoef1RegAddrs                                   0x076A
#define DCREG_FRAME_YUV_TO_RGB_COEF1_Address                             0x01DA8
#define DCREG_FRAME_YUV_TO_RGB_COEF1_MSB                                      15
#define DCREG_FRAME_YUV_TO_RGB_COEF1_LSB                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF1_BLK                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF1_Count                                     2
#define DCREG_FRAME_YUV_TO_RGB_COEF1_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF1_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF1_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF1_ResetValue                       0x00000000

#define DCREG_FRAME_YUV_TO_RGB_COEF1_COEFFICIENT2                           15:0
#define DCREG_FRAME_YUV_TO_RGB_COEF1_COEFFICIENT2_End                         15
#define DCREG_FRAME_YUV_TO_RGB_COEF1_COEFFICIENT2_Start                        0
#define DCREG_FRAME_YUV_TO_RGB_COEF1_COEFFICIENT2_Type                       U16

#define DCREG_FRAME_YUV_TO_RGB_COEF1_COEFFICIENT3                          31:16
#define DCREG_FRAME_YUV_TO_RGB_COEF1_COEFFICIENT3_End                         31
#define DCREG_FRAME_YUV_TO_RGB_COEF1_COEFFICIENT3_Start                       16
#define DCREG_FRAME_YUV_TO_RGB_COEF1_COEFFICIENT3_Type                       U16




#define dcregFrameYUVToRGBCoef2RegAddrs                                   0x076C
#define DCREG_FRAME_YUV_TO_RGB_COEF2_Address                             0x01DB0
#define DCREG_FRAME_YUV_TO_RGB_COEF2_MSB                                      15
#define DCREG_FRAME_YUV_TO_RGB_COEF2_LSB                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF2_BLK                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF2_Count                                     2
#define DCREG_FRAME_YUV_TO_RGB_COEF2_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF2_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF2_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF2_ResetValue                       0x00000000

#define DCREG_FRAME_YUV_TO_RGB_COEF2_COEFFICIENT4                           15:0
#define DCREG_FRAME_YUV_TO_RGB_COEF2_COEFFICIENT4_End                         15
#define DCREG_FRAME_YUV_TO_RGB_COEF2_COEFFICIENT4_Start                        0
#define DCREG_FRAME_YUV_TO_RGB_COEF2_COEFFICIENT4_Type                       U16

#define DCREG_FRAME_YUV_TO_RGB_COEF2_COEFFICIENT5                          31:16
#define DCREG_FRAME_YUV_TO_RGB_COEF2_COEFFICIENT5_End                         31
#define DCREG_FRAME_YUV_TO_RGB_COEF2_COEFFICIENT5_Start                       16
#define DCREG_FRAME_YUV_TO_RGB_COEF2_COEFFICIENT5_Type                       U16




#define dcregFrameYUVToRGBCoef3RegAddrs                                   0x076E
#define DCREG_FRAME_YUV_TO_RGB_COEF3_Address                             0x01DB8
#define DCREG_FRAME_YUV_TO_RGB_COEF3_MSB                                      15
#define DCREG_FRAME_YUV_TO_RGB_COEF3_LSB                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF3_BLK                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF3_Count                                     2
#define DCREG_FRAME_YUV_TO_RGB_COEF3_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF3_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF3_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF3_ResetValue                       0x00000000

#define DCREG_FRAME_YUV_TO_RGB_COEF3_COEFFICIENT6                           15:0
#define DCREG_FRAME_YUV_TO_RGB_COEF3_COEFFICIENT6_End                         15
#define DCREG_FRAME_YUV_TO_RGB_COEF3_COEFFICIENT6_Start                        0
#define DCREG_FRAME_YUV_TO_RGB_COEF3_COEFFICIENT6_Type                       U16

#define DCREG_FRAME_YUV_TO_RGB_COEF3_COEFFICIENT7                          31:16
#define DCREG_FRAME_YUV_TO_RGB_COEF3_COEFFICIENT7_End                         31
#define DCREG_FRAME_YUV_TO_RGB_COEF3_COEFFICIENT7_Start                       16
#define DCREG_FRAME_YUV_TO_RGB_COEF3_COEFFICIENT7_Type                       U16




#define dcregOverlayWaterMarkRegAddrs                                     0x0770
#define DCREG_OVERLAY_WATER_MARK_Address                                 0x01DC0
#define DCREG_OVERLAY_WATER_MARK_MSB                                          15
#define DCREG_OVERLAY_WATER_MARK_LSB                                           4
#define DCREG_OVERLAY_WATER_MARK_BLK                                           4
#define DCREG_OVERLAY_WATER_MARK_Count                                        16
#define DCREG_OVERLAY_WATER_MARK_FieldMask                            0x000FFFFF
#define DCREG_OVERLAY_WATER_MARK_ReadMask                             0x000FFFFF
#define DCREG_OVERLAY_WATER_MARK_WriteMask                            0x000FFFFF
#define DCREG_OVERLAY_WATER_MARK_ResetValue                           0x00000000

#define DCREG_OVERLAY_WATER_MARK_VALUE                                      19:0
#define DCREG_OVERLAY_WATER_MARK_VALUE_End                                    19
#define DCREG_OVERLAY_WATER_MARK_VALUE_Start                                   0
#define DCREG_OVERLAY_WATER_MARK_VALUE_Type                                  U20




#define dcregFrameYUVToRGBCoef4RegAddrs                                   0x0780
#define DCREG_FRAME_YUV_TO_RGB_COEF4_Address                             0x01E00
#define DCREG_FRAME_YUV_TO_RGB_COEF4_MSB                                      15
#define DCREG_FRAME_YUV_TO_RGB_COEF4_LSB                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF4_BLK                                       1
#define DCREG_FRAME_YUV_TO_RGB_COEF4_Count                                     2
#define DCREG_FRAME_YUV_TO_RGB_COEF4_FieldMask                        0x0000FFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF4_ReadMask                         0x0000FFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF4_WriteMask                        0x0000FFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF4_ResetValue                       0x00000000

#define DCREG_FRAME_YUV_TO_RGB_COEF4_COEFFICIENT8                           15:0
#define DCREG_FRAME_YUV_TO_RGB_COEF4_COEFFICIENT8_End                         15
#define DCREG_FRAME_YUV_TO_RGB_COEF4_COEFFICIENT8_Start                        0
#define DCREG_FRAME_YUV_TO_RGB_COEF4_COEFFICIENT8_Type                       U16




#define dcregFrameYUVToRGBCoefD0RegAddrs                                  0x0782
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_Address                           0x01E08
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_MSB                                    15
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_LSB                                     1
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_BLK                                     1
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_Count                                   2
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_FieldMask                      0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_ReadMask                       0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_WriteMask                      0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_ResetValue                     0x00000000

#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_COEFFICIENT                          25:0
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_COEFFICIENT_End                        25
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_COEFFICIENT_Start                       0
#define DCREG_FRAME_YUV_TO_RGB_COEF_D0_COEFFICIENT_Type                      U26




#define dcregFrameYUVToRGBCoefD1RegAddrs                                  0x0784
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_Address                           0x01E10
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_MSB                                    15
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_LSB                                     1
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_BLK                                     1
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_Count                                   2
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_FieldMask                      0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_ReadMask                       0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_WriteMask                      0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_ResetValue                     0x00000000

#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_COEFFICIENT                          25:0
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_COEFFICIENT_End                        25
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_COEFFICIENT_Start                       0
#define DCREG_FRAME_YUV_TO_RGB_COEF_D1_COEFFICIENT_Type                      U26




#define dcregFrameYUVToRGBCoefD2RegAddrs                                  0x0786
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_Address                           0x01E18
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_MSB                                    15
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_LSB                                     1
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_BLK                                     1
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_Count                                   2
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_FieldMask                      0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_ReadMask                       0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_WriteMask                      0x03FFFFFF
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_ResetValue                     0x00000000

#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_COEFFICIENT                          25:0
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_COEFFICIENT_End                        25
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_COEFFICIENT_Start                       0
#define DCREG_FRAME_YUV_TO_RGB_COEF_D2_COEFFICIENT_Type                      U26




#define dcregFrameRGBToRGBCoef0RegAddrs                                   0x0788
#define DCREG_FRAME_RGB_TO_RGB_COEF0_Address                             0x01E20
#define DCREG_FRAME_RGB_TO_RGB_COEF0_MSB                                      15
#define DCREG_FRAME_RGB_TO_RGB_COEF0_LSB                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF0_BLK                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF0_Count                                     2
#define DCREG_FRAME_RGB_TO_RGB_COEF0_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF0_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF0_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF0_ResetValue                       0x00000000

#define DCREG_FRAME_RGB_TO_RGB_COEF0_COEFFICIENT0                           15:0
#define DCREG_FRAME_RGB_TO_RGB_COEF0_COEFFICIENT0_End                         15
#define DCREG_FRAME_RGB_TO_RGB_COEF0_COEFFICIENT0_Start                        0
#define DCREG_FRAME_RGB_TO_RGB_COEF0_COEFFICIENT0_Type                       U16

#define DCREG_FRAME_RGB_TO_RGB_COEF0_COEFFICIENT1                          31:16
#define DCREG_FRAME_RGB_TO_RGB_COEF0_COEFFICIENT1_End                         31
#define DCREG_FRAME_RGB_TO_RGB_COEF0_COEFFICIENT1_Start                       16
#define DCREG_FRAME_RGB_TO_RGB_COEF0_COEFFICIENT1_Type                       U16




#define dcregFrameRGBToRGBCoef1RegAddrs                                   0x078A
#define DCREG_FRAME_RGB_TO_RGB_COEF1_Address                             0x01E28
#define DCREG_FRAME_RGB_TO_RGB_COEF1_MSB                                      15
#define DCREG_FRAME_RGB_TO_RGB_COEF1_LSB                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF1_BLK                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF1_Count                                     2
#define DCREG_FRAME_RGB_TO_RGB_COEF1_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF1_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF1_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF1_ResetValue                       0x00000000

#define DCREG_FRAME_RGB_TO_RGB_COEF1_COEFFICIENT2                           15:0
#define DCREG_FRAME_RGB_TO_RGB_COEF1_COEFFICIENT2_End                         15
#define DCREG_FRAME_RGB_TO_RGB_COEF1_COEFFICIENT2_Start                        0
#define DCREG_FRAME_RGB_TO_RGB_COEF1_COEFFICIENT2_Type                       U16

#define DCREG_FRAME_RGB_TO_RGB_COEF1_COEFFICIENT3                          31:16
#define DCREG_FRAME_RGB_TO_RGB_COEF1_COEFFICIENT3_End                         31
#define DCREG_FRAME_RGB_TO_RGB_COEF1_COEFFICIENT3_Start                       16
#define DCREG_FRAME_RGB_TO_RGB_COEF1_COEFFICIENT3_Type                       U16




#define dcregFrameRGBToRGBCoef2RegAddrs                                   0x078C
#define DCREG_FRAME_RGB_TO_RGB_COEF2_Address                             0x01E30
#define DCREG_FRAME_RGB_TO_RGB_COEF2_MSB                                      15
#define DCREG_FRAME_RGB_TO_RGB_COEF2_LSB                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF2_BLK                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF2_Count                                     2
#define DCREG_FRAME_RGB_TO_RGB_COEF2_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF2_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF2_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF2_ResetValue                       0x00000000

#define DCREG_FRAME_RGB_TO_RGB_COEF2_COEFFICIENT4                           15:0
#define DCREG_FRAME_RGB_TO_RGB_COEF2_COEFFICIENT4_End                         15
#define DCREG_FRAME_RGB_TO_RGB_COEF2_COEFFICIENT4_Start                        0
#define DCREG_FRAME_RGB_TO_RGB_COEF2_COEFFICIENT4_Type                       U16

#define DCREG_FRAME_RGB_TO_RGB_COEF2_COEFFICIENT5                          31:16
#define DCREG_FRAME_RGB_TO_RGB_COEF2_COEFFICIENT5_End                         31
#define DCREG_FRAME_RGB_TO_RGB_COEF2_COEFFICIENT5_Start                       16
#define DCREG_FRAME_RGB_TO_RGB_COEF2_COEFFICIENT5_Type                       U16




#define dcregFrameRGBToRGBCoef3RegAddrs                                   0x078E
#define DCREG_FRAME_RGB_TO_RGB_COEF3_Address                             0x01E38
#define DCREG_FRAME_RGB_TO_RGB_COEF3_MSB                                      15
#define DCREG_FRAME_RGB_TO_RGB_COEF3_LSB                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF3_BLK                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF3_Count                                     2
#define DCREG_FRAME_RGB_TO_RGB_COEF3_FieldMask                        0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF3_ReadMask                         0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF3_WriteMask                        0xFFFFFFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF3_ResetValue                       0x00000000

#define DCREG_FRAME_RGB_TO_RGB_COEF3_COEFFICIENT6                           15:0
#define DCREG_FRAME_RGB_TO_RGB_COEF3_COEFFICIENT6_End                         15
#define DCREG_FRAME_RGB_TO_RGB_COEF3_COEFFICIENT6_Start                        0
#define DCREG_FRAME_RGB_TO_RGB_COEF3_COEFFICIENT6_Type                       U16

#define DCREG_FRAME_RGB_TO_RGB_COEF3_COEFFICIENT7                          31:16
#define DCREG_FRAME_RGB_TO_RGB_COEF3_COEFFICIENT7_End                         31
#define DCREG_FRAME_RGB_TO_RGB_COEF3_COEFFICIENT7_Start                       16
#define DCREG_FRAME_RGB_TO_RGB_COEF3_COEFFICIENT7_Type                       U16




#define dcregFrameRGBToRGBCoef4RegAddrs                                   0x0790
#define DCREG_FRAME_RGB_TO_RGB_COEF4_Address                             0x01E40
#define DCREG_FRAME_RGB_TO_RGB_COEF4_MSB                                      15
#define DCREG_FRAME_RGB_TO_RGB_COEF4_LSB                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF4_BLK                                       1
#define DCREG_FRAME_RGB_TO_RGB_COEF4_Count                                     2
#define DCREG_FRAME_RGB_TO_RGB_COEF4_FieldMask                        0x0000FFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF4_ReadMask                         0x0000FFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF4_WriteMask                        0x0000FFFF
#define DCREG_FRAME_RGB_TO_RGB_COEF4_ResetValue                       0x00000000

#define DCREG_FRAME_RGB_TO_RGB_COEF4_COEFFICIENT8                           15:0
#define DCREG_FRAME_RGB_TO_RGB_COEF4_COEFFICIENT8_End                         15
#define DCREG_FRAME_RGB_TO_RGB_COEF4_COEFFICIENT8_Start                        0
#define DCREG_FRAME_RGB_TO_RGB_COEF4_COEFFICIENT8_Type                       U16




#define dcregRGBToYUVCoef0RegAddrs                                        0x0792
#define DCREG_RGB_TO_YUV_COEF0_Address                                   0x01E48
#define DCREG_RGB_TO_YUV_COEF0_MSB                                            15
#define DCREG_RGB_TO_YUV_COEF0_LSB                                             1
#define DCREG_RGB_TO_YUV_COEF0_BLK                                             1
#define DCREG_RGB_TO_YUV_COEF0_Count                                           2
#define DCREG_RGB_TO_YUV_COEF0_FieldMask                              0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF0_ReadMask                               0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF0_WriteMask                              0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF0_ResetValue                             0x00000000

#define DCREG_RGB_TO_YUV_COEF0_COEFFICIENT0                                 15:0
#define DCREG_RGB_TO_YUV_COEF0_COEFFICIENT0_End                               15
#define DCREG_RGB_TO_YUV_COEF0_COEFFICIENT0_Start                              0
#define DCREG_RGB_TO_YUV_COEF0_COEFFICIENT0_Type                             U16

#define DCREG_RGB_TO_YUV_COEF0_COEFFICIENT1                                31:16
#define DCREG_RGB_TO_YUV_COEF0_COEFFICIENT1_End                               31
#define DCREG_RGB_TO_YUV_COEF0_COEFFICIENT1_Start                             16
#define DCREG_RGB_TO_YUV_COEF0_COEFFICIENT1_Type                             U16




#define dcregRGBToYUVCoef1RegAddrs                                        0x0794
#define DCREG_RGB_TO_YUV_COEF1_Address                                   0x01E50
#define DCREG_RGB_TO_YUV_COEF1_MSB                                            15
#define DCREG_RGB_TO_YUV_COEF1_LSB                                             1
#define DCREG_RGB_TO_YUV_COEF1_BLK                                             1
#define DCREG_RGB_TO_YUV_COEF1_Count                                           2
#define DCREG_RGB_TO_YUV_COEF1_FieldMask                              0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF1_ReadMask                               0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF1_WriteMask                              0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF1_ResetValue                             0x00000000

#define DCREG_RGB_TO_YUV_COEF1_COEFFICIENT2                                 15:0
#define DCREG_RGB_TO_YUV_COEF1_COEFFICIENT2_End                               15
#define DCREG_RGB_TO_YUV_COEF1_COEFFICIENT2_Start                              0
#define DCREG_RGB_TO_YUV_COEF1_COEFFICIENT2_Type                             U16

#define DCREG_RGB_TO_YUV_COEF1_COEFFICIENT3                                31:16
#define DCREG_RGB_TO_YUV_COEF1_COEFFICIENT3_End                               31
#define DCREG_RGB_TO_YUV_COEF1_COEFFICIENT3_Start                             16
#define DCREG_RGB_TO_YUV_COEF1_COEFFICIENT3_Type                             U16




#define dcregRGBToYUVCoef2RegAddrs                                        0x0796
#define DCREG_RGB_TO_YUV_COEF2_Address                                   0x01E58
#define DCREG_RGB_TO_YUV_COEF2_MSB                                            15
#define DCREG_RGB_TO_YUV_COEF2_LSB                                             1
#define DCREG_RGB_TO_YUV_COEF2_BLK                                             1
#define DCREG_RGB_TO_YUV_COEF2_Count                                           2
#define DCREG_RGB_TO_YUV_COEF2_FieldMask                              0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF2_ReadMask                               0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF2_WriteMask                              0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF2_ResetValue                             0x00000000

#define DCREG_RGB_TO_YUV_COEF2_COEFFICIENT4                                 15:0
#define DCREG_RGB_TO_YUV_COEF2_COEFFICIENT4_End                               15
#define DCREG_RGB_TO_YUV_COEF2_COEFFICIENT4_Start                              0
#define DCREG_RGB_TO_YUV_COEF2_COEFFICIENT4_Type                             U16

#define DCREG_RGB_TO_YUV_COEF2_COEFFICIENT5                                31:16
#define DCREG_RGB_TO_YUV_COEF2_COEFFICIENT5_End                               31
#define DCREG_RGB_TO_YUV_COEF2_COEFFICIENT5_Start                             16
#define DCREG_RGB_TO_YUV_COEF2_COEFFICIENT5_Type                             U16




#define dcregRGBToYUVCoef3RegAddrs                                        0x0798
#define DCREG_RGB_TO_YUV_COEF3_Address                                   0x01E60
#define DCREG_RGB_TO_YUV_COEF3_MSB                                            15
#define DCREG_RGB_TO_YUV_COEF3_LSB                                             1
#define DCREG_RGB_TO_YUV_COEF3_BLK                                             1
#define DCREG_RGB_TO_YUV_COEF3_Count                                           2
#define DCREG_RGB_TO_YUV_COEF3_FieldMask                              0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF3_ReadMask                               0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF3_WriteMask                              0xFFFFFFFF
#define DCREG_RGB_TO_YUV_COEF3_ResetValue                             0x00000000

#define DCREG_RGB_TO_YUV_COEF3_COEFFICIENT6                                 15:0
#define DCREG_RGB_TO_YUV_COEF3_COEFFICIENT6_End                               15
#define DCREG_RGB_TO_YUV_COEF3_COEFFICIENT6_Start                              0
#define DCREG_RGB_TO_YUV_COEF3_COEFFICIENT6_Type                             U16

#define DCREG_RGB_TO_YUV_COEF3_COEFFICIENT7                                31:16
#define DCREG_RGB_TO_YUV_COEF3_COEFFICIENT7_End                               31
#define DCREG_RGB_TO_YUV_COEF3_COEFFICIENT7_Start                             16
#define DCREG_RGB_TO_YUV_COEF3_COEFFICIENT7_Type                             U16




#define dcregRGBToYUVCoef4RegAddrs                                        0x079A
#define DCREG_RGB_TO_YUV_COEF4_Address                                   0x01E68
#define DCREG_RGB_TO_YUV_COEF4_MSB                                            15
#define DCREG_RGB_TO_YUV_COEF4_LSB                                             1
#define DCREG_RGB_TO_YUV_COEF4_BLK                                             1
#define DCREG_RGB_TO_YUV_COEF4_Count                                           2
#define DCREG_RGB_TO_YUV_COEF4_FieldMask                              0x0000FFFF
#define DCREG_RGB_TO_YUV_COEF4_ReadMask                               0x0000FFFF
#define DCREG_RGB_TO_YUV_COEF4_WriteMask                              0x0000FFFF
#define DCREG_RGB_TO_YUV_COEF4_ResetValue                             0x00000000

#define DCREG_RGB_TO_YUV_COEF4_COEFFICIENT8                                 15:0
#define DCREG_RGB_TO_YUV_COEF4_COEFFICIENT8_End                               15
#define DCREG_RGB_TO_YUV_COEF4_COEFFICIENT8_Start                              0
#define DCREG_RGB_TO_YUV_COEF4_COEFFICIENT8_Type                             U16




#define dcregRGBToYUVCoefD0RegAddrs                                       0x079C
#define DCREG_RGB_TO_YUV_COEF_D0_Address                                 0x01E70
#define DCREG_RGB_TO_YUV_COEF_D0_MSB                                          15
#define DCREG_RGB_TO_YUV_COEF_D0_LSB                                           1
#define DCREG_RGB_TO_YUV_COEF_D0_BLK                                           1
#define DCREG_RGB_TO_YUV_COEF_D0_Count                                         2
#define DCREG_RGB_TO_YUV_COEF_D0_FieldMask                            0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D0_ReadMask                             0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D0_WriteMask                            0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D0_ResetValue                           0x00000000

#define DCREG_RGB_TO_YUV_COEF_D0_COEFFICIENT                                 9:0
#define DCREG_RGB_TO_YUV_COEF_D0_COEFFICIENT_End                               9
#define DCREG_RGB_TO_YUV_COEF_D0_COEFFICIENT_Start                             0
#define DCREG_RGB_TO_YUV_COEF_D0_COEFFICIENT_Type                            U10




#define dcregRGBToYUVCoefD1RegAddrs                                       0x079E
#define DCREG_RGB_TO_YUV_COEF_D1_Address                                 0x01E78
#define DCREG_RGB_TO_YUV_COEF_D1_MSB                                          15
#define DCREG_RGB_TO_YUV_COEF_D1_LSB                                           1
#define DCREG_RGB_TO_YUV_COEF_D1_BLK                                           1
#define DCREG_RGB_TO_YUV_COEF_D1_Count                                         2
#define DCREG_RGB_TO_YUV_COEF_D1_FieldMask                            0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D1_ReadMask                             0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D1_WriteMask                            0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D1_ResetValue                           0x00000000

#define DCREG_RGB_TO_YUV_COEF_D1_COEFFICIENT                                 9:0
#define DCREG_RGB_TO_YUV_COEF_D1_COEFFICIENT_End                               9
#define DCREG_RGB_TO_YUV_COEF_D1_COEFFICIENT_Start                             0
#define DCREG_RGB_TO_YUV_COEF_D1_COEFFICIENT_Type                            U10




#define dcregRGBToYUVCoefD2RegAddrs                                       0x07A0
#define DCREG_RGB_TO_YUV_COEF_D2_Address                                 0x01E80
#define DCREG_RGB_TO_YUV_COEF_D2_MSB                                          15
#define DCREG_RGB_TO_YUV_COEF_D2_LSB                                           1
#define DCREG_RGB_TO_YUV_COEF_D2_BLK                                           1
#define DCREG_RGB_TO_YUV_COEF_D2_Count                                         2
#define DCREG_RGB_TO_YUV_COEF_D2_FieldMask                            0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D2_ReadMask                             0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D2_WriteMask                            0x000003FF
#define DCREG_RGB_TO_YUV_COEF_D2_ResetValue                           0x00000000

#define DCREG_RGB_TO_YUV_COEF_D2_COEFFICIENT                                 9:0
#define DCREG_RGB_TO_YUV_COEF_D2_COEFFICIENT_End                               9
#define DCREG_RGB_TO_YUV_COEF_D2_COEFFICIENT_Start                             0
#define DCREG_RGB_TO_YUV_COEF_D2_COEFFICIENT_Type                            U10




#define dcregFrameYClampBoundRegAddrs                                     0x07A2
#define DCREG_FRAME_YCLAMP_BOUND_Address                                 0x01E88
#define DCREG_FRAME_YCLAMP_BOUND_MSB                                          15
#define DCREG_FRAME_YCLAMP_BOUND_LSB                                           1
#define DCREG_FRAME_YCLAMP_BOUND_BLK                                           1
#define DCREG_FRAME_YCLAMP_BOUND_Count                                         2
#define DCREG_FRAME_YCLAMP_BOUND_FieldMask                            0x03FF03FF
#define DCREG_FRAME_YCLAMP_BOUND_ReadMask                             0x03FF03FF
#define DCREG_FRAME_YCLAMP_BOUND_WriteMask                            0x03FF03FF
#define DCREG_FRAME_YCLAMP_BOUND_ResetValue                           0x00000000


#define DCREG_FRAME_YCLAMP_BOUND_LVALUE                                      9:0
#define DCREG_FRAME_YCLAMP_BOUND_LVALUE_End                                    9
#define DCREG_FRAME_YCLAMP_BOUND_LVALUE_Start                                  0
#define DCREG_FRAME_YCLAMP_BOUND_LVALUE_Type                                 U10


#define DCREG_FRAME_YCLAMP_BOUND_HVALUE                                    25:16
#define DCREG_FRAME_YCLAMP_BOUND_HVALUE_End                                   25
#define DCREG_FRAME_YCLAMP_BOUND_HVALUE_Start                                 16
#define DCREG_FRAME_YCLAMP_BOUND_HVALUE_Type                                 U10




#define dcregFrameUVClampBoundRegAddrs                                    0x07A4
#define DCREG_FRAME_UV_CLAMP_BOUND_Address                               0x01E90
#define DCREG_FRAME_UV_CLAMP_BOUND_MSB                                        15
#define DCREG_FRAME_UV_CLAMP_BOUND_LSB                                         1
#define DCREG_FRAME_UV_CLAMP_BOUND_BLK                                         1
#define DCREG_FRAME_UV_CLAMP_BOUND_Count                                       2
#define DCREG_FRAME_UV_CLAMP_BOUND_FieldMask                          0x03FF03FF
#define DCREG_FRAME_UV_CLAMP_BOUND_ReadMask                           0x03FF03FF
#define DCREG_FRAME_UV_CLAMP_BOUND_WriteMask                          0x03FF03FF
#define DCREG_FRAME_UV_CLAMP_BOUND_ResetValue                         0x00000000


#define DCREG_FRAME_UV_CLAMP_BOUND_LVALUE                                    9:0
#define DCREG_FRAME_UV_CLAMP_BOUND_LVALUE_End                                  9
#define DCREG_FRAME_UV_CLAMP_BOUND_LVALUE_Start                                0
#define DCREG_FRAME_UV_CLAMP_BOUND_LVALUE_Type                               U10


#define DCREG_FRAME_UV_CLAMP_BOUND_HVALUE                                  25:16
#define DCREG_FRAME_UV_CLAMP_BOUND_HVALUE_End                                 25
#define DCREG_FRAME_UV_CLAMP_BOUND_HVALUE_Start                               16
#define DCREG_FRAME_UV_CLAMP_BOUND_HVALUE_Type                               U10




#define dcregOverlayYUVToRGBCoef0RegAddrs                                 0x07B0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_Address                           0x01EC0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_MSB                                    15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_LSB                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_BLK                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_Count                                  16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_ResetValue                     0x00000000

#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_COEFFICIENT0                         15:0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_COEFFICIENT0_End                       15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_COEFFICIENT0_Start                      0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_COEFFICIENT0_Type                     U16

#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_COEFFICIENT1                        31:16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_COEFFICIENT1_End                       31
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_COEFFICIENT1_Start                     16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF0_COEFFICIENT1_Type                     U16




#define dcregOverlayYUVToRGBCoef1RegAddrs                                 0x07C0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_Address                           0x01F00
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_MSB                                    15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_LSB                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_BLK                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_Count                                  16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_ResetValue                     0x00000000

#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_COEFFICIENT2                         15:0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_COEFFICIENT2_End                       15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_COEFFICIENT2_Start                      0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_COEFFICIENT2_Type                     U16

#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_COEFFICIENT3                        31:16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_COEFFICIENT3_End                       31
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_COEFFICIENT3_Start                     16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF1_COEFFICIENT3_Type                     U16




#define dcregOverlayYUVToRGBCoef2RegAddrs                                 0x07D0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_Address                           0x01F40
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_MSB                                    15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_LSB                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_BLK                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_Count                                  16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_ResetValue                     0x00000000

#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_COEFFICIENT4                         15:0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_COEFFICIENT4_End                       15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_COEFFICIENT4_Start                      0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_COEFFICIENT4_Type                     U16

#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_COEFFICIENT5                        31:16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_COEFFICIENT5_End                       31
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_COEFFICIENT5_Start                     16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF2_COEFFICIENT5_Type                     U16




#define dcregOverlayYUVToRGBCoef3RegAddrs                                 0x07E0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_Address                           0x01F80
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_MSB                                    15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_LSB                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_BLK                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_Count                                  16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_ResetValue                     0x00000000

#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_COEFFICIENT6                         15:0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_COEFFICIENT6_End                       15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_COEFFICIENT6_Start                      0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_COEFFICIENT6_Type                     U16

#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_COEFFICIENT7                        31:16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_COEFFICIENT7_End                       31
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_COEFFICIENT7_Start                     16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF3_COEFFICIENT7_Type                     U16




#define dcregOverlayYUVToRGBCoef4RegAddrs                                 0x07F0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_Address                           0x01FC0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_MSB                                    15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_LSB                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_BLK                                     4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_Count                                  16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_FieldMask                      0x0000FFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_ReadMask                       0x0000FFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_WriteMask                      0x0000FFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_ResetValue                     0x00000000

#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_COEFFICIENT8                         15:0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_COEFFICIENT8_End                       15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_COEFFICIENT8_Start                      0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF4_COEFFICIENT8_Type                     U16




#define dcregOverlayYUVToRGBCoefD0RegAddrs                                0x0800
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_Address                         0x02000
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_MSB                                  15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_LSB                                   4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_BLK                                   4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_Count                                16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_FieldMask                    0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_ReadMask                     0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_WriteMask                    0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_ResetValue                   0x00000000

#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_COEFFICIENT                        25:0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_COEFFICIENT_End                      25
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_COEFFICIENT_Start                     0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D0_COEFFICIENT_Type                    U26




#define dcregOverlayYUVToRGBCoefD1RegAddrs                                0x0810
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_Address                         0x02040
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_MSB                                  15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_LSB                                   4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_BLK                                   4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_Count                                16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_FieldMask                    0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_ReadMask                     0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_WriteMask                    0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_ResetValue                   0x00000000

#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_COEFFICIENT                        25:0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_COEFFICIENT_End                      25
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_COEFFICIENT_Start                     0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D1_COEFFICIENT_Type                    U26




#define dcregOverlayYUVToRGBCoefD2RegAddrs                                0x0820
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_Address                         0x02080
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_MSB                                  15
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_LSB                                   4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_BLK                                   4
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_Count                                16
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_FieldMask                    0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_ReadMask                     0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_WriteMask                    0x03FFFFFF
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_ResetValue                   0x00000000

#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_COEFFICIENT                        25:0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_COEFFICIENT_End                      25
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_COEFFICIENT_Start                     0
#define DCREG_OVERLAY_YUV_TO_RGB_COEF_D2_COEFFICIENT_Type                    U26




#define dcregOverlayRGBToRGBCoef0RegAddrs                                 0x0830
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_Address                           0x020C0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_MSB                                    15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_LSB                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_BLK                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_Count                                  16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_ResetValue                     0x00000000

#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_COEFFICIENT0                         15:0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_COEFFICIENT0_End                       15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_COEFFICIENT0_Start                      0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_COEFFICIENT0_Type                     U16

#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_COEFFICIENT1                        31:16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_COEFFICIENT1_End                       31
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_COEFFICIENT1_Start                     16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF0_COEFFICIENT1_Type                     U16




#define dcregOverlayRGBToRGBCoef1RegAddrs                                 0x0840
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_Address                           0x02100
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_MSB                                    15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_LSB                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_BLK                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_Count                                  16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_ResetValue                     0x00000000

#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_COEFFICIENT2                         15:0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_COEFFICIENT2_End                       15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_COEFFICIENT2_Start                      0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_COEFFICIENT2_Type                     U16

#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_COEFFICIENT3                        31:16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_COEFFICIENT3_End                       31
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_COEFFICIENT3_Start                     16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF1_COEFFICIENT3_Type                     U16




#define dcregOverlayRGBToRGBCoef2RegAddrs                                 0x0850
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_Address                           0x02140
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_MSB                                    15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_LSB                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_BLK                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_Count                                  16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_ResetValue                     0x00000000

#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_COEFFICIENT4                         15:0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_COEFFICIENT4_End                       15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_COEFFICIENT4_Start                      0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_COEFFICIENT4_Type                     U16

#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_COEFFICIENT5                        31:16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_COEFFICIENT5_End                       31
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_COEFFICIENT5_Start                     16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF2_COEFFICIENT5_Type                     U16




#define dcregOverlayRGBToRGBCoef3RegAddrs                                 0x0860
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_Address                           0x02180
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_MSB                                    15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_LSB                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_BLK                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_Count                                  16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_FieldMask                      0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_ReadMask                       0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_WriteMask                      0xFFFFFFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_ResetValue                     0x00000000

#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_COEFFICIENT6                         15:0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_COEFFICIENT6_End                       15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_COEFFICIENT6_Start                      0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_COEFFICIENT6_Type                     U16

#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_COEFFICIENT7                        31:16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_COEFFICIENT7_End                       31
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_COEFFICIENT7_Start                     16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF3_COEFFICIENT7_Type                     U16




#define dcregOverlayRGBToRGBCoef4RegAddrs                                 0x0870
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_Address                           0x021C0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_MSB                                    15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_LSB                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_BLK                                     4
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_Count                                  16
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_FieldMask                      0x0000FFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_ReadMask                       0x0000FFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_WriteMask                      0x0000FFFF
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_ResetValue                     0x00000000

#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_COEFFICIENT8                         15:0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_COEFFICIENT8_End                       15
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_COEFFICIENT8_Start                      0
#define DCREG_OVERLAY_RGB_TO_RGB_COEF4_COEFFICIENT8_Type                     U16



#define dcregOverlayDeGammaIndexRegAddrs                                  0x0880
#define DCREG_OVERLAY_DE_GAMMA_INDEX_Address                             0x02200
#define DCREG_OVERLAY_DE_GAMMA_INDEX_MSB                                      15
#define DCREG_OVERLAY_DE_GAMMA_INDEX_LSB                                       4
#define DCREG_OVERLAY_DE_GAMMA_INDEX_BLK                                       4
#define DCREG_OVERLAY_DE_GAMMA_INDEX_Count                                    16
#define DCREG_OVERLAY_DE_GAMMA_INDEX_FieldMask                        0x000001FF
#define DCREG_OVERLAY_DE_GAMMA_INDEX_ReadMask                         0x00000000
#define DCREG_OVERLAY_DE_GAMMA_INDEX_WriteMask                        0x000001FF
#define DCREG_OVERLAY_DE_GAMMA_INDEX_ResetValue                       0x00000000


#define DCREG_OVERLAY_DE_GAMMA_INDEX_INDEX                                   8:0
#define DCREG_OVERLAY_DE_GAMMA_INDEX_INDEX_End                                 8
#define DCREG_OVERLAY_DE_GAMMA_INDEX_INDEX_Start                               0
#define DCREG_OVERLAY_DE_GAMMA_INDEX_INDEX_Type                              U09



#define dcregOverlayDeGammaDataRegAddrs                                   0x0890
#define DCREG_OVERLAY_DE_GAMMA_DATA_Address                              0x02240
#define DCREG_OVERLAY_DE_GAMMA_DATA_MSB                                       15
#define DCREG_OVERLAY_DE_GAMMA_DATA_LSB                                        4
#define DCREG_OVERLAY_DE_GAMMA_DATA_BLK                                        4
#define DCREG_OVERLAY_DE_GAMMA_DATA_Count                                     16
#define DCREG_OVERLAY_DE_GAMMA_DATA_FieldMask                         0x7FFF7FFF
#define DCREG_OVERLAY_DE_GAMMA_DATA_ReadMask                          0x00000000
#define DCREG_OVERLAY_DE_GAMMA_DATA_WriteMask                         0x7FFF7FFF
#define DCREG_OVERLAY_DE_GAMMA_DATA_ResetValue                        0x00000000


#define DCREG_OVERLAY_DE_GAMMA_DATA_BLUE                                    14:0
#define DCREG_OVERLAY_DE_GAMMA_DATA_BLUE_End                                  14
#define DCREG_OVERLAY_DE_GAMMA_DATA_BLUE_Start                                 0
#define DCREG_OVERLAY_DE_GAMMA_DATA_BLUE_Type                                U15


#define DCREG_OVERLAY_DE_GAMMA_DATA_GREEN                                  30:16
#define DCREG_OVERLAY_DE_GAMMA_DATA_GREEN_End                                 30
#define DCREG_OVERLAY_DE_GAMMA_DATA_GREEN_Start                               16
#define DCREG_OVERLAY_DE_GAMMA_DATA_GREEN_Type                               U15



#define dcregOverlayDeGammaExDataRegAddrs                                 0x08A0
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_Address                           0x02280
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_MSB                                    15
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_LSB                                     4
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_BLK                                     4
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_Count                                  16
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_FieldMask                      0x00007FFF
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_ReadMask                       0x00000000
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_WriteMask                      0x00007FFF
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_ResetValue                     0x00000000


#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_RED                                  14:0
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_RED_End                                14
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_RED_Start                               0
#define DCREG_OVERLAY_DE_GAMMA_EX_DATA_RED_Type                              U15




#define dcregOverlayYClampBoundRegAddrs                                   0x08B0
#define DCREG_OVERLAY_YCLAMP_BOUND_Address                               0x022C0
#define DCREG_OVERLAY_YCLAMP_BOUND_MSB                                        15
#define DCREG_OVERLAY_YCLAMP_BOUND_LSB                                         4
#define DCREG_OVERLAY_YCLAMP_BOUND_BLK                                         4
#define DCREG_OVERLAY_YCLAMP_BOUND_Count                                      16
#define DCREG_OVERLAY_YCLAMP_BOUND_FieldMask                          0x03FF03FF
#define DCREG_OVERLAY_YCLAMP_BOUND_ReadMask                           0x03FF03FF
#define DCREG_OVERLAY_YCLAMP_BOUND_WriteMask                          0x03FF03FF
#define DCREG_OVERLAY_YCLAMP_BOUND_ResetValue                         0x00000000


#define DCREG_OVERLAY_YCLAMP_BOUND_LVALUE                                    9:0
#define DCREG_OVERLAY_YCLAMP_BOUND_LVALUE_End                                  9
#define DCREG_OVERLAY_YCLAMP_BOUND_LVALUE_Start                                0
#define DCREG_OVERLAY_YCLAMP_BOUND_LVALUE_Type                               U10


#define DCREG_OVERLAY_YCLAMP_BOUND_HVALUE                                  25:16
#define DCREG_OVERLAY_YCLAMP_BOUND_HVALUE_End                                 25
#define DCREG_OVERLAY_YCLAMP_BOUND_HVALUE_Start                               16
#define DCREG_OVERLAY_YCLAMP_BOUND_HVALUE_Type                               U10




#define dcregOverlayUVClampBoundRegAddrs                                  0x08C0
#define DCREG_OVERLAY_UV_CLAMP_BOUND_Address                             0x02300
#define DCREG_OVERLAY_UV_CLAMP_BOUND_MSB                                      15
#define DCREG_OVERLAY_UV_CLAMP_BOUND_LSB                                       4
#define DCREG_OVERLAY_UV_CLAMP_BOUND_BLK                                       4
#define DCREG_OVERLAY_UV_CLAMP_BOUND_Count                                    16
#define DCREG_OVERLAY_UV_CLAMP_BOUND_FieldMask                        0x03FF03FF
#define DCREG_OVERLAY_UV_CLAMP_BOUND_ReadMask                         0x03FF03FF
#define DCREG_OVERLAY_UV_CLAMP_BOUND_WriteMask                        0x03FF03FF
#define DCREG_OVERLAY_UV_CLAMP_BOUND_ResetValue                       0x00000000


#define DCREG_OVERLAY_UV_CLAMP_BOUND_LVALUE                                  9:0
#define DCREG_OVERLAY_UV_CLAMP_BOUND_LVALUE_End                                9
#define DCREG_OVERLAY_UV_CLAMP_BOUND_LVALUE_Start                              0
#define DCREG_OVERLAY_UV_CLAMP_BOUND_LVALUE_Type                             U10


#define DCREG_OVERLAY_UV_CLAMP_BOUND_HVALUE                                25:16
#define DCREG_OVERLAY_UV_CLAMP_BOUND_HVALUE_End                               25
#define DCREG_OVERLAY_UV_CLAMP_BOUND_HVALUE_Start                             16
#define DCREG_OVERLAY_UV_CLAMP_BOUND_HVALUE_Type                             U10




#define dcregThreedLutScaleRegAddrs                                       0x07A6
#define DCREG_THREED_LUT_SCALE_Address                                   0x01E98
#define DCREG_THREED_LUT_SCALE_MSB                                            15
#define DCREG_THREED_LUT_SCALE_LSB                                             1
#define DCREG_THREED_LUT_SCALE_BLK                                             1
#define DCREG_THREED_LUT_SCALE_Count                                           2
#define DCREG_THREED_LUT_SCALE_FieldMask                              0x3FFFFFFF
#define DCREG_THREED_LUT_SCALE_ReadMask                               0x3FFFFFFF
#define DCREG_THREED_LUT_SCALE_WriteMask                              0x3FFFFFFF
#define DCREG_THREED_LUT_SCALE_ResetValue                             0x10040100

#define DCREG_THREED_LUT_SCALE_B                                             9:0
#define DCREG_THREED_LUT_SCALE_B_End                                           9
#define DCREG_THREED_LUT_SCALE_B_Start                                         0
#define DCREG_THREED_LUT_SCALE_B_Type                                        U10

#define DCREG_THREED_LUT_SCALE_G                                           19:10
#define DCREG_THREED_LUT_SCALE_G_End                                          19
#define DCREG_THREED_LUT_SCALE_G_Start                                        10
#define DCREG_THREED_LUT_SCALE_G_Type                                        U10

#define DCREG_THREED_LUT_SCALE_R                                           29:20
#define DCREG_THREED_LUT_SCALE_R_End                                          29
#define DCREG_THREED_LUT_SCALE_R_Start                                        20
#define DCREG_THREED_LUT_SCALE_R_Type                                        U10




#define dcregThreedLutOffsetRegAddrs                                      0x07A8
#define DCREG_THREED_LUT_OFFSET_Address                                  0x01EA0
#define DCREG_THREED_LUT_OFFSET_MSB                                           15
#define DCREG_THREED_LUT_OFFSET_LSB                                            1
#define DCREG_THREED_LUT_OFFSET_BLK                                            1
#define DCREG_THREED_LUT_OFFSET_Count                                          2
#define DCREG_THREED_LUT_OFFSET_FieldMask                             0x0FFF0FFF
#define DCREG_THREED_LUT_OFFSET_ReadMask                              0x0FFF0FFF
#define DCREG_THREED_LUT_OFFSET_WriteMask                             0x0FFF0FFF
#define DCREG_THREED_LUT_OFFSET_ResetValue                            0x00000000

#define DCREG_THREED_LUT_OFFSET_B                                           11:0
#define DCREG_THREED_LUT_OFFSET_B_End                                         11
#define DCREG_THREED_LUT_OFFSET_B_Start                                        0
#define DCREG_THREED_LUT_OFFSET_B_Type                                       U12

#define DCREG_THREED_LUT_OFFSET_G                                          27:16
#define DCREG_THREED_LUT_OFFSET_G_End                                         27
#define DCREG_THREED_LUT_OFFSET_G_Start                                       16
#define DCREG_THREED_LUT_OFFSET_G_Type                                       U12




#define dcregThreedLutOffsetExRegAddrs                                    0x07AA
#define DCREG_THREED_LUT_OFFSET_EX_Address                               0x01EA8
#define DCREG_THREED_LUT_OFFSET_EX_MSB                                        15
#define DCREG_THREED_LUT_OFFSET_EX_LSB                                         1
#define DCREG_THREED_LUT_OFFSET_EX_BLK                                         1
#define DCREG_THREED_LUT_OFFSET_EX_Count                                       2
#define DCREG_THREED_LUT_OFFSET_EX_FieldMask                          0x00000FFF
#define DCREG_THREED_LUT_OFFSET_EX_ReadMask                           0x00000FFF
#define DCREG_THREED_LUT_OFFSET_EX_WriteMask                          0x00000FFF
#define DCREG_THREED_LUT_OFFSET_EX_ResetValue                         0x00000000

#define DCREG_THREED_LUT_OFFSET_EX_R                                        11:0
#define DCREG_THREED_LUT_OFFSET_EX_R_End                                      11
#define DCREG_THREED_LUT_OFFSET_EX_R_Start                                     0
#define DCREG_THREED_LUT_OFFSET_EX_R_Type                                    U12


#endif


