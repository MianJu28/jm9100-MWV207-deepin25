/*
 * JMGPU driver
 *
 * Copyright (c) 2020 ChangSha JingJiaMicro Electronics Co., Ltd.
 * All rights reserved.
 *
 * Author:
 *      wj <jjwgpu@jingjiamicro.com>
 *
 * The software and information contained herein is proprietary and
 * confidential to JingJiaMicro Electronics. This software can only be
 * used by JingJiaMicro Electronics Corporation. Any use, reproduction,
 * or disclosure without the written permission of JingJiaMicro
 * Electronics Corporation is strictly prohibited.
 *
 */




#ifndef __AQTexture_h__
#define __AQTexture_h__


#define AQTextureSampleModeRegAddrs                                       0x0800
#define AQ_TEXTURE_SAMPLE_MODE_Address                                   0x02000
#define AQ_TEXTURE_SAMPLE_MODE_MSB                                            15
#define AQ_TEXTURE_SAMPLE_MODE_LSB                                             4
#define AQ_TEXTURE_SAMPLE_MODE_BLK                                             4
#define AQ_TEXTURE_SAMPLE_MODE_Count                                          16
#define AQ_TEXTURE_SAMPLE_MODE_FieldMask                              0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_MODE_ReadMask                               0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_MODE_WriteMask                              0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_MODE_ResetValue                             0x00000000


#define AQ_TEXTURE_SAMPLE_MODE_TYPE                                          2:0
#define AQ_TEXTURE_SAMPLE_MODE_TYPE_End                                        2
#define AQ_TEXTURE_SAMPLE_MODE_TYPE_Start                                      0
#define AQ_TEXTURE_SAMPLE_MODE_TYPE_Type                                     U03
#define   AQ_TEXTURE_SAMPLE_MODE_TYPE_NONE                                   0x0
#define   AQ_TEXTURE_SAMPLE_MODE_TYPE_1D                                     0x1
#define   AQ_TEXTURE_SAMPLE_MODE_TYPE_2D                                     0x2
#define   AQ_TEXTURE_SAMPLE_MODE_TYPE_3D                                     0x3
#define   AQ_TEXTURE_SAMPLE_MODE_TYPE_PROJECTED                              0x4
#define   AQ_TEXTURE_SAMPLE_MODE_TYPE_CUBIC_MAP                              0x5


#define AQ_TEXTURE_SAMPLE_MODE_ADDR_UMODE                                    4:3
#define AQ_TEXTURE_SAMPLE_MODE_ADDR_UMODE_End                                  4
#define AQ_TEXTURE_SAMPLE_MODE_ADDR_UMODE_Start                                3
#define AQ_TEXTURE_SAMPLE_MODE_ADDR_UMODE_Type                               U02
#define   AQ_TEXTURE_SAMPLE_MODE_ADDR_UMODE_WRAP                             0x0
#define   AQ_TEXTURE_SAMPLE_MODE_ADDR_UMODE_MIRROR                           0x1
#define   AQ_TEXTURE_SAMPLE_MODE_ADDR_UMODE_CLAMP                            0x2
#define   AQ_TEXTURE_SAMPLE_MODE_ADDR_UMODE_BORDER                           0x3


#define AQ_TEXTURE_SAMPLE_MODE_ADDR_VMODE                                    6:5
#define AQ_TEXTURE_SAMPLE_MODE_ADDR_VMODE_End                                  6
#define AQ_TEXTURE_SAMPLE_MODE_ADDR_VMODE_Start                                5
#define AQ_TEXTURE_SAMPLE_MODE_ADDR_VMODE_Type                               U02
#define   AQ_TEXTURE_SAMPLE_MODE_ADDR_VMODE_WRAP                             0x0
#define   AQ_TEXTURE_SAMPLE_MODE_ADDR_VMODE_MIRROR                           0x1
#define   AQ_TEXTURE_SAMPLE_MODE_ADDR_VMODE_CLAMP                            0x2
#define   AQ_TEXTURE_SAMPLE_MODE_ADDR_VMODE_BORDER                           0x3


#define AQ_TEXTURE_SAMPLE_MODE_MIN_FILTER                                    8:7
#define AQ_TEXTURE_SAMPLE_MODE_MIN_FILTER_End                                  8
#define AQ_TEXTURE_SAMPLE_MODE_MIN_FILTER_Start                                7
#define AQ_TEXTURE_SAMPLE_MODE_MIN_FILTER_Type                               U02
#define   AQ_TEXTURE_SAMPLE_MODE_MIN_FILTER_NONE                             0x0
#define   AQ_TEXTURE_SAMPLE_MODE_MIN_FILTER_POINT                            0x1
#define   AQ_TEXTURE_SAMPLE_MODE_MIN_FILTER_LINEAR                           0x2
#define   AQ_TEXTURE_SAMPLE_MODE_MIN_FILTER_ANISOTROPIC                      0x3


#define AQ_TEXTURE_SAMPLE_MODE_MIP_FILTER                                   10:9
#define AQ_TEXTURE_SAMPLE_MODE_MIP_FILTER_End                                 10
#define AQ_TEXTURE_SAMPLE_MODE_MIP_FILTER_Start                                9
#define AQ_TEXTURE_SAMPLE_MODE_MIP_FILTER_Type                               U02
#define   AQ_TEXTURE_SAMPLE_MODE_MIP_FILTER_NONE                             0x0
#define   AQ_TEXTURE_SAMPLE_MODE_MIP_FILTER_POINT                            0x1
#define   AQ_TEXTURE_SAMPLE_MODE_MIP_FILTER_LINEAR                           0x2
#define   AQ_TEXTURE_SAMPLE_MODE_MIP_FILTER_ANISOTROPIC                      0x3


#define AQ_TEXTURE_SAMPLE_MODE_MAG_FILTER                                  12:11
#define AQ_TEXTURE_SAMPLE_MODE_MAG_FILTER_End                                 12
#define AQ_TEXTURE_SAMPLE_MODE_MAG_FILTER_Start                               11
#define AQ_TEXTURE_SAMPLE_MODE_MAG_FILTER_Type                               U02
#define   AQ_TEXTURE_SAMPLE_MODE_MAG_FILTER_NONE                             0x0
#define   AQ_TEXTURE_SAMPLE_MODE_MAG_FILTER_POINT                            0x1
#define   AQ_TEXTURE_SAMPLE_MODE_MAG_FILTER_LINEAR                           0x2
#define   AQ_TEXTURE_SAMPLE_MODE_MAG_FILTER_ANISOTROPIC                      0x3


#define AQ_TEXTURE_SAMPLE_MODE_FORMAT                                      17:13
#define AQ_TEXTURE_SAMPLE_MODE_FORMAT_End                                     17
#define AQ_TEXTURE_SAMPLE_MODE_FORMAT_Start                                   13
#define AQ_TEXTURE_SAMPLE_MODE_FORMAT_Type                                   U05
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_A8                                  0x01
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_L8                                  0x02
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_I8                                  0x03
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_A8L8                                0x04
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_ARGB4                               0x05
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_XRGB4                               0x06
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_ARGB8                               0x07
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_XRGB8                               0x08
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_ABGR8                               0x09
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_XBGR8                               0x0A
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_R5G6B5                              0x0B
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_A1RGB5                              0x0C
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_X1RGB5                              0x0D
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_YUY2                                0x0E
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_UYVY                                0x0F
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_D16                                 0x10
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_D24X8                               0x11
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_A8_OES                              0x12
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_DXT1                                0x13
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_DXT2                                0x14
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_DXT3                                0x14
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_DXT4                                0x15
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_DXT5                                0x15
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_HDR7E3                              0x16
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_HDR6E4                              0x17
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_HDR5E5                              0x18
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_HDR6E5                              0x19
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_RGBE8                               0x1A
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_RGBE8F                              0x1B
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_RGB9E5                              0x1C
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_RGB9E5F                             0x1D
#define   AQ_TEXTURE_SAMPLE_MODE_FORMAT_ETC1                                0x1E


#define AQ_TEXTURE_SAMPLE_MODE_FILTER_CONSTANT                             18:18
#define AQ_TEXTURE_SAMPLE_MODE_FILTER_CONSTANT_End                            18
#define AQ_TEXTURE_SAMPLE_MODE_FILTER_CONSTANT_Start                          18
#define AQ_TEXTURE_SAMPLE_MODE_FILTER_CONSTANT_Type                          U01
#define   AQ_TEXTURE_SAMPLE_MODE_FILTER_CONSTANT_DISABLE                     0x0
#define   AQ_TEXTURE_SAMPLE_MODE_FILTER_CONSTANT_ENABLE                      0x1


#define AQ_TEXTURE_SAMPLE_MODE_ROUND_UV                                    19:19
#define AQ_TEXTURE_SAMPLE_MODE_ROUND_UV_End                                   19
#define AQ_TEXTURE_SAMPLE_MODE_ROUND_UV_Start                                 19
#define AQ_TEXTURE_SAMPLE_MODE_ROUND_UV_Type                                 U01
#define   AQ_TEXTURE_SAMPLE_MODE_ROUND_UV_DISABLE                            0x0
#define   AQ_TEXTURE_SAMPLE_MODE_ROUND_UV_ENABLE                             0x1


#define AQ_TEXTURE_SAMPLE_MODE_ADDRESSING                                  21:20
#define AQ_TEXTURE_SAMPLE_MODE_ADDRESSING_End                                 21
#define AQ_TEXTURE_SAMPLE_MODE_ADDRESSING_Start                               20
#define AQ_TEXTURE_SAMPLE_MODE_ADDRESSING_Type                               U02

#define   AQ_TEXTURE_SAMPLE_MODE_ADDRESSING_NO_STRIDE                        0x0

#define   AQ_TEXTURE_SAMPLE_MODE_ADDRESSING_NO_STRIDE_LINEAR                 0x1

#define   AQ_TEXTURE_SAMPLE_MODE_ADDRESSING_TILED                            0x2

#define   AQ_TEXTURE_SAMPLE_MODE_ADDRESSING_LINEAR                           0x3


#define AQ_TEXTURE_SAMPLE_MODE_ENDIAN_CONTROL                              23:22
#define AQ_TEXTURE_SAMPLE_MODE_ENDIAN_CONTROL_End                             23
#define AQ_TEXTURE_SAMPLE_MODE_ENDIAN_CONTROL_Start                           22
#define AQ_TEXTURE_SAMPLE_MODE_ENDIAN_CONTROL_Type                           U02
#define   AQ_TEXTURE_SAMPLE_MODE_ENDIAN_CONTROL_NO_SWAP                      0x0
#define   AQ_TEXTURE_SAMPLE_MODE_ENDIAN_CONTROL_SWAP_WORD                    0x1
#define   AQ_TEXTURE_SAMPLE_MODE_ENDIAN_CONTROL_SWAP_DWORD                   0x2
#define   AQ_TEXTURE_SAMPLE_MODE_ENDIAN_CONTROL_SWAP_DDWORD                  0x3


#define AQ_TEXTURE_SAMPLE_MODE_ANISO_MAX_LOG                               31:24
#define AQ_TEXTURE_SAMPLE_MODE_ANISO_MAX_LOG_End                              31
#define AQ_TEXTURE_SAMPLE_MODE_ANISO_MAX_LOG_Start                            24
#define AQ_TEXTURE_SAMPLE_MODE_ANISO_MAX_LOG_Type                            U08

#define AQTextureSampleWHRegAddrs                                         0x0810
#define AQ_TEXTURE_SAMPLE_WH_Address                                     0x02040
#define AQ_TEXTURE_SAMPLE_WH_MSB                                              15
#define AQ_TEXTURE_SAMPLE_WH_LSB                                               4
#define AQ_TEXTURE_SAMPLE_WH_BLK                                               4
#define AQ_TEXTURE_SAMPLE_WH_Count                                            16
#define AQ_TEXTURE_SAMPLE_WH_FieldMask                                0x7FFF7FFF
#define AQ_TEXTURE_SAMPLE_WH_ReadMask                                 0x7FFF7FFF
#define AQ_TEXTURE_SAMPLE_WH_WriteMask                                0x7FFF7FFF
#define AQ_TEXTURE_SAMPLE_WH_ResetValue                               0x00000000


#define AQ_TEXTURE_SAMPLE_WH_INT_WIDTH                                      14:0
#define AQ_TEXTURE_SAMPLE_WH_INT_WIDTH_End                                    14
#define AQ_TEXTURE_SAMPLE_WH_INT_WIDTH_Start                                   0
#define AQ_TEXTURE_SAMPLE_WH_INT_WIDTH_Type                                  U15


#define AQ_TEXTURE_SAMPLE_WH_INT_HEIGHT                                    30:16
#define AQ_TEXTURE_SAMPLE_WH_INT_HEIGHT_End                                   30
#define AQ_TEXTURE_SAMPLE_WH_INT_HEIGHT_Start                                 16
#define AQ_TEXTURE_SAMPLE_WH_INT_HEIGHT_Type                                 U15

#define AQTextureSampleLogWHRegAddrs                                      0x0820
#define AQ_TEXTURE_SAMPLE_LOG_WH_Address                                 0x02080
#define AQ_TEXTURE_SAMPLE_LOG_WH_MSB                                          15
#define AQ_TEXTURE_SAMPLE_LOG_WH_LSB                                           4
#define AQ_TEXTURE_SAMPLE_LOG_WH_BLK                                           4
#define AQ_TEXTURE_SAMPLE_LOG_WH_Count                                        12
#define AQ_TEXTURE_SAMPLE_LOG_WH_FieldMask                            0xF80FFFFF
#define AQ_TEXTURE_SAMPLE_LOG_WH_ReadMask                             0xF80FFFFF
#define AQ_TEXTURE_SAMPLE_LOG_WH_WriteMask                            0xF80FFFFF
#define AQ_TEXTURE_SAMPLE_LOG_WH_ResetValue                           0x00000000


#define AQ_TEXTURE_SAMPLE_LOG_WH_LOG_WIDTH                                   9:0
#define AQ_TEXTURE_SAMPLE_LOG_WH_LOG_WIDTH_End                                 9
#define AQ_TEXTURE_SAMPLE_LOG_WH_LOG_WIDTH_Start                               0
#define AQ_TEXTURE_SAMPLE_LOG_WH_LOG_WIDTH_Type                              U10


#define AQ_TEXTURE_SAMPLE_LOG_WH_LOG_HEIGHT                                19:10
#define AQ_TEXTURE_SAMPLE_LOG_WH_LOG_HEIGHT_End                               19
#define AQ_TEXTURE_SAMPLE_LOG_WH_LOG_HEIGHT_Start                             10
#define AQ_TEXTURE_SAMPLE_LOG_WH_LOG_HEIGHT_Type                             U10


#define AQ_TEXTURE_SAMPLE_LOG_WH_TX2_SH_NORMALIZE                          28:27
#define AQ_TEXTURE_SAMPLE_LOG_WH_TX2_SH_NORMALIZE_End                         28
#define AQ_TEXTURE_SAMPLE_LOG_WH_TX2_SH_NORMALIZE_Start                       27
#define AQ_TEXTURE_SAMPLE_LOG_WH_TX2_SH_NORMALIZE_Type                       U02

#define   AQ_TEXTURE_SAMPLE_LOG_WH_TX2_SH_NORMALIZE_AUTO                     0x0

#define   AQ_TEXTURE_SAMPLE_LOG_WH_TX2_SH_NORMALIZE_ENABLED                  0x1

#define   AQ_TEXTURE_SAMPLE_LOG_WH_TX2_SH_NORMALIZE_DISABLED                 0x2


#define AQ_TEXTURE_SAMPLE_LOG_WH_INTEGER_FILTER_CONTROL                    29:29
#define AQ_TEXTURE_SAMPLE_LOG_WH_INTEGER_FILTER_CONTROL_End                   29
#define AQ_TEXTURE_SAMPLE_LOG_WH_INTEGER_FILTER_CONTROL_Start                 29
#define AQ_TEXTURE_SAMPLE_LOG_WH_INTEGER_FILTER_CONTROL_Type                 U01

#define   AQ_TEXTURE_SAMPLE_LOG_WH_INTEGER_FILTER_CONTROL_NATIVE             0x0

#define   AQ_TEXTURE_SAMPLE_LOG_WH_INTEGER_FILTER_CONTROL_INTEGER            0x1


#define AQ_TEXTURE_SAMPLE_LOG_WH_NON_POWER_OF_TWO_CONTROL                  30:30
#define AQ_TEXTURE_SAMPLE_LOG_WH_NON_POWER_OF_TWO_CONTROL_End                 30
#define AQ_TEXTURE_SAMPLE_LOG_WH_NON_POWER_OF_TWO_CONTROL_Start               30
#define AQ_TEXTURE_SAMPLE_LOG_WH_NON_POWER_OF_TWO_CONTROL_Type               U01

#define   AQ_TEXTURE_SAMPLE_LOG_WH_NON_POWER_OF_TWO_CONTROL_NON_POWER_OF_TWO 0x0

#define   AQ_TEXTURE_SAMPLE_LOG_WH_NON_POWER_OF_TWO_CONTROL_POWER_OF_TWO     0x1


#define AQ_TEXTURE_SAMPLE_LOG_WH_SRGB                                      31:31
#define AQ_TEXTURE_SAMPLE_LOG_WH_SRGB_End                                     31
#define AQ_TEXTURE_SAMPLE_LOG_WH_SRGB_Start                                   31
#define AQ_TEXTURE_SAMPLE_LOG_WH_SRGB_Type                                   U01
#define   AQ_TEXTURE_SAMPLE_LOG_WH_SRGB_DISABLE                              0x0
#define   AQ_TEXTURE_SAMPLE_LOG_WH_SRGB_ENABLE                               0x1

#define AQTextureSampleLodRegAddrs                                        0x0830
#define AQ_TEXTURE_SAMPLE_LOD_Address                                    0x020C0
#define AQ_TEXTURE_SAMPLE_LOD_MSB                                             15
#define AQ_TEXTURE_SAMPLE_LOD_LSB                                              4
#define AQ_TEXTURE_SAMPLE_LOD_BLK                                              4
#define AQ_TEXTURE_SAMPLE_LOD_Count                                           12
#define AQ_TEXTURE_SAMPLE_LOD_FieldMask                               0x7FFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD_ReadMask                                0x7FFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD_WriteMask                               0x7FFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD_ResetValue                              0x00000000


#define AQ_TEXTURE_SAMPLE_LOD_EN_LOD_BIAS                                    0:0
#define AQ_TEXTURE_SAMPLE_LOD_EN_LOD_BIAS_End                                  0
#define AQ_TEXTURE_SAMPLE_LOD_EN_LOD_BIAS_Start                                0
#define AQ_TEXTURE_SAMPLE_LOD_EN_LOD_BIAS_Type                               U01
#define   AQ_TEXTURE_SAMPLE_LOD_EN_LOD_BIAS_DISABLE                          0x0
#define   AQ_TEXTURE_SAMPLE_LOD_EN_LOD_BIAS_ENABLE                           0x1


#define AQ_TEXTURE_SAMPLE_LOD_MAX_LOD_FIX5DOT5                              10:1
#define AQ_TEXTURE_SAMPLE_LOD_MAX_LOD_FIX5DOT5_End                            10
#define AQ_TEXTURE_SAMPLE_LOD_MAX_LOD_FIX5DOT5_Start                           1
#define AQ_TEXTURE_SAMPLE_LOD_MAX_LOD_FIX5DOT5_Type                          U10


#define AQ_TEXTURE_SAMPLE_LOD_MIN_LOD_FIX5DOT5                             20:11
#define AQ_TEXTURE_SAMPLE_LOD_MIN_LOD_FIX5DOT5_End                            20
#define AQ_TEXTURE_SAMPLE_LOD_MIN_LOD_FIX5DOT5_Start                          11
#define AQ_TEXTURE_SAMPLE_LOD_MIN_LOD_FIX5DOT5_Type                          U10


#define AQ_TEXTURE_SAMPLE_LOD_BIAS_LOD_FIX5DOT5                            30:21
#define AQ_TEXTURE_SAMPLE_LOD_BIAS_LOD_FIX5DOT5_End                           30
#define AQ_TEXTURE_SAMPLE_LOD_BIAS_LOD_FIX5DOT5_Start                         21
#define AQ_TEXTURE_SAMPLE_LOD_BIAS_LOD_FIX5DOT5_Type                         U10

#define AQTextureSampleBorderColorRegAddrs                                0x0840
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_Address                           0x02100
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_MSB                                    15
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_LSB                                     4
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_BLK                                     4
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_Count                                  12
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_FieldMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_ReadMask                       0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_WriteMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_ResetValue                     0x00000000

#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_ALPHA                               31:24
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_ALPHA_End                              31
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_ALPHA_Start                            24
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_ALPHA_Type                            U08

#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_RED                                 23:16
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_RED_End                                23
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_RED_Start                              16
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_RED_Type                              U08

#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_GREEN                                15:8
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_GREEN_End                              15
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_GREEN_Start                             8
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_GREEN_Type                            U08

#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_BLUE                                  7:0
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_BLUE_End                                7
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_BLUE_Start                              0
#define AQ_TEXTURE_SAMPLE_BORDER_COLOR_BLUE_Type                             U08




#define mwv207regTXStrideRegAddrs                                         0x0850
#define MWV207REG_TX_STRIDE_Address                                      0x02140
#define MWV207REG_TX_STRIDE_MSB                                               15
#define MWV207REG_TX_STRIDE_LSB                                                4
#define MWV207REG_TX_STRIDE_BLK                                                4
#define MWV207REG_TX_STRIDE_Count                                             16
#define MWV207REG_TX_STRIDE_FieldMask                                 0x0001FFFF
#define MWV207REG_TX_STRIDE_ReadMask                                  0x0001FFFF
#define MWV207REG_TX_STRIDE_WriteMask                                 0x0001FFFF
#define MWV207REG_TX_STRIDE_ResetValue                                0x00000000


#define MWV207REG_TX_STRIDE_STRIDE                                          16:0
#define MWV207REG_TX_STRIDE_STRIDE_End                                        16
#define MWV207REG_TX_STRIDE_STRIDE_Start                                       0
#define MWV207REG_TX_STRIDE_STRIDE_Type                                      U17




#define mwv207regTXVolumeRegAddrs                                         0x0860
#define MWV207REG_TX_VOLUME_Address                                      0x02180
#define MWV207REG_TX_VOLUME_MSB                                               15
#define MWV207REG_TX_VOLUME_LSB                                                4
#define MWV207REG_TX_VOLUME_BLK                                                4
#define MWV207REG_TX_VOLUME_Count                                             16
#define MWV207REG_TX_VOLUME_FieldMask                                 0x33FF3FFF
#define MWV207REG_TX_VOLUME_ReadMask                                  0x33FF3FFF
#define MWV207REG_TX_VOLUME_WriteMask                                 0x33FF3FFF
#define MWV207REG_TX_VOLUME_ResetValue                                0x00000000


#define MWV207REG_TX_VOLUME_DEPTH                                           13:0
#define MWV207REG_TX_VOLUME_DEPTH_End                                         13
#define MWV207REG_TX_VOLUME_DEPTH_Start                                        0
#define MWV207REG_TX_VOLUME_DEPTH_Type                                       U14


#define MWV207REG_TX_VOLUME_LOG_DEPTH                                      25:16
#define MWV207REG_TX_VOLUME_LOG_DEPTH_End                                     25
#define MWV207REG_TX_VOLUME_LOG_DEPTH_Start                                   16
#define MWV207REG_TX_VOLUME_LOG_DEPTH_Type                                   U10


#define MWV207REG_TX_VOLUME_MODE                                           29:28
#define MWV207REG_TX_VOLUME_MODE_End                                          29
#define MWV207REG_TX_VOLUME_MODE_Start                                        28
#define MWV207REG_TX_VOLUME_MODE_Type                                        U02
#define   MWV207REG_TX_VOLUME_MODE_WRAP                                      0x0
#define   MWV207REG_TX_VOLUME_MODE_MIRROR                                    0x1
#define   MWV207REG_TX_VOLUME_MODE_CLAMP                                     0x2
#define   MWV207REG_TX_VOLUME_MODE_BORDER                                    0x3




#define mwv207regTXModeRegAddrs                                           0x0870
#define MWV207REG_TX_MODE_Address                                        0x021C0
#define MWV207REG_TX_MODE_MSB                                                 15
#define MWV207REG_TX_MODE_LSB                                                  4
#define MWV207REG_TX_MODE_BLK                                                  4
#define MWV207REG_TX_MODE_Count                                               16
#define MWV207REG_TX_MODE_FieldMask                                   0xFFFFFFFF
#define MWV207REG_TX_MODE_ReadMask                                    0xFFFFFFFF
#define MWV207REG_TX_MODE_WriteMask                                   0xFFFFFFFF
#define MWV207REG_TX_MODE_ResetValue                                  0x00321000

#define MWV207REG_TX_MODE_FORMAT                                             5:0
#define MWV207REG_TX_MODE_FORMAT_End                                           5
#define MWV207REG_TX_MODE_FORMAT_Start                                         0
#define MWV207REG_TX_MODE_FORMAT_Type                                        U06
#define   MWV207REG_TX_MODE_FORMAT_ETC2_RGB8                                0x00
#define   MWV207REG_TX_MODE_FORMAT_ETC2_RGB8A1                              0x01
#define   MWV207REG_TX_MODE_FORMAT_ETC2_RGB8A8                              0x02
#define   MWV207REG_TX_MODE_FORMAT_EAC__R11_UNSIGNED                        0x03
#define   MWV207REG_TX_MODE_FORMAT_EAC__RG11_UNSIGNED                       0x04
#define   MWV207REG_TX_MODE_FORMAT_EAC__RG11_SIGNED                         0x05
#define   MWV207REG_TX_MODE_FORMAT_R8G8                                     0x06
#define   MWV207REG_TX_MODE_FORMAT_RF16                                     0x07
#define   MWV207REG_TX_MODE_FORMAT_RF16GF16                                 0x08
#define   MWV207REG_TX_MODE_FORMAT_RF16GF16BGF16AF16                        0x09
#define   MWV207REG_TX_MODE_FORMAT_RF32                                     0x0A
#define   MWV207REG_TX_MODE_FORMAT_RF32GF32                                 0x0B
#define   MWV207REG_TX_MODE_FORMAT_R10G10B10A2                              0x0C
#define   MWV207REG_TX_MODE_FORMAT_EAC__R11_SIGNED                          0x0D
#define   MWV207REG_TX_MODE_FORMAT_R8__SNORM                                0x0E
#define   MWV207REG_TX_MODE_FORMAT_RG8__SNORM                               0x0F
#define   MWV207REG_TX_MODE_FORMAT_RGBX8__SNORM                             0x10
#define   MWV207REG_TX_MODE_FORMAT_RGBA8__SNORM                             0x11
#define   MWV207REG_TX_MODE_FORMAT_RGB8                                     0x12
#define   MWV207REG_TX_MODE_FORMAT_YUV_ASSEMBLY                             0x13
#define   MWV207REG_TX_MODE_FORMAT_ASTC                                     0x14
#define   MWV207REG_TX_MODE_FORMAT_RI8                                      0x15
#define   MWV207REG_TX_MODE_FORMAT_RI8GI8                                   0x16
#define   MWV207REG_TX_MODE_FORMAT_RI8GI8BI8AI8                             0x17
#define   MWV207REG_TX_MODE_FORMAT_RI16                                     0x18
#define   MWV207REG_TX_MODE_FORMAT_RI16GI16                                 0x19
#define   MWV207REG_TX_MODE_FORMAT_RI16GI16BI16AI16                         0x1A
#define   MWV207REG_TX_MODE_FORMAT_RI32                                     0x0A
#define   MWV207REG_TX_MODE_FORMAT_RI32GI32                                 0x0B
#define   MWV207REG_TX_MODE_FORMAT_RF11GF11BF10                             0x1B
#define   MWV207REG_TX_MODE_FORMAT_RI10GI10BI10AI2                          0x1C
#define   MWV207REG_TX_MODE_FORMAT_R8G8B8G8                                 0x1D
#define   MWV207REG_TX_MODE_FORMAT_G8R8G8B8                                 0x1E
#define   MWV207REG_TX_MODE_FORMAT_RI8GI8BI8GI8                             0x1F
#define   MWV207REG_TX_MODE_FORMAT_GI8RI8GI8BI8                             0x20
#define   MWV207REG_TX_MODE_FORMAT_R8                                       0x21
#define   MWV207REG_TX_MODE_FORMAT_D24S8                                    0x22
#define   MWV207REG_TX_MODE_FORMAT_RI32_NEW                                 0x23
#define   MWV207REG_TX_MODE_FORMAT_RI32GI32_NEW                             0x24
#define   MWV207REG_TX_MODE_FORMAT_AYUV                                     0x25
#define   MWV207REG_TX_MODE_FORMAT_RF32GF32BF32AF32                         0x26
#define   MWV207REG_TX_MODE_FORMAT_RI32GI32BI32AI32                         0x27
#define   MWV207REG_TX_MODE_FORMAT_RUI32GUI32BUI32AUI32                     0x27
#define   MWV207REG_TX_MODE_FORMAT_RSI32GSI32BSI32ASI32                     0x28
#define   MWV207REG_TX_MODE_FORMAT_D32F                                     0x29
#define   MWV207REG_TX_MODE_FORMAT_D32FS8                                   0x2A
#define   MWV207REG_TX_MODE_FORMAT_BC4_UNORM                                0x2B
#define   MWV207REG_TX_MODE_FORMAT_BC4_SNORM                                0x2C
#define   MWV207REG_TX_MODE_FORMAT_BC5_UNORM                                0x2D
#define   MWV207REG_TX_MODE_FORMAT_BC5_SNORM                                0x2E
#define   MWV207REG_TX_MODE_FORMAT_BC6_UF16                                 0x2F
#define   MWV207REG_TX_MODE_FORMAT_BC6_SF16                                 0x30
#define   MWV207REG_TX_MODE_FORMAT_BC7_UNORM                                0x31
#define   MWV207REG_TX_MODE_FORMAT_RGBA16_UNORM                             0x32
#define   MWV207REG_TX_MODE_FORMAT_RGBA16_SNORM                             0x33
#define   MWV207REG_TX_MODE_FORMAT_RG16_UNORM                               0x34
#define   MWV207REG_TX_MODE_FORMAT_RG16_SNORM                               0x35
#define   MWV207REG_TX_MODE_FORMAT_R16_SNORM                                0x36


#define MWV207REG_TX_MODE_FULL_RANGE_ENCODING                                6:6
#define MWV207REG_TX_MODE_FULL_RANGE_ENCODING_End                              6
#define MWV207REG_TX_MODE_FULL_RANGE_ENCODING_Start                            6
#define MWV207REG_TX_MODE_FULL_RANGE_ENCODING_Type                           U01

#define   MWV207REG_TX_MODE_FULL_RANGE_ENCODING_NARROW_RANGE                 0x0

#define   MWV207REG_TX_MODE_FULL_RANGE_ENCODING_FULL_RANGE                   0x1


#define MWV207REG_TX_MODE_COLOR_SWIZZLE                                      7:7
#define MWV207REG_TX_MODE_COLOR_SWIZZLE_End                                    7
#define MWV207REG_TX_MODE_COLOR_SWIZZLE_Start                                  7
#define MWV207REG_TX_MODE_COLOR_SWIZZLE_Type                                 U01
#define   MWV207REG_TX_MODE_COLOR_SWIZZLE_DISABLE                            0x0
#define   MWV207REG_TX_MODE_COLOR_SWIZZLE_ENABLE                             0x1


#define MWV207REG_TX_MODE_SWIZZLE_RED                                       10:8
#define MWV207REG_TX_MODE_SWIZZLE_RED_End                                     10
#define MWV207REG_TX_MODE_SWIZZLE_RED_Start                                    8
#define MWV207REG_TX_MODE_SWIZZLE_RED_Type                                   U03
#define   MWV207REG_TX_MODE_SWIZZLE_RED_RED                                  0x0
#define   MWV207REG_TX_MODE_SWIZZLE_RED_GREEN                                0x1
#define   MWV207REG_TX_MODE_SWIZZLE_RED_BLUE                                 0x2
#define   MWV207REG_TX_MODE_SWIZZLE_RED_ALPHA                                0x3
#define   MWV207REG_TX_MODE_SWIZZLE_RED_ZERO                                 0x4
#define   MWV207REG_TX_MODE_SWIZZLE_RED_ONE                                  0x5


#define MWV207REG_TX_MODE_SWAP_Y                                           11:11
#define MWV207REG_TX_MODE_SWAP_Y_End                                          11
#define MWV207REG_TX_MODE_SWAP_Y_Start                                        11
#define MWV207REG_TX_MODE_SWAP_Y_Type                                        U01


#define MWV207REG_TX_MODE_SWIZZLE_GREEN                                    14:12
#define MWV207REG_TX_MODE_SWIZZLE_GREEN_End                                   14
#define MWV207REG_TX_MODE_SWIZZLE_GREEN_Start                                 12
#define MWV207REG_TX_MODE_SWIZZLE_GREEN_Type                                 U03
#define   MWV207REG_TX_MODE_SWIZZLE_GREEN_RED                                0x0
#define   MWV207REG_TX_MODE_SWIZZLE_GREEN_GREEN                              0x1
#define   MWV207REG_TX_MODE_SWIZZLE_GREEN_BLUE                               0x2
#define   MWV207REG_TX_MODE_SWIZZLE_GREEN_ALPHA                              0x3
#define   MWV207REG_TX_MODE_SWIZZLE_GREEN_ZERO                               0x4
#define   MWV207REG_TX_MODE_SWIZZLE_GREEN_ONE                                0x5


#define MWV207REG_TX_MODE_SWAP_UV                                          15:15
#define MWV207REG_TX_MODE_SWAP_UV_End                                         15
#define MWV207REG_TX_MODE_SWAP_UV_Start                                       15
#define MWV207REG_TX_MODE_SWAP_UV_Type                                       U01


#define MWV207REG_TX_MODE_SWIZZLE_BLUE                                     18:16
#define MWV207REG_TX_MODE_SWIZZLE_BLUE_End                                    18
#define MWV207REG_TX_MODE_SWIZZLE_BLUE_Start                                  16
#define MWV207REG_TX_MODE_SWIZZLE_BLUE_Type                                  U03
#define   MWV207REG_TX_MODE_SWIZZLE_BLUE_RED                                 0x0
#define   MWV207REG_TX_MODE_SWIZZLE_BLUE_GREEN                               0x1
#define   MWV207REG_TX_MODE_SWIZZLE_BLUE_BLUE                                0x2
#define   MWV207REG_TX_MODE_SWIZZLE_BLUE_ALPHA                               0x3
#define   MWV207REG_TX_MODE_SWIZZLE_BLUE_ZERO                                0x4
#define   MWV207REG_TX_MODE_SWIZZLE_BLUE_ONE                                 0x5

#define MWV207REG_TX_MODE_FLIP_Y                                           19:19
#define MWV207REG_TX_MODE_FLIP_Y_End                                          19
#define MWV207REG_TX_MODE_FLIP_Y_Start                                        19
#define MWV207REG_TX_MODE_FLIP_Y_Type                                        U01
#define   MWV207REG_TX_MODE_FLIP_Y_NORMAL                                    0x0
#define   MWV207REG_TX_MODE_FLIP_Y_UPSIDE_DOWN                               0x1


#define MWV207REG_TX_MODE_SWIZZLE_ALPHA                                    22:20
#define MWV207REG_TX_MODE_SWIZZLE_ALPHA_End                                   22
#define MWV207REG_TX_MODE_SWIZZLE_ALPHA_Start                                 20
#define MWV207REG_TX_MODE_SWIZZLE_ALPHA_Type                                 U03
#define   MWV207REG_TX_MODE_SWIZZLE_ALPHA_RED                                0x0
#define   MWV207REG_TX_MODE_SWIZZLE_ALPHA_GREEN                              0x1
#define   MWV207REG_TX_MODE_SWIZZLE_ALPHA_BLUE                               0x2
#define   MWV207REG_TX_MODE_SWIZZLE_ALPHA_ALPHA                              0x3
#define   MWV207REG_TX_MODE_SWIZZLE_ALPHA_ZERO                               0x4
#define   MWV207REG_TX_MODE_SWIZZLE_ALPHA_ONE                                0x5


#define MWV207REG_TX_MODE_TX256_BYTE_REQUEST                               23:23
#define MWV207REG_TX_MODE_TX256_BYTE_REQUEST_End                              23
#define MWV207REG_TX_MODE_TX256_BYTE_REQUEST_Start                            23
#define MWV207REG_TX_MODE_TX256_BYTE_REQUEST_Type                            U01
#define   MWV207REG_TX_MODE_TX256_BYTE_REQUEST_DISABLE                       0x0
#define   MWV207REG_TX_MODE_TX256_BYTE_REQUEST_ENABLE                        0x1


#define MWV207REG_TX_MODE_TEXTURE_ARRAY                                    24:24
#define MWV207REG_TX_MODE_TEXTURE_ARRAY_End                                   24
#define MWV207REG_TX_MODE_TEXTURE_ARRAY_Start                                 24
#define MWV207REG_TX_MODE_TEXTURE_ARRAY_Type                                 U01
#define   MWV207REG_TX_MODE_TEXTURE_ARRAY_DISABLE                            0x0
#define   MWV207REG_TX_MODE_TEXTURE_ARRAY_ENABLE                             0x1


#define MWV207REG_TX_MODE_EN_SEAMLESS_CUBE_MAP                             25:25
#define MWV207REG_TX_MODE_EN_SEAMLESS_CUBE_MAP_End                            25
#define MWV207REG_TX_MODE_EN_SEAMLESS_CUBE_MAP_Start                          25
#define MWV207REG_TX_MODE_EN_SEAMLESS_CUBE_MAP_Type                          U01
#define   MWV207REG_TX_MODE_EN_SEAMLESS_CUBE_MAP_DISABLE                     0x0
#define   MWV207REG_TX_MODE_EN_SEAMLESS_CUBE_MAP_ENABLE                      0x1


#define MWV207REG_TX_MODE_HORIZONAL_ALIGN                                  28:26
#define MWV207REG_TX_MODE_HORIZONAL_ALIGN_End                                 28
#define MWV207REG_TX_MODE_HORIZONAL_ALIGN_Start                               26
#define MWV207REG_TX_MODE_HORIZONAL_ALIGN_Type                               U03

#define   MWV207REG_TX_MODE_HORIZONAL_ALIGN_FOUR                             0x0

#define   MWV207REG_TX_MODE_HORIZONAL_ALIGN_SIXTEEN                          0x1

#define   MWV207REG_TX_MODE_HORIZONAL_ALIGN_SUPER_TILED                      0x2

#define   MWV207REG_TX_MODE_HORIZONAL_ALIGN_SPLIT_TILED                      0x3

#define   MWV207REG_TX_MODE_HORIZONAL_ALIGN_SPLIT_SUPER_TILED                0x4

#define   MWV207REG_TX_MODE_HORIZONAL_ALIGN_SPLIT_TILED_BIG                  0x5

#define   MWV207REG_TX_MODE_HORIZONAL_ALIGN_SPLIT_SUPER_TILED_BUG            0x6

#define   MWV207REG_TX_MODE_HORIZONAL_ALIGN_SUPER_TILED_YMAJOR               0x7


#define MWV207REG_TX_MODE_YUV_STANDARD                                     29:29
#define MWV207REG_TX_MODE_YUV_STANDARD_End                                    29
#define MWV207REG_TX_MODE_YUV_STANDARD_Start                                  29
#define MWV207REG_TX_MODE_YUV_STANDARD_Type                                  U01

#define   MWV207REG_TX_MODE_YUV_STANDARD_YUV601                              0x0

#define   MWV207REG_TX_MODE_YUV_STANDARD_YUV709                              0x1

#define MWV207REG_TX_MODE_TILE_STATUS                                      30:30
#define MWV207REG_TX_MODE_TILE_STATUS_End                                     30
#define MWV207REG_TX_MODE_TILE_STATUS_Start                                   30
#define MWV207REG_TX_MODE_TILE_STATUS_Type                                   U01

#define   MWV207REG_TX_MODE_TILE_STATUS_NO                                   0x0

#define   MWV207REG_TX_MODE_TILE_STATUS_YES                                  0x1


#define MWV207REG_TX_MODE_IMAGE_FILTER                                     31:31
#define MWV207REG_TX_MODE_IMAGE_FILTER_End                                    31
#define MWV207REG_TX_MODE_IMAGE_FILTER_Start                                  31
#define MWV207REG_TX_MODE_IMAGE_FILTER_Type                                  U01

#define   MWV207REG_TX_MODE_IMAGE_FILTER_NORMAL                              0x0

#define   MWV207REG_TX_MODE_IMAGE_FILTER_FILTER_KERNEL                       0x1




#define mwv207regTXControlYUVRegAddrs                                     0x0880
#define MWV207REG_TX_CONTROL_YUV_Address                                 0x02200
#define MWV207REG_TX_CONTROL_YUV_MSB                                          15
#define MWV207REG_TX_CONTROL_YUV_LSB                                           4
#define MWV207REG_TX_CONTROL_YUV_BLK                                           4
#define MWV207REG_TX_CONTROL_YUV_Count                                        16
#define MWV207REG_TX_CONTROL_YUV_FieldMask                            0xFFFF7F73
#define MWV207REG_TX_CONTROL_YUV_ReadMask                             0xFFFF7F73
#define MWV207REG_TX_CONTROL_YUV_WriteMask                            0xFFFF7F73
#define MWV207REG_TX_CONTROL_YUV_ResetValue                           0x00000000


#define MWV207REG_TX_CONTROL_YUV_FORMAT_X                                    1:0
#define MWV207REG_TX_CONTROL_YUV_FORMAT_X_End                                  1
#define MWV207REG_TX_CONTROL_YUV_FORMAT_X_Start                                0
#define MWV207REG_TX_CONTROL_YUV_FORMAT_X_Type                               U02

#define   MWV207REG_TX_CONTROL_YUV_FORMAT_X_NONE                             0x0

#define   MWV207REG_TX_CONTROL_YUV_FORMAT_X_ONE                              0x1

#define   MWV207REG_TX_CONTROL_YUV_FORMAT_X_TWO                              0x2

#define   MWV207REG_TX_CONTROL_YUV_FORMAT_X_FOUR                             0x3


#define MWV207REG_TX_CONTROL_YUV_FORMAT_Y                                    5:4
#define MWV207REG_TX_CONTROL_YUV_FORMAT_Y_End                                  5
#define MWV207REG_TX_CONTROL_YUV_FORMAT_Y_Start                                4
#define MWV207REG_TX_CONTROL_YUV_FORMAT_Y_Type                               U02

#define   MWV207REG_TX_CONTROL_YUV_FORMAT_Y_NONE                             0x0

#define   MWV207REG_TX_CONTROL_YUV_FORMAT_Y_ONE                              0x1

#define   MWV207REG_TX_CONTROL_YUV_FORMAT_Y_TWO                              0x2

#define   MWV207REG_TX_CONTROL_YUV_FORMAT_Y_FOUR                             0x3


#define MWV207REG_TX_CONTROL_YUV_CHANNEL_BITS                                6:6
#define MWV207REG_TX_CONTROL_YUV_CHANNEL_BITS_End                              6
#define MWV207REG_TX_CONTROL_YUV_CHANNEL_BITS_Start                            6
#define MWV207REG_TX_CONTROL_YUV_CHANNEL_BITS_Type                           U01

#define   MWV207REG_TX_CONTROL_YUV_CHANNEL_BITS_BITS8                        0x0

#define   MWV207REG_TX_CONTROL_YUV_CHANNEL_BITS_BITS10                       0x1


#define MWV207REG_TX_CONTROL_YUV_YOFFSET                                    10:8
#define MWV207REG_TX_CONTROL_YUV_YOFFSET_End                                  10
#define MWV207REG_TX_CONTROL_YUV_YOFFSET_Start                                 8
#define MWV207REG_TX_CONTROL_YUV_YOFFSET_Type                                U03


#define MWV207REG_TX_CONTROL_YUV_TILE_EX                                   11:11
#define MWV207REG_TX_CONTROL_YUV_TILE_EX_End                                  11
#define MWV207REG_TX_CONTROL_YUV_TILE_EX_Start                                11
#define MWV207REG_TX_CONTROL_YUV_TILE_EX_Type                                U01

#define   MWV207REG_TX_CONTROL_YUV_TILE_EX_NO_EXTERNED                       0x0

#define   MWV207REG_TX_CONTROL_YUV_TILE_EX_CUSTOMER0                         0x1


#define MWV207REG_TX_CONTROL_YUV_UOFFSET                                   14:12
#define MWV207REG_TX_CONTROL_YUV_UOFFSET_End                                  14
#define MWV207REG_TX_CONTROL_YUV_UOFFSET_Start                                12
#define MWV207REG_TX_CONTROL_YUV_UOFFSET_Type                                U03


#define MWV207REG_TX_CONTROL_YUV_VOFFSET                                   18:16
#define MWV207REG_TX_CONTROL_YUV_VOFFSET_End                                  18
#define MWV207REG_TX_CONTROL_YUV_VOFFSET_Start                                16
#define MWV207REG_TX_CONTROL_YUV_VOFFSET_Type                                U03


#define MWV207REG_TX_CONTROL_YUV_IS_P010                                   19:19
#define MWV207REG_TX_CONTROL_YUV_IS_P010_End                                  19
#define MWV207REG_TX_CONTROL_YUV_IS_P010_Start                                19
#define MWV207REG_TX_CONTROL_YUV_IS_P010_Type                                U01

#define MWV207REG_TX_CONTROL_YUV_INTERLEAVED                               20:20
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVED_End                              20
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVED_Start                            20
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVED_Type                            U01
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVED_PLANAR                        0x0
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVED_INTERLEAVED                   0x1


#define MWV207REG_TX_CONTROL_YUV_INTERLACED                                21:21
#define MWV207REG_TX_CONTROL_YUV_INTERLACED_End                               21
#define MWV207REG_TX_CONTROL_YUV_INTERLACED_Start                             21
#define MWV207REG_TX_CONTROL_YUV_INTERLACED_Type                             U01
#define   MWV207REG_TX_CONTROL_YUV_INTERLACED_PROGRESSIVE                    0x0

#define   MWV207REG_TX_CONTROL_YUV_INTERLACED_INTERLACED                     0x1


#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_Y                      23:22
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_Y_End                     23
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_Y_Start                   22
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_Y_Type                   U02
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_Y_PLANE_Y              0x0
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_Y_PLANE_U              0x1
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_Y_PLANE_V              0x2


#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_U                      25:24
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_U_End                     25
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_U_Start                   24
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_U_Type                   U02
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_U_PLANE_Y              0x0
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_U_PLANE_U              0x1
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_U_PLANE_V              0x2


#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_V                      27:26
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_V_End                     27
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_V_Start                   26
#define MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_V_Type                   U02
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_V_PLANE_Y              0x0
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_V_PLANE_U              0x1
#define   MWV207REG_TX_CONTROL_YUV_INTERLEAVE_SWIZZLE_V_PLANE_V              0x2


#define MWV207REG_TX_CONTROL_YUV_TILE_Y                                    29:28
#define MWV207REG_TX_CONTROL_YUV_TILE_Y_End                                   29
#define MWV207REG_TX_CONTROL_YUV_TILE_Y_Start                                 28
#define MWV207REG_TX_CONTROL_YUV_TILE_Y_Type                                 U02
#define   MWV207REG_TX_CONTROL_YUV_TILE_Y_LINEAR                             0x0
#define   MWV207REG_TX_CONTROL_YUV_TILE_Y_TILE4X4                            0x1
#define   MWV207REG_TX_CONTROL_YUV_TILE_Y_TILE8X8                            0x2
#define   MWV207REG_TX_CONTROL_YUV_TILE_Y_TILE16X16                          0x3


#define MWV207REG_TX_CONTROL_YUV_TILE_UV                                   31:30
#define MWV207REG_TX_CONTROL_YUV_TILE_UV_End                                  31
#define MWV207REG_TX_CONTROL_YUV_TILE_UV_Start                                30
#define MWV207REG_TX_CONTROL_YUV_TILE_UV_Type                                U02
#define   MWV207REG_TX_CONTROL_YUV_TILE_UV_LINEAR                            0x0
#define   MWV207REG_TX_CONTROL_YUV_TILE_UV_TILE4X4                           0x1
#define   MWV207REG_TX_CONTROL_YUV_TILE_UV_TILE8X8                           0x2
#define   MWV207REG_TX_CONTROL_YUV_TILE_UV_TILE16X16                         0x3




#define mwv207regTXStrideYUVRegAddrs                                      0x0890
#define MWV207REG_TX_STRIDE_YUV_Address                                  0x02240
#define MWV207REG_TX_STRIDE_YUV_MSB                                           15
#define MWV207REG_TX_STRIDE_YUV_LSB                                            4
#define MWV207REG_TX_STRIDE_YUV_BLK                                            4
#define MWV207REG_TX_STRIDE_YUV_Count                                         16
#define MWV207REG_TX_STRIDE_YUV_FieldMask                             0xFFFFFFFF
#define MWV207REG_TX_STRIDE_YUV_ReadMask                              0xFFFFFFFF
#define MWV207REG_TX_STRIDE_YUV_WriteMask                             0xFFFFFFFF
#define MWV207REG_TX_STRIDE_YUV_ResetValue                            0x00000000


#define MWV207REG_TX_STRIDE_YUV_USTRIDE                                     15:0
#define MWV207REG_TX_STRIDE_YUV_USTRIDE_End                                   15
#define MWV207REG_TX_STRIDE_YUV_USTRIDE_Start                                  0
#define MWV207REG_TX_STRIDE_YUV_USTRIDE_Type                                 U16


#define MWV207REG_TX_STRIDE_YUV_VSTRIDE                                    31:16
#define MWV207REG_TX_STRIDE_YUV_VSTRIDE_End                                   31
#define MWV207REG_TX_STRIDE_YUV_VSTRIDE_Start                                 16
#define MWV207REG_TX_STRIDE_YUV_VSTRIDE_Type                                 U16




#define mwv207regTxASTC0RegAddrs                                          0x08A0
#define MWV207REG_TX_ASTC0_Address                                       0x02280
#define MWV207REG_TX_ASTC0_MSB                                                15
#define MWV207REG_TX_ASTC0_LSB                                                 4
#define MWV207REG_TX_ASTC0_BLK                                                 4
#define MWV207REG_TX_ASTC0_Count                                              16
#define MWV207REG_TX_ASTC0_FieldMask                                  0x1F1F1F1F
#define MWV207REG_TX_ASTC0_ReadMask                                   0x1F1F1F1F
#define MWV207REG_TX_ASTC0_WriteMask                                  0x1F1F1F1F
#define MWV207REG_TX_ASTC0_ResetValue                                 0x00000000


#define MWV207REG_TX_ASTC0_SIZE_LOD0                                         3:0
#define MWV207REG_TX_ASTC0_SIZE_LOD0_End                                       3
#define MWV207REG_TX_ASTC0_SIZE_LOD0_Start                                     0
#define MWV207REG_TX_ASTC0_SIZE_LOD0_Type                                    U04
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_4x4                                   0x0
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_5x4                                   0x1
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_5x5                                   0x2
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_6x5                                   0x3
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_6x6                                   0x4
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_8x5                                   0x5
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_8x6                                   0x6
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_8x8                                   0x7
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_10x5                                  0x8
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_10x6                                  0x9
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_10x8                                  0xA
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_10x10                                 0xB
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_12x10                                 0xC
#define   MWV207REG_TX_ASTC0_SIZE_LOD0_12x12                                 0xD


#define MWV207REG_TX_ASTC0_SRGB_LOD0                                         4:4
#define MWV207REG_TX_ASTC0_SRGB_LOD0_End                                       4
#define MWV207REG_TX_ASTC0_SRGB_LOD0_Start                                     4
#define MWV207REG_TX_ASTC0_SRGB_LOD0_Type                                    U01
#define   MWV207REG_TX_ASTC0_SRGB_LOD0_DISABLE                               0x0
#define   MWV207REG_TX_ASTC0_SRGB_LOD0_ENABLE                                0x1


#define MWV207REG_TX_ASTC0_SIZE_LOD1                                        11:8
#define MWV207REG_TX_ASTC0_SIZE_LOD1_End                                      11
#define MWV207REG_TX_ASTC0_SIZE_LOD1_Start                                     8
#define MWV207REG_TX_ASTC0_SIZE_LOD1_Type                                    U04
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_4x4                                   0x0
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_5x4                                   0x1
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_5x5                                   0x2
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_6x5                                   0x3
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_6x6                                   0x4
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_8x5                                   0x5
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_8x6                                   0x6
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_8x8                                   0x7
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_10x5                                  0x8
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_10x6                                  0x9
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_10x8                                  0xA
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_10x10                                 0xB
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_12x10                                 0xC
#define   MWV207REG_TX_ASTC0_SIZE_LOD1_12x12                                 0xD


#define MWV207REG_TX_ASTC0_SRGB_LOD1                                       12:12
#define MWV207REG_TX_ASTC0_SRGB_LOD1_End                                      12
#define MWV207REG_TX_ASTC0_SRGB_LOD1_Start                                    12
#define MWV207REG_TX_ASTC0_SRGB_LOD1_Type                                    U01
#define   MWV207REG_TX_ASTC0_SRGB_LOD1_DISABLE                               0x0
#define   MWV207REG_TX_ASTC0_SRGB_LOD1_ENABLE                                0x1


#define MWV207REG_TX_ASTC0_SIZE_LOD2                                       19:16
#define MWV207REG_TX_ASTC0_SIZE_LOD2_End                                      19
#define MWV207REG_TX_ASTC0_SIZE_LOD2_Start                                    16
#define MWV207REG_TX_ASTC0_SIZE_LOD2_Type                                    U04
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_4x4                                   0x0
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_5x4                                   0x1
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_5x5                                   0x2
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_6x5                                   0x3
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_6x6                                   0x4
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_8x5                                   0x5
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_8x6                                   0x6
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_8x8                                   0x7
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_10x5                                  0x8
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_10x6                                  0x9
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_10x8                                  0xA
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_10x10                                 0xB
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_12x10                                 0xC
#define   MWV207REG_TX_ASTC0_SIZE_LOD2_12x12                                 0xD


#define MWV207REG_TX_ASTC0_SRGB_LOD2                                       20:20
#define MWV207REG_TX_ASTC0_SRGB_LOD2_End                                      20
#define MWV207REG_TX_ASTC0_SRGB_LOD2_Start                                    20
#define MWV207REG_TX_ASTC0_SRGB_LOD2_Type                                    U01
#define   MWV207REG_TX_ASTC0_SRGB_LOD2_DISABLE                               0x0
#define   MWV207REG_TX_ASTC0_SRGB_LOD2_ENABLE                                0x1


#define MWV207REG_TX_ASTC0_SIZE_LOD3                                       27:24
#define MWV207REG_TX_ASTC0_SIZE_LOD3_End                                      27
#define MWV207REG_TX_ASTC0_SIZE_LOD3_Start                                    24
#define MWV207REG_TX_ASTC0_SIZE_LOD3_Type                                    U04
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_4x4                                   0x0
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_5x4                                   0x1
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_5x5                                   0x2
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_6x5                                   0x3
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_6x6                                   0x4
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_8x5                                   0x5
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_8x6                                   0x6
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_8x8                                   0x7
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_10x5                                  0x8
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_10x6                                  0x9
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_10x8                                  0xA
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_10x10                                 0xB
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_12x10                                 0xC
#define   MWV207REG_TX_ASTC0_SIZE_LOD3_12x12                                 0xD


#define MWV207REG_TX_ASTC0_SRGB_LOD3                                       28:28
#define MWV207REG_TX_ASTC0_SRGB_LOD3_End                                      28
#define MWV207REG_TX_ASTC0_SRGB_LOD3_Start                                    28
#define MWV207REG_TX_ASTC0_SRGB_LOD3_Type                                    U01
#define   MWV207REG_TX_ASTC0_SRGB_LOD3_DISABLE                               0x0
#define   MWV207REG_TX_ASTC0_SRGB_LOD3_ENABLE                                0x1




#define mwv207regTxASTC1RegAddrs                                          0x08B0
#define MWV207REG_TX_ASTC1_Address                                       0x022C0
#define MWV207REG_TX_ASTC1_MSB                                                15
#define MWV207REG_TX_ASTC1_LSB                                                 4
#define MWV207REG_TX_ASTC1_BLK                                                 4
#define MWV207REG_TX_ASTC1_Count                                              16
#define MWV207REG_TX_ASTC1_FieldMask                                  0x1F1F1F1F
#define MWV207REG_TX_ASTC1_ReadMask                                   0x1F1F1F1F
#define MWV207REG_TX_ASTC1_WriteMask                                  0x1F1F1F1F
#define MWV207REG_TX_ASTC1_ResetValue                                 0x00000000


#define MWV207REG_TX_ASTC1_SIZE_LOD4                                         3:0
#define MWV207REG_TX_ASTC1_SIZE_LOD4_End                                       3
#define MWV207REG_TX_ASTC1_SIZE_LOD4_Start                                     0
#define MWV207REG_TX_ASTC1_SIZE_LOD4_Type                                    U04
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_4x4                                   0x0
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_5x4                                   0x1
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_5x5                                   0x2
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_6x5                                   0x3
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_6x6                                   0x4
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_8x5                                   0x5
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_8x6                                   0x6
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_8x8                                   0x7
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_10x5                                  0x8
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_10x6                                  0x9
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_10x8                                  0xA
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_10x10                                 0xB
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_12x10                                 0xC
#define   MWV207REG_TX_ASTC1_SIZE_LOD4_12x12                                 0xD


#define MWV207REG_TX_ASTC1_SRGB_LOD4                                         4:4
#define MWV207REG_TX_ASTC1_SRGB_LOD4_End                                       4
#define MWV207REG_TX_ASTC1_SRGB_LOD4_Start                                     4
#define MWV207REG_TX_ASTC1_SRGB_LOD4_Type                                    U01
#define   MWV207REG_TX_ASTC1_SRGB_LOD4_DISABLE                               0x0
#define   MWV207REG_TX_ASTC1_SRGB_LOD4_ENABLE                                0x1


#define MWV207REG_TX_ASTC1_SIZE_LOD5                                        11:8
#define MWV207REG_TX_ASTC1_SIZE_LOD5_End                                      11
#define MWV207REG_TX_ASTC1_SIZE_LOD5_Start                                     8
#define MWV207REG_TX_ASTC1_SIZE_LOD5_Type                                    U04
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_4x4                                   0x0
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_5x4                                   0x1
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_5x5                                   0x2
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_6x5                                   0x3
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_6x6                                   0x4
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_8x5                                   0x5
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_8x6                                   0x6
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_8x8                                   0x7
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_10x5                                  0x8
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_10x6                                  0x9
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_10x8                                  0xA
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_10x10                                 0xB
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_12x10                                 0xC
#define   MWV207REG_TX_ASTC1_SIZE_LOD5_12x12                                 0xD


#define MWV207REG_TX_ASTC1_SRGB_LOD5                                       12:12
#define MWV207REG_TX_ASTC1_SRGB_LOD5_End                                      12
#define MWV207REG_TX_ASTC1_SRGB_LOD5_Start                                    12
#define MWV207REG_TX_ASTC1_SRGB_LOD5_Type                                    U01
#define   MWV207REG_TX_ASTC1_SRGB_LOD5_DISABLE                               0x0
#define   MWV207REG_TX_ASTC1_SRGB_LOD5_ENABLE                                0x1


#define MWV207REG_TX_ASTC1_SIZE_LOD6                                       19:16
#define MWV207REG_TX_ASTC1_SIZE_LOD6_End                                      19
#define MWV207REG_TX_ASTC1_SIZE_LOD6_Start                                    16
#define MWV207REG_TX_ASTC1_SIZE_LOD6_Type                                    U04
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_4x4                                   0x0
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_5x4                                   0x1
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_5x5                                   0x2
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_6x5                                   0x3
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_6x6                                   0x4
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_8x5                                   0x5
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_8x6                                   0x6
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_8x8                                   0x7
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_10x5                                  0x8
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_10x6                                  0x9
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_10x8                                  0xA
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_10x10                                 0xB
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_12x10                                 0xC
#define   MWV207REG_TX_ASTC1_SIZE_LOD6_12x12                                 0xD


#define MWV207REG_TX_ASTC1_SRGB_LOD6                                       20:20
#define MWV207REG_TX_ASTC1_SRGB_LOD6_End                                      20
#define MWV207REG_TX_ASTC1_SRGB_LOD6_Start                                    20
#define MWV207REG_TX_ASTC1_SRGB_LOD6_Type                                    U01
#define   MWV207REG_TX_ASTC1_SRGB_LOD6_DISABLE                               0x0
#define   MWV207REG_TX_ASTC1_SRGB_LOD6_ENABLE                                0x1


#define MWV207REG_TX_ASTC1_SIZE_LOD7                                       27:24
#define MWV207REG_TX_ASTC1_SIZE_LOD7_End                                      27
#define MWV207REG_TX_ASTC1_SIZE_LOD7_Start                                    24
#define MWV207REG_TX_ASTC1_SIZE_LOD7_Type                                    U04
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_4x4                                   0x0
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_5x4                                   0x1
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_5x5                                   0x2
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_6x5                                   0x3
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_6x6                                   0x4
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_8x5                                   0x5
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_8x6                                   0x6
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_8x8                                   0x7
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_10x5                                  0x8
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_10x6                                  0x9
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_10x8                                  0xA
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_10x10                                 0xB
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_12x10                                 0xC
#define   MWV207REG_TX_ASTC1_SIZE_LOD7_12x12                                 0xD


#define MWV207REG_TX_ASTC1_SRGB_LOD7                                       28:28
#define MWV207REG_TX_ASTC1_SRGB_LOD7_End                                      28
#define MWV207REG_TX_ASTC1_SRGB_LOD7_Start                                    28
#define MWV207REG_TX_ASTC1_SRGB_LOD7_Type                                    U01
#define   MWV207REG_TX_ASTC1_SRGB_LOD7_DISABLE                               0x0
#define   MWV207REG_TX_ASTC1_SRGB_LOD7_ENABLE                                0x1




#define mwv207regTxASTC2RegAddrs                                          0x08C0
#define MWV207REG_TX_ASTC2_Address                                       0x02300
#define MWV207REG_TX_ASTC2_MSB                                                15
#define MWV207REG_TX_ASTC2_LSB                                                 4
#define MWV207REG_TX_ASTC2_BLK                                                 4
#define MWV207REG_TX_ASTC2_Count                                              16
#define MWV207REG_TX_ASTC2_FieldMask                                  0x1F1F1F1F
#define MWV207REG_TX_ASTC2_ReadMask                                   0x1F1F1F1F
#define MWV207REG_TX_ASTC2_WriteMask                                  0x1F1F1F1F
#define MWV207REG_TX_ASTC2_ResetValue                                 0x00000000


#define MWV207REG_TX_ASTC2_SIZE_LOD8                                         3:0
#define MWV207REG_TX_ASTC2_SIZE_LOD8_End                                       3
#define MWV207REG_TX_ASTC2_SIZE_LOD8_Start                                     0
#define MWV207REG_TX_ASTC2_SIZE_LOD8_Type                                    U04
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_4x4                                   0x0
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_5x4                                   0x1
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_5x5                                   0x2
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_6x5                                   0x3
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_6x6                                   0x4
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_8x5                                   0x5
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_8x6                                   0x6
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_8x8                                   0x7
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_10x5                                  0x8
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_10x6                                  0x9
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_10x8                                  0xA
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_10x10                                 0xB
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_12x10                                 0xC
#define   MWV207REG_TX_ASTC2_SIZE_LOD8_12x12                                 0xD


#define MWV207REG_TX_ASTC2_SRGB_LOD8                                         4:4
#define MWV207REG_TX_ASTC2_SRGB_LOD8_End                                       4
#define MWV207REG_TX_ASTC2_SRGB_LOD8_Start                                     4
#define MWV207REG_TX_ASTC2_SRGB_LOD8_Type                                    U01
#define   MWV207REG_TX_ASTC2_SRGB_LOD8_DISABLE                               0x0
#define   MWV207REG_TX_ASTC2_SRGB_LOD8_ENABLE                                0x1


#define MWV207REG_TX_ASTC2_SIZE_LOD9                                        11:8
#define MWV207REG_TX_ASTC2_SIZE_LOD9_End                                      11
#define MWV207REG_TX_ASTC2_SIZE_LOD9_Start                                     8
#define MWV207REG_TX_ASTC2_SIZE_LOD9_Type                                    U04
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_4x4                                   0x0
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_5x4                                   0x1
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_5x5                                   0x2
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_6x5                                   0x3
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_6x6                                   0x4
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_8x5                                   0x5
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_8x6                                   0x6
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_8x8                                   0x7
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_10x5                                  0x8
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_10x6                                  0x9
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_10x8                                  0xA
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_10x10                                 0xB
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_12x10                                 0xC
#define   MWV207REG_TX_ASTC2_SIZE_LOD9_12x12                                 0xD


#define MWV207REG_TX_ASTC2_SRGB_LOD9                                       12:12
#define MWV207REG_TX_ASTC2_SRGB_LOD9_End                                      12
#define MWV207REG_TX_ASTC2_SRGB_LOD9_Start                                    12
#define MWV207REG_TX_ASTC2_SRGB_LOD9_Type                                    U01
#define   MWV207REG_TX_ASTC2_SRGB_LOD9_DISABLE                               0x0
#define   MWV207REG_TX_ASTC2_SRGB_LOD9_ENABLE                                0x1


#define MWV207REG_TX_ASTC2_SIZE_LOD10                                      19:16
#define MWV207REG_TX_ASTC2_SIZE_LOD10_End                                     19
#define MWV207REG_TX_ASTC2_SIZE_LOD10_Start                                   16
#define MWV207REG_TX_ASTC2_SIZE_LOD10_Type                                   U04
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_4x4                                  0x0
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_5x4                                  0x1
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_5x5                                  0x2
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_6x5                                  0x3
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_6x6                                  0x4
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_8x5                                  0x5
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_8x6                                  0x6
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_8x8                                  0x7
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_10x5                                 0x8
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_10x6                                 0x9
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_10x8                                 0xA
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_10x10                                0xB
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_12x10                                0xC
#define   MWV207REG_TX_ASTC2_SIZE_LOD10_12x12                                0xD


#define MWV207REG_TX_ASTC2_SRGB_LOD10                                      20:20
#define MWV207REG_TX_ASTC2_SRGB_LOD10_End                                     20
#define MWV207REG_TX_ASTC2_SRGB_LOD10_Start                                   20
#define MWV207REG_TX_ASTC2_SRGB_LOD10_Type                                   U01
#define   MWV207REG_TX_ASTC2_SRGB_LOD10_DISABLE                              0x0
#define   MWV207REG_TX_ASTC2_SRGB_LOD10_ENABLE                               0x1


#define MWV207REG_TX_ASTC2_SIZE_LOD11                                      27:24
#define MWV207REG_TX_ASTC2_SIZE_LOD11_End                                     27
#define MWV207REG_TX_ASTC2_SIZE_LOD11_Start                                   24
#define MWV207REG_TX_ASTC2_SIZE_LOD11_Type                                   U04
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_4x4                                  0x0
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_5x4                                  0x1
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_5x5                                  0x2
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_6x5                                  0x3
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_6x6                                  0x4
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_8x5                                  0x5
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_8x6                                  0x6
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_8x8                                  0x7
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_10x5                                 0x8
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_10x6                                 0x9
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_10x8                                 0xA
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_10x10                                0xB
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_12x10                                0xC
#define   MWV207REG_TX_ASTC2_SIZE_LOD11_12x12                                0xD


#define MWV207REG_TX_ASTC2_SRGB_LOD11                                      28:28
#define MWV207REG_TX_ASTC2_SRGB_LOD11_End                                     28
#define MWV207REG_TX_ASTC2_SRGB_LOD11_Start                                   28
#define MWV207REG_TX_ASTC2_SRGB_LOD11_Type                                   U01
#define   MWV207REG_TX_ASTC2_SRGB_LOD11_DISABLE                              0x0
#define   MWV207REG_TX_ASTC2_SRGB_LOD11_ENABLE                               0x1




#define mwv207regTxASTC3RegAddrs                                          0x08D0
#define MWV207REG_TX_ASTC3_Address                                       0x02340
#define MWV207REG_TX_ASTC3_MSB                                                15
#define MWV207REG_TX_ASTC3_LSB                                                 4
#define MWV207REG_TX_ASTC3_BLK                                                 4
#define MWV207REG_TX_ASTC3_Count                                              16
#define MWV207REG_TX_ASTC3_FieldMask                                  0x1F1F1F1F
#define MWV207REG_TX_ASTC3_ReadMask                                   0x1F1F1F1F
#define MWV207REG_TX_ASTC3_WriteMask                                  0x1F1F1F1F
#define MWV207REG_TX_ASTC3_ResetValue                                 0x00000000


#define MWV207REG_TX_ASTC3_SIZE_LOD12                                        3:0
#define MWV207REG_TX_ASTC3_SIZE_LOD12_End                                      3
#define MWV207REG_TX_ASTC3_SIZE_LOD12_Start                                    0
#define MWV207REG_TX_ASTC3_SIZE_LOD12_Type                                   U04
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_4x4                                  0x0
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_5x4                                  0x1
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_5x5                                  0x2
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_6x5                                  0x3
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_6x6                                  0x4
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_8x5                                  0x5
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_8x6                                  0x6
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_8x8                                  0x7
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_10x5                                 0x8
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_10x6                                 0x9
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_10x8                                 0xA
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_10x10                                0xB
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_12x10                                0xC
#define   MWV207REG_TX_ASTC3_SIZE_LOD12_12x12                                0xD


#define MWV207REG_TX_ASTC3_SRGB_LOD12                                        4:4
#define MWV207REG_TX_ASTC3_SRGB_LOD12_End                                      4
#define MWV207REG_TX_ASTC3_SRGB_LOD12_Start                                    4
#define MWV207REG_TX_ASTC3_SRGB_LOD12_Type                                   U01
#define   MWV207REG_TX_ASTC3_SRGB_LOD12_DISABLE                              0x0
#define   MWV207REG_TX_ASTC3_SRGB_LOD12_ENABLE                               0x1


#define MWV207REG_TX_ASTC3_SIZE_LOD13                                       11:8
#define MWV207REG_TX_ASTC3_SIZE_LOD13_End                                     11
#define MWV207REG_TX_ASTC3_SIZE_LOD13_Start                                    8
#define MWV207REG_TX_ASTC3_SIZE_LOD13_Type                                   U04
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_4x4                                  0x0
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_5x4                                  0x1
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_5x5                                  0x2
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_6x5                                  0x3
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_6x6                                  0x4
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_8x5                                  0x5
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_8x6                                  0x6
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_8x8                                  0x7
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_10x5                                 0x8
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_10x6                                 0x9
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_10x8                                 0xA
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_10x10                                0xB
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_12x10                                0xC
#define   MWV207REG_TX_ASTC3_SIZE_LOD13_12x12                                0xD


#define MWV207REG_TX_ASTC3_SRGB_LOD13                                      12:12
#define MWV207REG_TX_ASTC3_SRGB_LOD13_End                                     12
#define MWV207REG_TX_ASTC3_SRGB_LOD13_Start                                   12
#define MWV207REG_TX_ASTC3_SRGB_LOD13_Type                                   U01
#define   MWV207REG_TX_ASTC3_SRGB_LOD13_DISABLE                              0x0
#define   MWV207REG_TX_ASTC3_SRGB_LOD13_ENABLE                               0x1


#define MWV207REG_TX_ASTC3_SIZE_LOD14                                      19:16
#define MWV207REG_TX_ASTC3_SIZE_LOD14_End                                     19
#define MWV207REG_TX_ASTC3_SIZE_LOD14_Start                                   16
#define MWV207REG_TX_ASTC3_SIZE_LOD14_Type                                   U04
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_4x4                                  0x0
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_5x4                                  0x1
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_5x5                                  0x2
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_6x5                                  0x3
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_6x6                                  0x4
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_8x5                                  0x5
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_8x6                                  0x6
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_8x8                                  0x7
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_10x5                                 0x8
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_10x6                                 0x9
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_10x8                                 0xA
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_10x10                                0xB
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_12x10                                0xC
#define   MWV207REG_TX_ASTC3_SIZE_LOD14_12x12                                0xD


#define MWV207REG_TX_ASTC3_SRGB_LOD14                                      20:20
#define MWV207REG_TX_ASTC3_SRGB_LOD14_End                                     20
#define MWV207REG_TX_ASTC3_SRGB_LOD14_Start                                   20
#define MWV207REG_TX_ASTC3_SRGB_LOD14_Type                                   U01
#define   MWV207REG_TX_ASTC3_SRGB_LOD14_DISABLE                              0x0
#define   MWV207REG_TX_ASTC3_SRGB_LOD14_ENABLE                               0x1


#define MWV207REG_TX_ASTC3_SIZE_LOD15                                      27:24
#define MWV207REG_TX_ASTC3_SIZE_LOD15_End                                     27
#define MWV207REG_TX_ASTC3_SIZE_LOD15_Start                                   24
#define MWV207REG_TX_ASTC3_SIZE_LOD15_Type                                   U04
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_4x4                                  0x0
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_5x4                                  0x1
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_5x5                                  0x2
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_6x5                                  0x3
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_6x6                                  0x4
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_8x5                                  0x5
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_8x6                                  0x6
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_8x8                                  0x7
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_10x5                                 0x8
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_10x6                                 0x9
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_10x8                                 0xA
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_10x10                                0xB
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_12x10                                0xC
#define   MWV207REG_TX_ASTC3_SIZE_LOD15_12x12                                0xD


#define MWV207REG_TX_ASTC3_SRGB_LOD15                                      28:28
#define MWV207REG_TX_ASTC3_SRGB_LOD15_End                                     28
#define MWV207REG_TX_ASTC3_SRGB_LOD15_Start                                   28
#define MWV207REG_TX_ASTC3_SRGB_LOD15_Type                                   U01
#define   MWV207REG_TX_ASTC3_SRGB_LOD15_DISABLE                              0x0
#define   MWV207REG_TX_ASTC3_SRGB_LOD15_ENABLE                               0x1




#define AQTextureBaseLODRegAddrs                                          0x08E0
#define AQ_TEXTURE_BASE_LOD_Address                                      0x02380
#define AQ_TEXTURE_BASE_LOD_MSB                                               15
#define AQ_TEXTURE_BASE_LOD_LSB                                                4
#define AQ_TEXTURE_BASE_LOD_BLK                                                4
#define AQ_TEXTURE_BASE_LOD_Count                                             16
#define AQ_TEXTURE_BASE_LOD_FieldMask                                 0x01F10F0F
#define AQ_TEXTURE_BASE_LOD_ReadMask                                  0x01F10F0F
#define AQ_TEXTURE_BASE_LOD_WriteMask                                 0x01F10F0F
#define AQ_TEXTURE_BASE_LOD_ResetValue                                0x00000F00


#define AQ_TEXTURE_BASE_LOD_BASE_LEVEL                                       3:0
#define AQ_TEXTURE_BASE_LOD_BASE_LEVEL_End                                     3
#define AQ_TEXTURE_BASE_LOD_BASE_LEVEL_Start                                   0
#define AQ_TEXTURE_BASE_LOD_BASE_LEVEL_Type                                  U04


#define AQ_TEXTURE_BASE_LOD_MAX_LEVEL                                       11:8
#define AQ_TEXTURE_BASE_LOD_MAX_LEVEL_End                                     11
#define AQ_TEXTURE_BASE_LOD_MAX_LEVEL_Start                                    8
#define AQ_TEXTURE_BASE_LOD_MAX_LEVEL_Type                                   U04


#define AQ_TEXTURE_BASE_LOD_COMPARE_MODE                                   16:16
#define AQ_TEXTURE_BASE_LOD_COMPARE_MODE_End                                  16
#define AQ_TEXTURE_BASE_LOD_COMPARE_MODE_Start                                16
#define AQ_TEXTURE_BASE_LOD_COMPARE_MODE_Type                                U01

#define   AQ_TEXTURE_BASE_LOD_COMPARE_MODE_NONE                              0x0

#define   AQ_TEXTURE_BASE_LOD_COMPARE_MODE_REFERENCE                         0x1


#define AQ_TEXTURE_BASE_LOD_COMPARE_FUNC                                   22:20
#define AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_End                                  22
#define AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_Start                                20
#define AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_Type                                U03
#define   AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_LEQUAL                            0x0
#define   AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_GEQUAL                            0x1
#define   AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_LESS                              0x2
#define   AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_GREATER                           0x3
#define   AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_EQUAL                             0x4
#define   AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_NOT_EQUAL                         0x5
#define   AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_ALWAYS                            0x6
#define   AQ_TEXTURE_BASE_LOD_COMPARE_FUNC_NEVER                             0x7


#define AQ_TEXTURE_BASE_LOD_CALCULATION_MODE                               24:23
#define AQ_TEXTURE_BASE_LOD_CALCULATION_MODE_End                              24
#define AQ_TEXTURE_BASE_LOD_CALCULATION_MODE_Start                            23
#define AQ_TEXTURE_BASE_LOD_CALCULATION_MODE_Type                            U02
#define   AQ_TEXTURE_BASE_LOD_CALCULATION_MODE_D3D_ES20                      0x0
#define   AQ_TEXTURE_BASE_LOD_CALCULATION_MODE_ES30                          0x1

#define AQTextureConfig2RegAddrs                                          0x08F0
#define AQ_TEXTURE_CONFIG2_Address                                       0x023C0
#define AQ_TEXTURE_CONFIG2_MSB                                                15
#define AQ_TEXTURE_CONFIG2_LSB                                                 4
#define AQ_TEXTURE_CONFIG2_BLK                                                 4
#define AQ_TEXTURE_CONFIG2_Count                                              16
#define AQ_TEXTURE_CONFIG2_FieldMask                                  0xFF9F3333
#define AQ_TEXTURE_CONFIG2_ReadMask                                   0xFF9F3333
#define AQ_TEXTURE_CONFIG2_WriteMask                                  0xFF9F3333
#define AQ_TEXTURE_CONFIG2_ResetValue                                 0x00030000


#define AQ_TEXTURE_CONFIG2_NORM_RED                                          1:0
#define AQ_TEXTURE_CONFIG2_NORM_RED_End                                        1
#define AQ_TEXTURE_CONFIG2_NORM_RED_Start                                      0
#define AQ_TEXTURE_CONFIG2_NORM_RED_Type                                     U02
#define   AQ_TEXTURE_CONFIG2_NORM_RED_DISABLE                                0x0
#define   AQ_TEXTURE_CONFIG2_NORM_RED_UNSIGNED                               0x1
#define   AQ_TEXTURE_CONFIG2_NORM_RED_SIGNED                                 0x2


#define AQ_TEXTURE_CONFIG2_NORM_GREEN                                        5:4
#define AQ_TEXTURE_CONFIG2_NORM_GREEN_End                                      5
#define AQ_TEXTURE_CONFIG2_NORM_GREEN_Start                                    4
#define AQ_TEXTURE_CONFIG2_NORM_GREEN_Type                                   U02
#define   AQ_TEXTURE_CONFIG2_NORM_GREEN_DISABLE                              0x0
#define   AQ_TEXTURE_CONFIG2_NORM_GREEN_UNSIGNED                             0x1
#define   AQ_TEXTURE_CONFIG2_NORM_GREEN_SIGNED                               0x2


#define AQ_TEXTURE_CONFIG2_NORM_BLUE                                         9:8
#define AQ_TEXTURE_CONFIG2_NORM_BLUE_End                                       9
#define AQ_TEXTURE_CONFIG2_NORM_BLUE_Start                                     8
#define AQ_TEXTURE_CONFIG2_NORM_BLUE_Type                                    U02
#define   AQ_TEXTURE_CONFIG2_NORM_BLUE_DISABLE                               0x0
#define   AQ_TEXTURE_CONFIG2_NORM_BLUE_UNSIGNED                              0x1
#define   AQ_TEXTURE_CONFIG2_NORM_BLUE_SIGNED                                0x2


#define AQ_TEXTURE_CONFIG2_NORM_ALPHA                                      13:12
#define AQ_TEXTURE_CONFIG2_NORM_ALPHA_End                                     13
#define AQ_TEXTURE_CONFIG2_NORM_ALPHA_Start                                   12
#define AQ_TEXTURE_CONFIG2_NORM_ALPHA_Type                                   U02
#define   AQ_TEXTURE_CONFIG2_NORM_ALPHA_DISABLE                              0x0
#define   AQ_TEXTURE_CONFIG2_NORM_ALPHA_UNSIGNED                             0x1
#define   AQ_TEXTURE_CONFIG2_NORM_ALPHA_SIGNED                               0x2


#define AQ_TEXTURE_CONFIG2_TX_FILTER_CLAMP                                 16:16
#define AQ_TEXTURE_CONFIG2_TX_FILTER_CLAMP_End                                16
#define AQ_TEXTURE_CONFIG2_TX_FILTER_CLAMP_Start                              16
#define AQ_TEXTURE_CONFIG2_TX_FILTER_CLAMP_Type                              U01
#define   AQ_TEXTURE_CONFIG2_TX_FILTER_CLAMP_ENABLE                          0x0
#define   AQ_TEXTURE_CONFIG2_TX_FILTER_CLAMP_DISABLE                         0x1


#define AQ_TEXTURE_CONFIG2_TX_COLOR_CLAMP                                  17:17
#define AQ_TEXTURE_CONFIG2_TX_COLOR_CLAMP_End                                 17
#define AQ_TEXTURE_CONFIG2_TX_COLOR_CLAMP_Start                               17
#define AQ_TEXTURE_CONFIG2_TX_COLOR_CLAMP_Type                               U01
#define   AQ_TEXTURE_CONFIG2_TX_COLOR_CLAMP_ENABLE                           0x0
#define   AQ_TEXTURE_CONFIG2_TX_COLOR_CLAMP_DISABLE                          0x1


#define AQ_TEXTURE_CONFIG2_INTEGER_SIGN_EXTENSION                          19:18
#define AQ_TEXTURE_CONFIG2_INTEGER_SIGN_EXTENSION_End                         19
#define AQ_TEXTURE_CONFIG2_INTEGER_SIGN_EXTENSION_Start                       18
#define AQ_TEXTURE_CONFIG2_INTEGER_SIGN_EXTENSION_Type                       U02

#define   AQ_TEXTURE_CONFIG2_INTEGER_SIGN_EXTENSION_NONE                     0x0

#define   AQ_TEXTURE_CONFIG2_INTEGER_SIGN_EXTENSION_SIGNED8                  0x1

#define   AQ_TEXTURE_CONFIG2_INTEGER_SIGN_EXTENSION_SIGNED16                 0x2


#define AQ_TEXTURE_CONFIG2_GUARDBAND_ENABLE                                20:20
#define AQ_TEXTURE_CONFIG2_GUARDBAND_ENABLE_End                               20
#define AQ_TEXTURE_CONFIG2_GUARDBAND_ENABLE_Start                             20
#define AQ_TEXTURE_CONFIG2_GUARDBAND_ENABLE_Type                             U01
#define   AQ_TEXTURE_CONFIG2_GUARDBAND_ENABLE_DISABLE                        0x0
#define   AQ_TEXTURE_CONFIG2_GUARDBAND_ENABLE_ENABLE                         0x1


#define AQ_TEXTURE_CONFIG2_TX128_BYTE_REQUEST                              23:23
#define AQ_TEXTURE_CONFIG2_TX128_BYTE_REQUEST_End                             23
#define AQ_TEXTURE_CONFIG2_TX128_BYTE_REQUEST_Start                           23
#define AQ_TEXTURE_CONFIG2_TX128_BYTE_REQUEST_Type                           U01
#define   AQ_TEXTURE_CONFIG2_TX128_BYTE_REQUEST_DISABLE                      0x0
#define   AQ_TEXTURE_CONFIG2_TX128_BYTE_REQUEST_ENABLE                       0x1


#define AQ_TEXTURE_CONFIG2_GUARDBAND_INDEX                                 27:24
#define AQ_TEXTURE_CONFIG2_GUARDBAND_INDEX_End                                27
#define AQ_TEXTURE_CONFIG2_GUARDBAND_INDEX_Start                              24
#define AQ_TEXTURE_CONFIG2_GUARDBAND_INDEX_Type                              U04


#define AQ_TEXTURE_CONFIG2_TILE_STATUS_CLIENT                              30:28
#define AQ_TEXTURE_CONFIG2_TILE_STATUS_CLIENT_End                             30
#define AQ_TEXTURE_CONFIG2_TILE_STATUS_CLIENT_Start                           28
#define AQ_TEXTURE_CONFIG2_TILE_STATUS_CLIENT_Type                           U03


#define AQ_TEXTURE_CONFIG2_COMPRESSION_DEC                                 31:31
#define AQ_TEXTURE_CONFIG2_COMPRESSION_DEC_End                                31
#define AQ_TEXTURE_CONFIG2_COMPRESSION_DEC_Start                              31
#define AQ_TEXTURE_CONFIG2_COMPRESSION_DEC_Type                              U01
#define   AQ_TEXTURE_CONFIG2_COMPRESSION_DEC_DISABLE                         0x0
#define   AQ_TEXTURE_CONFIG2_COMPRESSION_DEC_ENABLE                          0x1


#define AQTextureSampleLod00AddressRegAddrs                               0x0900
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_Address                          0x02400
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD00_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod01AddressRegAddrs                               0x0910
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_Address                          0x02440
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD01_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod02AddressRegAddrs                               0x0920
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_Address                          0x02480
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD02_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod03AddressRegAddrs                               0x0930
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_Address                          0x024C0
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD03_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod04AddressRegAddrs                               0x0940
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_Address                          0x02500
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD04_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod05AddressRegAddrs                               0x0950
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_Address                          0x02540
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD05_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod06AddressRegAddrs                               0x0960
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_Address                          0x02580
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD06_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod07AddressRegAddrs                               0x0970
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_Address                          0x025C0
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD07_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod08AddressRegAddrs                               0x0980
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_Address                          0x02600
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_ResetValue                    0x00000000


#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD08_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod09AddressRegAddrs                               0x0990
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_Address                          0x02640
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_ResetValue                    0x00000000

#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD09_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod10AddressRegAddrs                               0x09A0
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_Address                          0x02680
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_ResetValue                    0x00000000

#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD10_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod11AddressRegAddrs                               0x09B0
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_Address                          0x026C0
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_ResetValue                    0x00000000

#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD11_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod12AddressRegAddrs                               0x09C0
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_Address                          0x02700
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_ResetValue                    0x00000000

#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD12_ADDRESS_ADDR_Type                            U32

#define AQTextureSampleLod13AddressRegAddrs                               0x09D0
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_Address                          0x02740
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_MSB                                   15
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_LSB                                    4
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_BLK                                    4
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_Count                                 12
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_FieldMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_ReadMask                      0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_WriteMask                     0xFFFFFFFF
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_ResetValue                    0x00000000

#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_ADDR                                31:0
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_ADDR_End                              31
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_ADDR_Start                             0
#define AQ_TEXTURE_SAMPLE_LOD13_ADDRESS_ADDR_Type                            U32


#define mwv207regTXSamplerStrideRegAddrs                                  0x0B00
#define MWV207REG_TX_SAMPLER_STRIDE_Address                              0x02C00
#define MWV207REG_TX_SAMPLER_STRIDE_MSB                                       15
#define MWV207REG_TX_SAMPLER_STRIDE_LSB                                        8
#define MWV207REG_TX_SAMPLER_STRIDE_BLK                                        4
#define MWV207REG_TX_SAMPLER_STRIDE_Count                                    256
#define MWV207REG_TX_SAMPLER_STRIDE_FieldMask                         0xFFFFFFFF
#define MWV207REG_TX_SAMPLER_STRIDE_ReadMask                          0xFFFFFFFF
#define MWV207REG_TX_SAMPLER_STRIDE_WriteMask                         0xFFFFFFFF
#define MWV207REG_TX_SAMPLER_STRIDE_ResetValue                        0x00000000


#define MWV207REG_TX_SAMPLER_STRIDE_STRIDE                                  15:0
#define MWV207REG_TX_SAMPLER_STRIDE_STRIDE_End                                15
#define MWV207REG_TX_SAMPLER_STRIDE_STRIDE_Start                               0
#define MWV207REG_TX_SAMPLER_STRIDE_STRIDE_Type                              U16


#define MWV207REG_TX_SAMPLER_STRIDE_SLICE                                  31:16
#define MWV207REG_TX_SAMPLER_STRIDE_SLICE_End                                 31
#define MWV207REG_TX_SAMPLER_STRIDE_SLICE_Start                               16
#define MWV207REG_TX_SAMPLER_STRIDE_SLICE_Type                               U16



#define AQ_TEXTURE_TO_SHADER_FORMAT                                          4:0
#define AQ_TEXTURE_TO_SHADER_FORMAT_End                                        4
#define AQ_TEXTURE_TO_SHADER_FORMAT_Start                                      0
#define AQ_TEXTURE_TO_SHADER_FORMAT_Type                                     U05
#define   AQ_TEXTURE_TO_SHADER_FORMAT_INTERNAL                              0x00
#define   AQ_TEXTURE_TO_SHADER_FORMAT_U16                                   0x01
#define   AQ_TEXTURE_TO_SHADER_FORMAT_D16                                   0x01
#define   AQ_TEXTURE_TO_SHADER_FORMAT_U24                                   0x02
#define   AQ_TEXTURE_TO_SHADER_FORMAT_D24                                   0x02
#define   AQ_TEXTURE_TO_SHADER_FORMAT_RGBE8                                 0x03
#define   AQ_TEXTURE_TO_SHADER_FORMAT_RGB9E5                                0x04
#define   AQ_TEXTURE_TO_SHADER_FORMAT_FLOAT32                               0x05
#define   AQ_TEXTURE_TO_SHADER_FORMAT_INTEGER                               0x06
#define   AQ_TEXTURE_TO_SHADER_FORMAT_INTERNAL_NORMALIZE                    0x07
#define   AQ_TEXTURE_TO_SHADER_FORMAT_LOD                                   0x0A
#define   AQ_TEXTURE_TO_SHADER_FORMAT_GATHER_U16                            0x0B
#define   AQ_TEXTURE_TO_SHADER_FORMAT_GATHER_D16                            0x0B
#define   AQ_TEXTURE_TO_SHADER_FORMAT_GATHER_U24                            0x0C
#define   AQ_TEXTURE_TO_SHADER_FORMAT_GATHER_D24                            0x0C
#define   AQ_TEXTURE_TO_SHADER_FORMAT_GATHER_32                             0x0D
#define   AQ_TEXTURE_TO_SHADER_FORMAT_GATHER_64                             0x0E
#define   AQ_TEXTURE_TO_SHADER_FORMAT_GATHER_128                            0x0F
#define   AQ_TEXTURE_TO_SHADER_FORMAT_GATHER_D32                            0x10
#define   AQ_TEXTURE_TO_SHADER_FORMAT_INTEGER32                             0x11
#define   AQ_TEXTURE_TO_SHADER_FORMAT_STENCIL_D32F8                         0x12
#define   AQ_TEXTURE_TO_SHADER_FORMAT_STENCIL_UINT8                         0x12
#define   AQ_TEXTURE_TO_SHADER_FORMAT_D32F                                  0x13
#define   AQ_TEXTURE_TO_SHADER_FORMAT_D32FPCF                               0x14
#define   AQ_TEXTURE_TO_SHADER_FORMAT_SNORM16                               0x15
#define   AQ_TEXTURE_TO_SHADER_FORMAT_UNORM16                               0x16


#define AQ_TEXTURE_TYPE                                                      2:0
#define AQ_TEXTURE_TYPE_End                                                    2
#define AQ_TEXTURE_TYPE_Start                                                  0
#define AQ_TEXTURE_TYPE_Type                                                 U03
#define   AQ_TEXTURE_TYPE_NONE                                               0x0
#define   AQ_TEXTURE_TYPE_1D                                                 0x1
#define   AQ_TEXTURE_TYPE_2D                                                 0x2
#define   AQ_TEXTURE_TYPE_3D                                                 0x3
#define   AQ_TEXTURE_TYPE_PROJECTED                                          0x4
#define   AQ_TEXTURE_TYPE_CUBIC_MAP                                          0x5

#define AQ_TEXTURE_ADDRESS_MODE                                              4:3
#define AQ_TEXTURE_ADDRESS_MODE_End                                            4
#define AQ_TEXTURE_ADDRESS_MODE_Start                                          3
#define AQ_TEXTURE_ADDRESS_MODE_Type                                         U02
#define   AQ_TEXTURE_ADDRESS_MODE_WRAP                                       0x0
#define   AQ_TEXTURE_ADDRESS_MODE_MIRROR                                     0x1
#define   AQ_TEXTURE_ADDRESS_MODE_CLAMP                                      0x2
#define   AQ_TEXTURE_ADDRESS_MODE_BORDER                                     0x3

#define AQ_TEXTURE_FORMAT                                                    9:5
#define AQ_TEXTURE_FORMAT_End                                                  9
#define AQ_TEXTURE_FORMAT_Start                                                5
#define AQ_TEXTURE_FORMAT_Type                                               U05
#define   AQ_TEXTURE_FORMAT_A8                                              0x01
#define   AQ_TEXTURE_FORMAT_L8                                              0x02
#define   AQ_TEXTURE_FORMAT_I8                                              0x03
#define   AQ_TEXTURE_FORMAT_A8L8                                            0x04
#define   AQ_TEXTURE_FORMAT_ARGB4                                           0x05
#define   AQ_TEXTURE_FORMAT_XRGB4                                           0x06
#define   AQ_TEXTURE_FORMAT_ARGB8                                           0x07
#define   AQ_TEXTURE_FORMAT_XRGB8                                           0x08
#define   AQ_TEXTURE_FORMAT_ABGR8                                           0x09
#define   AQ_TEXTURE_FORMAT_XBGR8                                           0x0A
#define   AQ_TEXTURE_FORMAT_R5G6B5                                          0x0B
#define   AQ_TEXTURE_FORMAT_A1RGB5                                          0x0C
#define   AQ_TEXTURE_FORMAT_X1RGB5                                          0x0D
#define   AQ_TEXTURE_FORMAT_YUY2                                            0x0E
#define   AQ_TEXTURE_FORMAT_UYVY                                            0x0F
#define   AQ_TEXTURE_FORMAT_D16                                             0x10
#define   AQ_TEXTURE_FORMAT_D24X8                                           0x11
#define   AQ_TEXTURE_FORMAT_A8_OES                                          0x12
#define   AQ_TEXTURE_FORMAT_DXT1                                            0x13
#define   AQ_TEXTURE_FORMAT_DXT2                                            0x14
#define   AQ_TEXTURE_FORMAT_DXT3                                            0x14
#define   AQ_TEXTURE_FORMAT_DXT4                                            0x15
#define   AQ_TEXTURE_FORMAT_DXT5                                            0x15
#define   AQ_TEXTURE_FORMAT_HDR7E3                                          0x16
#define   AQ_TEXTURE_FORMAT_HDR6E4                                          0x17
#define   AQ_TEXTURE_FORMAT_HDR5E5                                          0x18
#define   AQ_TEXTURE_FORMAT_HDR6E5                                          0x19
#define   AQ_TEXTURE_FORMAT_RGBE8                                           0x1A
#define   AQ_TEXTURE_FORMAT_RGBE8F                                          0x1B
#define   AQ_TEXTURE_FORMAT_RGB9E5                                          0x1C
#define   AQ_TEXTURE_FORMAT_RGB9E5F                                         0x1D
#define   AQ_TEXTURE_FORMAT_ETC1                                            0x1E

#define AQ_TEXTURE_FILTER                                                  11:10
#define AQ_TEXTURE_FILTER_End                                                 11
#define AQ_TEXTURE_FILTER_Start                                               10
#define AQ_TEXTURE_FILTER_Type                                               U02
#define   AQ_TEXTURE_FILTER_NONE                                             0x0
#define   AQ_TEXTURE_FILTER_POINT                                            0x1
#define   AQ_TEXTURE_FILTER_LINEAR                                           0x2
#define   AQ_TEXTURE_FILTER_ANISOTROPIC                                      0x3

#define   AQ_CONST_VS_TEXTURE_SAMPLES                                       0x04
#define   AQ_CONST_PS_TEXTURE_SAMPLES                                       0x08
#define   AQ_CONST_LOD_COUNT                                                0x10
#define   AQ_CONST_PS_IMAGE_SAMPLERS                                        0x04

#define   AQ_TEXTURE_LOAD_PLAIN                                             0x00
#define   AQ_TEXTURE_LOAD_USER_LOD_BIAS                                     0x01
#define   AQ_TEXTURE_LOAD_USER_LOD                                          0x02
#define   AQ_TEXTURE_LOAD_PCF                                               0x03
#define   AQ_TEXTURE_LOAD_LOD                                               0x04
#define   AQ_TEXTURE_LOAD_LOD_PCF                                           0x05
#define   AQ_TEXTURE_LOAD_BIAS                                              0x06
#define   AQ_TEXTURE_LOAD_BIAS_PCF                                          0x07
#define   AQ_TEXTURE_LOAD_STATE                                             0x08
#define   AQ_TEXTURE_LOAD_STATE_LOD                                         0x09
#define   AQ_TEXTURE_LOAD_STATE_BIAS                                        0x0A
#define   AQ_TEXTURE_LOAD_QUERY                                             0x0B
#define   AQ_TEXTURE_LOAD_QUERY_BIAS                                        0x0C
#define   AQ_TEXTURE_LOAD_GATHER                                            0x0D
#define   AQ_TEXTURE_LOAD_GATHER_PCF                                        0x0E
#define   AQ_TEXTURE_LOAD_FETCH_MS                                          0x0F
#define   AQ_TEXTURE_LOAD_FLUSH                                             0x10

#define   MWV207_REG_TX_SWIZZLE_USING_RED                                    0x0
#define   MWV207_REG_TX_SWIZZLE_USING_GREEN                                  0x1
#define   MWV207_REG_TX_SWIZZLE_USING_BLUE                                   0x2
#define   MWV207_REG_TX_SWIZZLE_USING_ALPHA                                  0x3
#define   MWV207_REG_TX_SWIZZLE_USING_ZERO                                   0x4
#define   MWV207_REG_TX_SWIZZLE_USING_ONE                                    0x5


#endif


