if [ -e /dev/jmgpu ]; then
	export  __GLX_VENDOR_LIBRARY_NAME=mwv207
fi
