#!/bin/bash

# set -x

CPU=`LANG=en uname -m`
OS=`cat /etc/os-release | sed -n '/^ID=/p' | sed -e 's/"//g' -e 's/ID=//g'`
LIBDIR=/usr/lib/`gcc -print-multiarch`
MULTIARCH=`gcc -print-multiarch`
KERNELMV=`uname -r | awk -F. '{ print $1"."$2}'`

ISGLVND=0
# ii  libglvnd-dev:arm64
# ii  libglvnd0:arm64
HASGLVND=`dpkg -l | grep glvnd`
if [ ! -z "${HASGLVND}" ]; then
	# 有安装 libglvnd
	ISGLVND=1
fi
if [ "${CPU}" == "loongarch64" -o "${CPU}" == "mips64" -o "${CPU}" == "sw_64" ]; then
	# 龙芯平台不支持 glvnd
	ISGLVND=0
fi

count=0
while true
do
	JM7200=`lspci -d 0731:* -n | grep '0731:7' | wc -l`
	JM9200=`lspci -d 0731:* -n | grep '0731:9' | wc -l`
	if [ $JM7200 -gt 0 ]; then
		if [ -e /dev/cur_gl ]; then
			# 麒麟添加的类似 glvnd 处理
			ISGLVND=1
		fi
	fi
	if [ $JM9200 -gt 0 ];then
		if [ -e /dev/cur_gl ]; then
			# 麒麟添加的类似 glvnd 处理
			ISGLVND=1
		fi
	fi
	count=`expr $count + 1`
	if [ $count -gt 5 ]; then
		break;
	fi
done

if [  "${CPU}" == "sw_64" ]; then
	# sw平台不支持 glvnd
	ISGLVND=0
fi
# 是否有安装 mwv206-dev 驱动包
ISMWV206=`dpkg -l | egrep "mwv206-dev|com.jingjiamicro.mwv206" | wc -l`

# 操作系统支持 glvnd ，92的驱动就不需要修改
if [ "${ISGLVND}" == "0" ]; then
	# 操作系统不支持 glvnd

	if [ "${ISMWV206}" != "0" ]; then
		# 有安装 mwv206-dev 驱动包
		echo "update mwv206 switch-gl" >> /opt/mwv207/usr/share/doc/switch-gl.log
	else
		# 没有安装 mwv206-dev 驱动包
		echo "enable mwv207 switch-gl" >> /opt/mwv207/usr/share/doc/switch-gl.log
	fi

	cp /opt/mwv207/usr/sbin/switch-gl.sh /usr/sbin/switch-gl
	cp /opt/mwv207/lib/systemd/system/sw-gl.service /lib/systemd/system/sw-gl.service
	systemctl daemon-reload
	systemctl enable sw-gl.service
	systemctl start sw-gl.service

	/opt/mwv207/usr/sbin/switch-gl.sh
fi

# 有 JM92 显卡
if [ $JM9200 -gt 0 ];then
	if [ -e /usr/share/X11/xorg.conf.d/10-mwv206.conf ]; then
		# 删除 JM72 的 xorg 配置文件
		rm -rf /usr/share/X11/xorg.conf.d/10-mwv206.conf
	fi
fi


