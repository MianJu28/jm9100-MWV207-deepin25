#!/bin/bash
#set -x

function update_360browser(){
    QD=/opt/apps/com.360.browser-stable/files/com.360.browser
    if [ -e "$QD" ];then
        ISMWV=`grep disable-gpu-rasterization ${QD}`
        if [ "${ISMWV}" == "" ]; then
            sed -i '/exec/s/browser360\"/browser360\" --disable-gpu-rasterization/g'  ${QD}
        fi
    fi

}

function update_qaxbrowser(){
    QD=/opt/apps/com.qianxin.browser-stable/files/com.qianxin.browser
    if [ -e "$QD" ];then
        ISMWV=`grep disable-gpu-rasterization ${QD}`
        if [ "${ISMWV}" == "" ]; then
            sed -i '/exec/s/qaxbrowser\"/qaxbrowser\" --disable-gpu-rasterization/g'  ${QD}
        fi
    fi

}

function update_org.deepin.browser(){
QD=/usr/bin/browser
if [ -e "$QD" ];then
    ISMWV=`grep disable-gpu-rasterization ${QD}`
    if [ "${ISMWV}" == "" ]; then
        sed -i '/exec/s/browser\"/browser\" --disable-gpu-rasterization/g'  ${QD}
    fi
fi

}

function update_loongnix.lbrowser(){
QD=/opt/apps/cn.loongnix.lbrowser/files/cn.loongnix.lbrowser
if [ -e "$QD" ];then
    ISMWV=`grep disable-gpu-rasterization ${QD}`
    if [ "${ISMWV}" == "" ]; then
        sed -i '/exec/s/lbrowser\"/lbrowser\" --disable-gpu-rasterization/g'  ${QD}
    fi
fi

}

function update_chromuium(){
    QD=/usr/bin/chromium-browser
    if [ -e "$QD" ];then
        ISMWV=`grep disable-gpu-rasterization ${QD}`
        if [ "${ISMWV}" == "" ]; then
            sed -i '/exec/s/APPNAME/APPNAME --disable-gpu-rasterization/g'  ${QD}
        fi
    fi

}


function update_code(){
    QD=/usr/share/applications/code.desktop
    if [ -e "$QD" ];then
        ISMW=`grep disable-gpu-rasterization $QD`
        if [ "$ISMW" == "" ];then
                sed -i 's|Exec=/usr/share/code/code|Exec=/usr/share/code/code --disable-gpu-rasterization|'  $QD
            USERS=`ls /home/`
            for USER in ${USERS}
            do
                if [ -e /home/${USER}/桌面/code.desktop ];then
                    cp /usr/share/applications/code.desktop /home/${USER}/桌面/code.desktop
                fi
            done

        fi
    fi
}


function update_linuxqq(){
    QD=/usr/share/applications/qq.desktop
    if [ -e "$QD" ];then
        ISMW=`grep disable-gpu-rasterization $QD`
        if [ "$ISMW" == "" ];then
                sed -i 's|Exec=/opt/QQ/qq %U|Exec=/opt/QQ/qq %U --disable-gpu-rasterization|'  $QD
            USERS=`ls /home/`
            for USER in ${USERS}
            do
		# kylin         
	        if [ -e /home/${USER}/桌面/qq.desktop ];then
                    cp /usr/share/applications/qq.desktop /home/${USER}/桌面/qq.desktop
                fi
		#uos 1060
                if [ -e /home/${USER}/Desktop/qq.desktop ];then
                    cp /usr/share/applications/qq.desktop /home/${USER}/Desktop/qq.desktop
                fi
            done

        fi
    fi

    QD=/opt/apps/linux.qq.com/entries/applications/qq.desktop
    if [ -e "$QD" ];then
        ISMW=`grep disable-gpu-rasterization $QD`
        if [ "$ISMW" == "" ];then
                sed -i 's|Exec=/opt/apps/linux.qq.com/files/qq %U|Exec=/opt/apps/linux.qq.com/files/qq %U --disable-gpu-rasterization|'  $QD
            USERS=`ls /home/`
            for USER in ${USERS}
            do
		#uos 1072
    		if [ -e /home/${USER}/Desktop/qq.desktop ];then
                    cp /opt/apps/linux.qq.com/entries/applications/qq.desktop /home/${USER}/Desktop/qq.desktop
                fi
            done

        fi
    fi
}



if [ -e /dev/jmgpu ];then
    #if [ -e /dev/mwv206_0 ];then
    while true
    do
        update_qaxbrowser
        sleep 1
        #update_org.deepin.browser
        #sleep 1
        update_loongnix.lbrowser
        sleep 1
        update_360browser
        sleep 1
        update_chromuium
        sleep 1
        update_code
        sleep 1
        update_linuxqq
    done

fi


