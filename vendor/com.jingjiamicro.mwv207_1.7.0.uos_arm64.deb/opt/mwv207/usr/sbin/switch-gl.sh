#!/bin/bash

set -x

CPU=`LANG=en uname -m`
OS=`cat /etc/os-release | sed -n '/^ID=/p' | sed -e 's/"//g' -e 's/ID=//g'`
ISRPM=`which rpm`

#龙芯UOS系统下有rpm命令导致判断错误把系统识别成服务器系统导致驱动目录识别错误
ISDPKG=`which dpkg`
if [ "${ISDPKG}" != "" ]; then
	ISRPM=""
fi

ISGLVND=0
# ii  libglvnd-dev:arm64
# ii  libglvnd0:arm64

if [ "${ISRPM}" == "" ]; then
	#debain
	LIBDIR=/usr/lib/`gcc -print-multiarch`
	HASGLVND=`dpkg -l | grep glvnd`
	ISMWV207DEV=`dpkg -l | egrep "com.jingjiamicro.mwv207|mwv207-dev" | wc -l`
else
	#rpm
	LIBDIR=/usr/lib64/
	HASGLVND=`rpm -qa | grep glvnd`
	ISMWV207DEV=`rpm -qa | egrep "com.jingjiamicro.mwv207|mwv207-dev" | wc -l`
fi

if [ "${CPU}" == "loongarch64" ]; then
	MULTIARCH=""
else
	MULTIARCH=`gcc -print-multiarch`
fi


if [ ! -z "${HASGLVND}" ]; then
	# 有安装 libglvnd
	ISGLVND=1
fi
if [ "${CPU}" == "loongarch64" -o "${CPU}" == "mips64" -o "${CPU}" == "sw_64" ]; then
	# 龙芯 、申威平台不支持 glvnd
	ISGLVND=0
fi



ISJM7200=0
ISJM9200=0
count=0
while true
do
        JM7200=`lspci -d 0731:* -n | grep '0731:7' | wc -l`
        JM9200=`lspci -d 0731:* -n | grep '0731:9' | wc -l`
        if [ $JM7200 -gt 0 ]; then
                ISJM7200=1
		if [ -e /dev/cur_gl ]; then
			# 麒麟添加的类似 glvnd 处理
			ISGLVND=1
		fi
	fi
	if [ $JM9200 -gt 0 ];then
                ISJM9200=1
		if [ -e /dev/cur_gl ]; then
			# 麒麟添加的类似 glvnd 处理
			ISGLVND=1
		fi
        fi
        count=`expr $count + 1`
        if [ $count -gt 5 ]; then
                break;
        fi
done

if [ "${CPU}" == "sw_64" ]; then
	# sw平台/dev/cur_gl麒麟未支持
	ISGLVND=0
fi

# 删除 /etc/ld.so.conf.d 目录下的 mwv206和mwv207 库设置
function remove_ldconf() {
	CONFS=`grep mwv20 /etc/ld.so.conf.d/ -rn | awk -F: '{ print $1 }' | sort | uniq`
	for CONF in ${CONFS}
	do
		if [ -e ${CONF} ]; then
			sed -i '/mwv20/d' ${CONF}
		fi
	done
}

function update_libGL_mesa() {
	if [ -d "${LIBDIR}/mesa" ]; then
		echo "${LIBDIR}/mesa" > /etc/ld.so.conf.d/${MULTIARCH}-gl.conf
	fi
	ldconfig
	LIBGLSO=`find ${LIBDIR} -maxdepth 1 -type f -name 'libGL.so.*'`
	if [ "${LIBGLSO}" != "" ]; then
		rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
		ln -sf ${LIBGLSO} ${LIBDIR}/libGL.so.1
		ln -sf ${LIBGLSO} ${LIBDIR}/libGL.so
	else
		LIBGLSO=`find ${LIBDIR}/mesa -maxdepth 1 -type f -name 'libGL.so.*'`
		if [ "${LIBGLSO}" != "" ]; then
			rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
			ln -sf ${LIBGLSO} ${LIBDIR}/libGL.so.1
			ln -sf ${LIBGLSO} ${LIBDIR}/libGL.so
		fi
	fi
}

function update_kylin() {
	remove_ldconf
	# sw平台/dev/cur_gl麒麟未支持
	if [ -e /dev/cur_gl ] && [ "${CPU}" != "sw_64" ]; then
		update_libGL_mesa
	elif [ $ISJM7200 -eq 1 ]; then
		if [ -d "${LIBDIR}/mwv206" ]; then
			echo "${LIBDIR}/mwv206" > /etc/ld.so.conf.d/${MULTIARCH}-gl.conf
			ldconfig
			rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
			ln -sf ${LIBDIR}/mwv206/libGL.so ${LIBDIR}/libGL.so
			ln -sf ${LIBDIR}/mwv206/libGL.so.1 ${LIBDIR}/libGL.so.1
		else
			update_libGL_mesa
		fi
	elif [ $ISJM9200 -eq 1 ]; then
		if [ "${ISGLVND}" == "1" ]; then
			update_libGL_mesa
		elif [ "${ISMWV207DEV}" -ne "0" ]; then
			echo "${LIBDIR}/mwv207" > /etc/ld.so.conf.d/${MULTIARCH}-gl.conf
			ldconfig
			rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
			ln -sf ${LIBDIR}/mwv207/libGL.so ${LIBDIR}/libGL.so
			ln -sf ${LIBDIR}/mwv207/libGL.so.1 ${LIBDIR}/libGL.so.1
		else
			update_libGL_mesa
		fi
	else
		update_libGL_mesa
	fi

	if [ $ISJM7200 -eq 1 ]; then
		cp -f /usr/share/X11/xorg.conf.d/10-mwv206.conf.jm7200 /usr/share/X11/xorg.conf.d/10-mwv206.conf
	elif [ $ISJM9200 -eq 1 ]; then
		if [ -e /usr/share/X11/xorg.conf.d/10-mwv206.conf ]; then
			rm -rf /usr/share/X11/xorg.conf.d/10-mwv206.conf
		fi
	else
		if [ -e /usr/share/X11/xorg.conf.d/10-mwv206.conf ]; then
			rm -rf /usr/share/X11/xorg.conf.d/10-mwv206.conf
		fi
	fi
}


function update_other() {
	remove_ldconf
	if [ $ISJM7200 -eq 1 ]; then
		if [ -d "${LIBDIR}/mwv206" ]; then
			echo "${LIBDIR}/mwv206" > /etc/ld.so.conf.d/${MULTIARCH}-gl.conf
			ldconfig
			rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
			ln -s ${LIBDIR}/mwv206/libGL.so ${LIBDIR}/libGL.so
			ln -s ${LIBDIR}/mwv206/libGL.so.1 ${LIBDIR}/libGL.so.1
		else
			if [ -d "${LIBDIR}/mesa" ]; then
				echo "${LIBDIR}/mesa" > /etc/ld.so.conf.d/${MULTIARCH}-gl.conf
			fi
			update_libGL_mesa
		fi
	elif [ $ISJM9200 -eq 1 ]; then
		if [ "${ISGLVND}" == "1" ]; then
			update_libGL_mesa
		elif [ "${ISMWV207DEV}" -ne "0" ]; then
			if [ "${OS}" == "kylinsecos" -a "${CPU}" == "loongarch64" ]; then
				#process marco can not start
				update_libGL_mesa
				while true
				do
					ISMARCO=`pgrep -x marco`
					sleep 1
					if [   "${ISMARCO}" != "" ]; then
						echo "${LIBDIR}/mwv207" > /etc/ld.so.conf.d/${MULTIARCH}-gl.conf
						ldconfig
						rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
						ln -s ${LIBDIR}/mwv207/libGL.so ${LIBDIR}/libGL.so
						ln -s ${LIBDIR}/mwv207/libGL.so.1 ${LIBDIR}/libGL.so.1
						break
					fi
				done
			else
				echo "${LIBDIR}/mwv207" > /etc/ld.so.conf.d/${MULTIARCH}-gl.conf
				ldconfig
				rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
				ln -s ${LIBDIR}/mwv207/libGL.so ${LIBDIR}/libGL.so
				ln -s ${LIBDIR}/mwv207/libGL.so.1 ${LIBDIR}/libGL.so.1
			fi
		else
			update_libGL_mesa
		fi
	else
		update_libGL_mesa
	fi

	if [ $ISJM7200 -eq 1 ]; then
		cp -f /usr/share/X11/xorg.conf.d/10-mwv206.conf.jm7200 /usr/share/X11/xorg.conf.d/10-mwv206.conf
	elif [ $ISJM9200 -eq 1 ]; then
		if [ -e /usr/share/X11/xorg.conf.d/10-mwv206.conf ]; then
			rm -rf /usr/share/X11/xorg.conf.d/10-mwv206.conf
		fi
	else
		if [ -e /usr/share/X11/xorg.conf.d/10-mwv206.conf ]; then
			rm -rf /usr/share/X11/xorg.conf.d/10-mwv206.conf
		fi
	fi
}

function update() {
	if [ "$OS" == "kylin" ]; then
		update_kylin
	else
		update_other
	fi
}

update

exit 0
