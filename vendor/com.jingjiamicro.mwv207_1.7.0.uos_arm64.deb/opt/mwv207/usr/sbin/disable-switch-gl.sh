#!/bin/bash

# set -x

CPU=`LANG=en uname -m`
OS=`cat /etc/os-release | sed -n '/^ID=/p' | sed -e 's/"//g' -e 's/ID=//g'`
LIBDIR=/usr/lib/`gcc -print-multiarch`
MULTIARCH=`gcc -print-multiarch`
KERNELMV=`uname -r | awk -F. '{ print $1"."$2}'`

ISGLVND=0
# ii  libglvnd-dev:arm64
# ii  libglvnd0:arm64
HASGLVND=`dpkg -l | grep glvnd`
if [ ! -z "${HASGLVND}" ]; then
	# 有安装 libglvnd
	ISGLVND=1
fi
if [ "${CPU}" == "loongarch64" -o "${CPU}" == "mips64" ]; then
	# 龙芯平台不支持 glvnd
	ISGLVND=0
fi

count=0
while true
do
	JM7200=`lspci -d 0731:* -n | grep '0731:7' | wc -l`
	JM9200=`lspci -d 0731:* -n | grep '0731:9' | wc -l`
	if [ $JM7200 -gt 0 ]; then
		if [ -e /dev/cur_gl ]; then
			# 麒麟添加的类似 glvnd 处理
			ISGLVND=1
		fi
	fi
	if [ $JM9200 -gt 0 ];then
		if [ -e /dev/cur_gl ]; then
			# 麒麟添加的类似 glvnd 处理
			ISGLVND=1
		fi
	fi
	count=`expr $count + 1`
	if [ $count -gt 5 ]; then
		break;
	fi
done

function update_libGL_mesa() {
	# 恢复到默认的 mesa
	CONFS=`grep mwv20 /etc/ld.so.conf.d/ -rn | awk -F: '{ print $1 }' | sort | uniq`
	for CONF in ${CONFS}
	do
		if [ -e ${CONF} ]; then
			sed -i '/mwv20/d' ${CONF}
		fi
	done

	ldconfig
	LIBGLSO=`find ${LIBDIR} -maxdepth 1 -type f -name 'libGL.so.*'`
	if [ "${LIBGLSO}" != "" ]; then
		rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
		ln -sf ${LIBGLSO} ${LIBDIR}/libGL.so.1
		ln -sf ${LIBGLSO} ${LIBDIR}/libGL.so
	else
		LIBGLSO=`find ${LIBDIR}/mesa -maxdepth 1 -type f -name 'libGL.so.*'`
		if [ "${LIBGLSO}" != "" ]; then
			rm -rf ${LIBDIR}/libGL.so ${LIBDIR}/libGL.so.1
			ln -sf ${LIBGLSO} ${LIBDIR}/libGL.so.1
			ln -sf ${LIBGLSO} ${LIBDIR}/libGL.so
		fi
	fi
}

# 是否有安装 mwv206-dev 驱动包
ISMWV206=`dpkg -l | egrep "mwv206-dev|com.jingjiamicro.mwv206" | wc -l`
# 0 - 没有更新系统的switch-gl
ISUPDATESWITCH=`grep 'update mwv206 switch-gl' /opt/mwv207/usr/share/doc/switch-gl.log | wc -l`
ISENABLESWITCH=`grep 'enable mwv207 switch-gl' /opt/mwv207/usr/share/doc/switch-gl.log | wc -l`

if [ "${ISGLVND}" == "0" ]; then
	# 操作系统不支持 glvnd
	if [ "${ISUPDATESWITCH}" != "0" -o "${ISENABLESWITCH}" != "0" ]; then
		# 有更新系统的switch-gl
		if [ "${ISMWV206}" == "0" ]; then
			# 没有安装 mwv206-dev 驱动包
			systemctl disable sw-gl.service || true
			systemctl stop sw-gl.service || true
			rm -rf /usr/sbin/switch-gl /lib/systemd/system/sw-gl.service || true
			systemctl daemon-reload

			update_libGL_mesa
		else
			# mwv206-dev 驱动包还没有卸载，还不能删除 sw-gl 相关的脚本
			update_libGL_mesa
		fi
	fi
fi

# 有 JM92 显卡
if [ $JM9200 -gt 0 ];then
	if [ -e /usr/share/X11/xorg.conf.d/10-mwv206.conf ]; then
		# 删除 JM72 的 xorg 配置文件
		rm -rf /usr/share/X11/xorg.conf.d/10-mwv206.conf
	fi
fi

