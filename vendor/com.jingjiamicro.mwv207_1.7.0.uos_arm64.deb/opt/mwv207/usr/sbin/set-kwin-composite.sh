#!/bin/bash

# set -x

# 参数说明：
# XRender - 设置成使用XRender后端，将Backend设置为XRender、OpenGLIsUnsafe设置为true
# OpenGL  - 设置成使用GL后端，将Backend设置为OpenGL、OpenGLIsUnsafe设置为false

BACKEND=$1

# kylin
# uos
OS=`cat /etc/os-release | sed -n '/^ID=/p' | sed -e 's/"//g' -e 's/ID=//g' | tr A-Z a-z`

if [ "${OS}" == "kylin" ]; then
	RCS=`find /home/ -mindepth 3 -maxdepth 3 -type f -name ukui-kwinrc`
elif [ "${OS}" == "uos" ]; then
	RCS=`find /home/ -mindepth 3 -maxdepth 3 -type f -name kwinrc`
fi

if [ "${BACKEND}" == "XRender" ]; then
	for RC in ${RCS}
	do
		if [ -e ${RC} -a ! -z ${RC} ]; then
			sed -i -e 's/\(Backend\)=.*/\1=XRender/g' ${RC}
			sed -i -e 's/\(OpenGLIsUnsafe\)=.*$/\1=true/g' ${RC}
			sed -i -e 's/\(OpenGLIsUnsafePending\)=.*/\1=false/g' ${RC}
			HASTOUCH1=`grep touchclickEnabled ${RC}`
			if [ -z "${HASTOUCH1}" ]; then
				echo "touchclickEnabled=false" >> ${RC}
			else
				sed -i -e 's/\(touchclickEnabled\)=.*/\1=false/g' ${RC}
			fi
			HASTOUCH2=`grep touchmotionstreakEnabled ${RC}`
			if [ -z "${HASTOUCH2}" ]; then
				echo "touchmotionstreakEnabled=false" >> ${RC}
			else
				sed -i -e 's/\(touchmotionstreakEnabled\)=.*$/\1=false/g' ${RC}
			fi
		fi
	done
elif [ "${BACKEND}" == "OpenGL" ]; then
	for RC in ${RCS}
	do
		if [ -e ${RC} -a ! -z ${RC} ]; then
			sed -i -e 's/\(Backend\)=.*/\1=OpenGL/g' ${RC}
			sed -i -e 's/\(OpenGLIsUnsafe\)=.*$/\1=false/g' ${RC}
			sed -i -e 's/\(touchclickEnabled\)=.*/\1=true/g' ${RC}
			sed -i -e 's/\(touchmotionstreakEnabled\)=.*$/\1=true/g' ${RC}
		fi
	done
fi

exit 0
